import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  filterUrl = '/assets/filters/filter-data.json'
  constructor (private readonly _http: HttpClient) { }

  getFilterOptions (): Observable<any> {
    return this._http.get<any>(this.filterUrl)
  }
}
