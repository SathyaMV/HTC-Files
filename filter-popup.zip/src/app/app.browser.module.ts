import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { documentToHtmlString } from '@contentful/rich-text-html-renderer';
import { HttpClientModule } from '@angular/common/http';
import { AppModule } from './app.module';
import { FormsModule } from '@angular/forms';

documentToHtmlString
@NgModule({
  imports: [
    BrowserModule.withServerTransition({
      appId: 'serverApp'
    }),
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    AppModule,
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppBrowserModule { }
