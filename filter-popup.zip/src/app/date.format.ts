export const MY_FORMATS_MONTH_YEAR = {
    parse: {
      dateInput: 'MM/YYYY',
    },
    display: {
      dateInput: 'MMM YYYY',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  };

  export const MY_FORMATS_YEAR = {
    parse: {
      dateInput: 'MM/YYYY'
    },
    display: {
      dateInput: 'YYYY',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY'
    },
  };