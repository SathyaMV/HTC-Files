import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-packages',
  templateUrl: './packages.component.html',
  styleUrls: ['./packages.component.css']
})
export class PackagesComponent implements OnInit {
  recordNotFound: boolean = false
  systemError: boolean = true
  cartButtonLabel: Record<string, string> = {
    available: 'Book Now',
    booked: 'Booked',
    outOfStock: 'Sold Out'
  }

  packageList: any[] = [
    {
      title: 'Study Abroad in Australia & New Zealand',
      description: 'Save $800 with this 10 event package',
      totalEvents: '10',
      eventDuration: '8 -20 Jan 2023',
      hostCountries: 'AU, NZ',
      countryName: 'India',
      countryImg: './assets/img/flags/india-flag.svg',
      eventGroup: 'Study Abroad in Australia & New Zealand',
      actualPrice: '$8,800',
      offerPrice: '$8,000 AUD',
      BookingDeadlineDate: '10 Jan 2023',
      packageStatus: 'available',
      isBookingDeadlineAvailable: false,
      isEarlyBirdAvailable: true,
      isHidden: false,
      packageId: '1'
    },
    {
      title: 'Study Abroad in Australia & New Zealand',
      description: 'Save $1200 with this 14 event package',
      totalEvents: '14',
      eventDuration: '5 -25 Jan 2023',
      hostCountries: 'AU, NZ',
      countryName: 'Australia',
      countryImg: './assets/img/flags/australia-flag.svg',
      eventGroup: 'Study Abroad in Australia & New Zealand',
      actualPrice: '$8,000',
      offerPrice: '$6,800 AUD',
      BookingDeadlineDate: '10 Jan 2023',
      packageStatus: 'available',
      isBookingDeadlineAvailable: true,
      isEarlyBirdAvailable: false,
      isHidden: false,
      packageId: '2'
    },
    {
      title: 'Study Abroad in Australia & New Zealand',
      description: 'Save $800 with this 10 event package',
      totalEvents: '10',
      eventDuration: '8 -20 Jan 2023',
      hostCountries: 'AU, NZ',
      countryName: 'India',
      countryImg: './assets/img/flags/india-flag.svg',
      eventGroup: 'Study Abroad in Australia & New Zealand',
      actualPrice: '$8,800',
      offerPrice: '$8,000 AUD',
      BookingDeadlineDate: '10 Jan 2023',
      packageStatus: 'booked',
      isBookingDeadlineAvailable: false,
      isEarlyBirdAvailable: false,
      isHidden: false,
      packageId: '3'
    },
    {
      title: 'Study Abroad in Australia & New Zealand',
      description: 'Save $800 with this 10 event package',
      totalEvents: '10',
      eventDuration: '8 -20 Jan 2023',
      hostCountries: 'AU, NZ',
      countryName: 'India',
      countryImg: './assets/img/flags/india-flag.svg',
      eventGroup: 'Study Abroad in Australia & New Zealand',
      actualPrice: '$8,800',
      offerPrice: '$8,000 AUD',
      BookingDeadlineDate: '10 Jan 2023',
      packageStatus: 'outOfStock',
      isBookingDeadlineAvailable: false,
      isEarlyBirdAvailable: false,
      isHidden: false,
      packageId: '4'
    },
    {
      title: 'Annual Package',
      description: 'Save $4,000 with this 24 event package',
      totalEvents: '24',
      eventDuration: '15 -31 Jan 2023',
      hostCountries: 'AU, NZ',
      countryName: 'INDIA + 3 MORE',
      countryImg: './assets/img/flags/india-flag.svg',
      eventGroup: 'Study Abroad in Australia & New Zealand + 5 MORE',
      actualPrice: '$28,800',
      offerPrice: '$24,000 AUD',
      BookingDeadlineDate: '18 Jan 2023',
      packageStatus: 'available',
      isBookingDeadlineAvailable: false,
      isEarlyBirdAvailable: true,
      isHidden: false,
      packageId: '5'
    }
  ]

  ngOnInit (): void { }
}
