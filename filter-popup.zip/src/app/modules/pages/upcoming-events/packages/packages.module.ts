import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ReactiveFormsModule } from '@angular/forms'
import { PackagesRoutingModule } from './packages-routing.module'
import { PackagesComponent } from './packages.component'
import { FilterComponent } from '../../../../shared/components/filter/filter.component'
import { HeaderComponent } from '../../../../shared/components/header/header.component'
import { MatSelectModule } from '@angular/material/select'
import { MatCheckboxModule } from '@angular/material/checkbox'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatTabsModule } from '@angular/material/tabs'
import { MatIconModule } from '@angular/material/icon'
import { MatBadgeModule } from '@angular/material/badge'
import { MatCardModule } from '@angular/material/card'
import { MatButtonModule } from '@angular/material/button'
import { CdkAccordionModule } from '@angular/cdk/accordion'
import { MatExpansionModule } from '@angular/material/expansion'
import { MatListModule } from '@angular/material/list'
import { MatDialogModule } from '@angular/material/dialog'
import { FilterPopupComponent } from 'src/app/shared/components/filter/filter-popup/filter-popup.component'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { DateAdapter, MatNativeDateModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core'
import { MatInputModule } from '@angular/material/input'
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter'
import { MY_FORMATS_MONTH_YEAR } from 'src/app/date.format'

@NgModule({
  declarations: [
    PackagesComponent,
    FilterComponent,
    HeaderComponent,
    FilterPopupComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    PackagesRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatTabsModule,
    MatIconModule,
    MatBadgeModule,
    CdkAccordionModule,
    MatExpansionModule,
    MatListModule,
    MatDialogModule,
    MatBadgeModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    HttpClientModule
  ],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS_MONTH_YEAR }
  ]
})
export class PackagesModule {}
