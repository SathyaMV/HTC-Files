import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `openSideNav`', () => {
    jest.spyOn(component, 'openSideNav');
    component.openSideNav();
    expect(component.openSideNav).toHaveBeenCalled();
    component.navActivenew = true;
    expect(component.navActivenew).toBe(true);
  });

  it('Should call `openSideNav` if false condition', () => {
    jest.spyOn(component, 'openSideNav');
    component.openSideNav();
    expect(component.openSideNav).toHaveBeenCalled();
    component.navActivenew = false;
    expect(component.navActivenew).toBe(false);
  });

});
