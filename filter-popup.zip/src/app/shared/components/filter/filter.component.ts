import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { MatDialog } from '@angular/material/dialog'
import { FilterPopupComponent } from './filter-popup/filter-popup.component'
import { MatDatepicker } from '@angular/material/datepicker'
import * as _moment from 'moment'
import { default as _rollupMoment, Moment } from 'moment'
import { FilterService } from 'src/app/providers/filter.service'
const moment = _rollupMoment || _moment

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  constructor (public dialog: MatDialog, public filterService: FilterService) { }

  form!: FormGroup

  regionOptions = []

  countryOptions = []

  groupOptions = []

  myFilter = (d: any): boolean => {
    const month = (d?._d || new Date()).getMonth()
    if (month !== 5 && month !== 11) {
      return true
    } else {
      return false
    }
  }

  date: any = new FormControl(moment())
  minDate: Date = new Date()

  chosenYearHandler (normalizedYear: Moment): void {
    const ctrlValue = this.date.value
    console.log(ctrlValue)
    ctrlValue.year(normalizedYear.year())
    console.log(ctrlValue)
    this.date.setValue(ctrlValue)
  }

  chosenMonthHandler (normalizedMonth: Moment, datepicker: MatDatepicker<Moment>): void {
    datepicker.close()
    const ctrlValue = this.date.value
    console.log(ctrlValue)
    ctrlValue.month(normalizedMonth.month())
    console.log(ctrlValue)
    this.date.setValue(ctrlValue)
  }

  previousMonth (): void {
    const ctrlValue = this.date.value
    if (ctrlValue.month() > this.minDate.getMonth() || ctrlValue.year() > this.minDate.getFullYear()) {
      ctrlValue.month(ctrlValue.month() - 1)
    }
    this.date.setValue(ctrlValue);
  }

  nextMonth (): void {
    const ctrlValue = this.date.value
    ctrlValue.month(ctrlValue.month() + 1)
    this.date.setValue(ctrlValue)
  }

  ngOnInit (): void {
    this.form = new FormGroup({
      selectedRegion: new FormControl([]),
      selectedCountry: new FormControl([]),
      selectedGroup: new FormControl([])
    })

    this.getRegionOptions()
    this.getCountryOptions()
    this.getGroupOptions()
  }

  /**
   * Methods for getting filter dropdown data's from the json
   */
  getRegionOptions (): void {
    this.filterService.getFilterOptions().subscribe((region) => {
      this.regionOptions = JSON.parse(JSON.stringify(region.regionOptions))
    })
  }

  getCountryOptions (): void {
    this.filterService.getFilterOptions().subscribe((country) => {
      this.countryOptions = JSON.parse(JSON.stringify(country.countryOptions))
    })
  }

  getGroupOptions (): void {
    this.filterService.getFilterOptions().subscribe((group) => {
      this.groupOptions = JSON.parse(JSON.stringify(group.groupOptions))
    })
  }

  /**
   * Method for opend filterpopup for mobile and tabs
   */
  openDialog (): void {
    const dialogRef = this.dialog.open(FilterPopupComponent)
    dialogRef.afterClosed().subscribe(result => { })
  }

  /**
   * Methods for selecting/deselecting all the option in the filter dropdown
   */
  onSelectAllRegion (): void {
    this.form.patchValue({
      selectedRegion: this.regionOptions.map(option => option.value)
    })
  }

  onClearAllRegion (): void {
    this.form.patchValue({ selectedRegion: [] })
  }

  onSelectAllCountry (): void {
    this.form.patchValue({
      selectedCountry: this.countryOptions.map(option => option.value)
    })
  }

  onClearAllCountry (): void {
    this.form.patchValue({ selectedCountry: [] })
  }

  onSelectAllGroup (): void {
    this.form.patchValue({
      selectedGroup: this.groupOptions.map(option => option.value)
    })
  }

  onClearAllGroup (): void {
    this.form.patchValue({ selectedGroup: [] })
  }

  /**
   * Method for resetting all the selected filter option to default(empty)
   */
  clearFilters (): void {
    this.form.reset()
  }
}
