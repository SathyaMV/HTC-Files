import { Component, OnInit } from '@angular/core'
import { FormBuilder, FormControl, FormGroup } from '@angular/forms'

@Component({
  selector: 'app-filter-popup',
  templateUrl: './filter-popup.component.html',
  styleUrls: ['./filter-popup.component.css']
})
export class FilterPopupComponent implements OnInit {
  panelOpenState: boolean = true

  popupForm!: FormGroup

  regionOptions = [
    { label: 'Africa', value: 'Africa' },
    { label: 'East Asia', value: 'East Asia' },
    { label: 'Europe', value: 'Europe' },
    { label: 'Middle East', value: 'Middle East' },
    { label: 'North America', value: 'North America' },
    { label: 'Oceania', value: 'Oceania' },
    { label: 'South Asia', value: 'South Asia' },
    { label: 'South East Asia', value: 'South East Asia' },
    { label: 'West Asia', value: 'West Asia' }
  ]

  countryOptions = [
    { label: 'Australia', value: 'Australia', region: 'Oceania' },
    { label: 'Bahrain', value: 'Bahrain', region: 'Middle East' },
    { label: 'Bangladesh', value: 'Bangladesh', region: 'South Asia' },
    { label: 'Cambodia', value: 'Cambodia', region: 'South East Asia' },
    { label: 'Canada', value: 'Canada', region: 'North America' },
    { label: 'Egypt', value: 'Egypt', region: 'Middle East' },
    { label: 'Ghana', value: 'Ghana', region: 'Africa' },
    { label: 'Hong Kong', value: 'Hong Kong', region: 'East Asia' },
    { label: 'India', value: 'India', region: 'South Asia' },
    { label: 'Indonesia', value: 'Indonesia', region: 'South East Asia' },
    { label: 'Iran', value: 'Iran', region: 'Middle East' },
    { label: 'Jordan', value: 'Jordan', region: 'Middle East' },
    { label: 'Kenya', value: 'Kenya', region: 'Africa' },
    { label: 'Kuwait', value: 'Kuwait', region: 'Middle East' },
    { label: 'Lebanon', value: 'Lebanon', region: 'Middle East' },
    { label: 'Malaysia', value: 'Malaysia', region: 'South East Asia' },
    { label: 'Mauritius', value: 'Mauritius', region: 'Africa' },
    { label: 'Nepal', value: 'Nepal', region: 'South Asia' },
    { label: 'New Zealand', value: 'New Zealand', region: 'Oceania' },
    { label: 'Nigeria', value: 'Nigeria', region: 'Africa' },
    { label: 'Oman', value: 'Oman', region: 'Middle East' },
    { label: 'Pakistan', value: 'Pakistan', region: 'South Asia' },
    { label: 'Philippines', value: 'Philippines', region: 'South East Asia' },
    { label: 'Saudi Arabia', value: 'Saudi Arabia', region: 'Middle East' },
    { label: 'Singapore', value: 'Singapore', region: 'South East Asia' },
    { label: 'South Korea', value: 'South Korea', region: 'East Asia' },
    { label: 'Sri Lanka', value: 'Sri Lanka', region: 'South Asia' },
    { label: 'Taiwan', value: 'Taiwan', region: 'East Asia' },
    { label: 'Thailand', value: 'Thailand', region: 'South East Asia' },
    { label: 'Turkey', value: 'Turkey', region: 'West Asia' },
    { label: 'UAE', value: 'UAE', region: 'Middle East' },
    { label: 'United Kingdom', value: 'United Kingdom', region: 'Europe' },
    { label: 'United  States', value: 'United  States', region: 'North America' },
    { label: 'Vietnam', value: 'Vietnam', region: 'South East Asia' }
  ]

  groupOptions = [
    {
      label: 'Study Abroad in Australia & New Zealand - India',
      value: 'Study Abroad in Australia & New Zealand - India'
    },
    { label: 'Study World Expo', value: 'Study World Expo' }
  ]

  constructor (public formBuilder: FormBuilder) {}

  ngOnInit (): void {
    this.popupForm = this.formBuilder.group({
      selectedRegion: new FormControl([]),
      selectedCountry: new FormControl([]),
      selectedGroup: new FormControl([])
    })
  }

  onSelectAllRegion (): void {
    this.popupForm.patchValue({
      selectedRegion: this.regionOptions.map(option => option.value)
    })
  }

  onClearAllRegion (): void {
    this.popupForm.patchValue({ selectedRegion: [] })
  }

  onSelectAllCountry (): void {
    this.popupForm.patchValue({
      selectedCountry: this.countryOptions.map(option => option.value)
    })
  }

  onClearAllCountry (): void {
    this.popupForm.patchValue({ selectedCountry: [] })
  }

  onSelectAllGroup (): void {
    this.popupForm.patchValue({
      selectedGroup: this.groupOptions.map(option => option.value)
    })
  }

  onClearAllGroup (): void {
    this.popupForm.patchValue({ selectedGroup: [] })
  }

  clearFilters (): void {
    this.popupForm.reset()
  }
}
