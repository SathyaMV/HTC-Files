export const environment = {
    production: true,
    baseHref: '/'
};
