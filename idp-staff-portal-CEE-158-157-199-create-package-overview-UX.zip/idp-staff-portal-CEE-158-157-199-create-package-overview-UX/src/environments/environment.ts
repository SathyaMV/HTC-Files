// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

import { simConstants } from '../app/common/utilities/sim-constants'
import { constants, routingUrl } from '../app/common/utilities/constants'

const apiDomain = constants.dev
const eventCopyUrlDomain = routingUrl.dev
const kioskUrl = routingUrl.dev
const checkInAppUrl = routingUrl.dev

const simApiDomain = simConstants.dev

export const environment = {
  production: true,
  baseHref: '/',
  enableAutentication: apiDomain.authentication,
  authenticationToken: apiDomain.authenticationToken,
  authenticationEmail: apiDomain.authenticationEmail,
  eventDashboardAPI: apiDomain.eventListViewAPI,
  eventOverViewAPI: apiDomain.eventOverViewAPI,
  virtualEventUrl: apiDomain.virtualEventUrl,
  webinarEventUrl: apiDomain.webinarEventUrl,
  studentProfileAPI: apiDomain.studentProfileAPI,
  eventQrCheckIn: apiDomain.eventQrcheckIn,
  eventsDynamicForm: apiDomain.eventsDynamicForm,
  getCounsellorNotesAPI: apiDomain.getNotesDetailsAPI,
  putCounsellorNotesAPI: apiDomain.putNotesDetailsAPI,
  bulkUploadRegistration: apiDomain.bulkUploadRegistration,
  getQuestions: apiDomain.getQuestions,
  updatePersonalInfoDetails: apiDomain.updatePersonalInfo,
  kioskSearch: apiDomain.kioskSearch,
  eventRegsitrationForm: apiDomain.eventRegistrationForm,
  updateEducationDetails: apiDomain.updateEducationInfo,
  updateBulkUploadlog: apiDomain.bulkUploadLog,
  searchEventResgistration: apiDomain.searchEventResgistration,
  getPreferenceAnswer: apiDomain.getPreferenceInfo,
  getEducationAnswer: apiDomain.getEducationInfo,
  getProficiency: apiDomain.getEnglishProficiency,
  putProficiency: apiDomain.putEnglishProficiency,
  eventCopyUrl: eventCopyUrlDomain.eventCopyUrl,
  getHDYH: apiDomain.getHowDidYouHear,
  getDestination: apiDomain.getDestination,
  getRegisterParticipant: apiDomain.getRegisterParticipant,
  getPreferredStudyLevel: apiDomain.getPreferredStudyLevel,
  getPreRegisterWalkin: apiDomain.getPreRegisterWalkin,
  getHighestQualification: apiDomain.getHighestQualification,
  getNewExistingStudent: apiDomain.getNewExistingStudent,
  kioskUrl: kioskUrl.kioskUrl,
  updateStaffDetails: apiDomain.postStaffDetails,
  getStaffInfo: apiDomain.getStaffDetails,
  getUserList: apiDomain.getUserList,
  getPermission: apiDomain.getPermissions,
  getStaffProfile: apiDomain.getStaffProfile,
  putStaffProfile: apiDomain.putStaffProfile,
  getImportRegistrants: apiDomain.getImportRegistrants,
  checkInUrl: checkInAppUrl.checkInUrl,
  putlastLogin: apiDomain.putLastLogin,
  getStudentParticipation: apiDomain.getStudentParticipation,
  getDownloadReport: apiDomain.getDownloadReport,
  checkStaffExist: apiDomain.checkStaffExist,
  postReferralData: apiDomain.updateReferralDetails,
  // Cognito details
  cognitoDomain: 'localhost',
  identityServer: 'dev-networkportal.auth.ap-southeast-1.amazoncognito.com',
  redirectSignIn: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  redirectSignOut: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  region: 'ap-southeast-1',
  userPoolId: 'ap-southeast-1_JtDXYUi6b',
  userPoolWebClientId: '241g55s6j05sqhc60pfv57if7t',
  identityPoolId: 'ap-southeast-1:2775aebc-62bd-4b15-aa05-6277e70cc690',


  // cognitoDomain: 'localhost',
  // identityServer: 'uat-networkportal.auth.ap-southeast-1.amazoncognito.com',
  // redirectSignIn: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // redirectSignOut: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // region: 'ap-southeast-1',
  // userPoolId: 'ap-southeast-1_qf8162Dw6',
  // userPoolWebClientId: '1dk8b3gr5ta4pqgnhtjboggtm4',
  // identityPoolId: 'ap-southeast-1:2775aebc-62bd-4b15-aa05-6277e70cc690',


  // cognitoDomain: 'localhost',
  // identityServer: 'stg-networkportal.auth.ap-southeast-1.amazoncognito.com',
  // redirectSignIn: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // redirectSignOut: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // region: 'ap-southeast-1',
  // userPoolId: 'ap-southeast-1_X6CeWEwIH',
  // userPoolWebClientId: '7o0s9hvhb26m4qbmog83uieg2j',
  // identityPoolId: 'ap-southeast-1:2775aebc-62bd-4b15-aa05-6277e70cc690',


  // Cognito details
  // cognitoDomain : 'localhost',
  // identityServer: 'uat-networkportal.auth.ap-southeast-1.amazoncognito.com',
  // redirectSignIn: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // redirectSignOut: 'http://localhost:4200/idp-staff-portal/events-dashboard',
  // region: 'ap-southeast-1',
  // userPoolId : 'ap-southeast-1_qf8162Dw6',
  // userPoolWebClientId : '1dk8b3gr5ta4pqgnhtjboggtm4',
  // identityPoolId:'ap-southeast-1:2775aebc-62bd-4b15-aa05-6277e70cc690',

  // Simplified Event Integration
  isSimEnable: true,
  langTxtJson: simApiDomain.langTxtJson,
  eventClassificationList: simApiDomain.eventClassificationList,
  eventClassificationApi: simApiDomain.eventClassificationApi,
  tabListApi: simApiDomain.tabListApi,
  regionApi: simApiDomain.regionApi,
  countryApi: simApiDomain.countryApi,
  destinationApi: simApiDomain.destinationApi,
  masterEventApi: simApiDomain.masterEventApi,
  studentEventApi: simApiDomain.studentEventApi,
  studentEventTabListApi: simApiDomain.studentEventTabListApi,
  supportedStudyLevelJson: simApiDomain.supportedStudyLevelJson,
  eventPlannerEmailApi: simApiDomain.eventPlannerEmailApi,
  hostCountryApi: simApiDomain.hostCountryApi,
  timezoneJson: simApiDomain.timezoneJson
}
