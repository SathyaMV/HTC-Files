import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'

import { PackagesDashboardRoutingModule } from './packages-dashboard-routing.module'
import { PackagesDashboardComponent } from './packages-dashboard.component'
import { SideNavModule } from 'src/app/common/component/side-nav/side-nav.module'

@NgModule({
  declarations: [PackagesDashboardComponent],
  imports: [CommonModule, PackagesDashboardRoutingModule, SideNavModule]
})
export class PackagesDashboardModule {}
