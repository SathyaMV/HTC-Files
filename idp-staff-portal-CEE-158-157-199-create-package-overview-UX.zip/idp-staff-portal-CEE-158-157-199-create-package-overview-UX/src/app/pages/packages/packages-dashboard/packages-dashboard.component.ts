import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-packages-dashboard',
  templateUrl: './packages-dashboard.component.html',
  styleUrls: ['./packages-dashboard.component.css']
})
export class PackagesDashboardComponent implements OnInit {
  pkgSuccess: boolean | undefined

  constructor () {}

  ngOnInit (): void {
    this.pkgSuccess = true
  }
}
