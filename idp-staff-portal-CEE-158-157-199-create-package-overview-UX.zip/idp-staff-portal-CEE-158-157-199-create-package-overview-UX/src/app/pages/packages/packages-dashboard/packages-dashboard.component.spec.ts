import { ComponentFixture, TestBed } from '@angular/core/testing'

import { PackagesDashboardComponent } from './packages-dashboard.component'

describe('PackagesDashboardComponent', () => {
  let component: PackagesDashboardComponent
  let fixture: ComponentFixture<PackagesDashboardComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PackagesDashboardComponent]
    }).compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(PackagesDashboardComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
