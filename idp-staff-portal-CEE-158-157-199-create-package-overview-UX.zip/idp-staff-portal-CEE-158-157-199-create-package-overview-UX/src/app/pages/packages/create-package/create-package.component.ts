import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core'
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from '@angular/forms'
import { MatDialog } from '@angular/material/dialog'
import { MatStepper } from '@angular/material/stepper'

@Component({
  selector: 'app-create-package',
  templateUrl: './create-package.component.html',
  styleUrls: ['./create-package.component.css']
})
export class CreatePackageComponent implements OnInit {
  @ViewChild('stepper') stepper!: MatStepper
  @ViewChild('formInvalidPopup') formInvalidPopup!: TemplateRef<any>
  isLinear = true
  pkgEventGroupList!: FormGroup
  firstFormGroup!: FormGroup
  secondFormGroup!: FormGroup
  showLoaderIcon: boolean = false

  constructor (
    private readonly formBuilder: FormBuilder,
    private readonly dialog: MatDialog
  ) {}

  ngOnInit (): void {
    this.pkgEventGroupList = new FormGroup({
      selectedEventGroup: new FormControl([])
    })
    this.firstFormGroup = new FormGroup({
      firstCtrl: new FormControl('', Validators.required)
    })
    this.secondFormGroup = new FormGroup({
      secondCtrl: new FormControl('', Validators.required)
    })
  }

  packageOverview = this.formBuilder.group({
    firstCtrl: ['', Validators.required]
  })

  eventGroup = this.formBuilder.group({
    secondCtrl: ['', Validators.required]
  })

  openDialog (): void {
    this.dialog.open(this.formInvalidPopup)
  }

  moveToNextStep (stepper): void {
    stepper.next()
  }
}
