import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatDialogModule } from '@angular/material/dialog'
import { MatButtonModule } from '@angular/material/button'
import { CdkStepperModule } from '@angular/cdk/stepper'
import { MatInputModule } from '@angular/material/input'
import { MatCardModule } from '@angular/material/card'
import { MatRadioModule } from '@angular/material/radio'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatStepperModule } from '@angular/material/stepper'
import { CreatePackageRoutingModule } from './create-package-routing.module'
import { CreatePackageComponent } from './create-package.component'
import { PackageOverviewComponent } from 'src/app/common/component/package-components/package-overview/package-overview.component'
import { EventGroupComponent } from 'src/app/common/component/package-components/event-group/event-group.component'
import { SimHeaderModule } from 'src/app/common/component/simEventComponents/SimHeader/sim-header.module'
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module'
import { MatCheckboxModule } from '@angular/material/checkbox'
import { PackageSearchFilterComponent } from 'src/app/common/component/package-components/package-search-filter/package-search-filter.component'
import { MatAutocompleteModule } from '@angular/material/autocomplete'
import { NgxPaginationModule } from 'ngx-pagination'
@NgModule({
  declarations: [
    CreatePackageComponent,
    PackageOverviewComponent,
    EventGroupComponent,
    PackageSearchFilterComponent
  ],
  imports: [
    CommonModule,
    CreatePackageRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatStepperModule,
    CdkStepperModule,
    MatFormFieldModule,
    MatInputModule,
    MatCardModule,
    MatRadioModule,
    SimHeaderModule,
    MatDialogModule,
    LoaderIconModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    NgxPaginationModule
  ]
})
export class CreatePackageModule {}
