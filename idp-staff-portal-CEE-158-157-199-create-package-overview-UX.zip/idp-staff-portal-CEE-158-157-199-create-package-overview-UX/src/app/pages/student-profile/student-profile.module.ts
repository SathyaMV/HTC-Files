import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { StudentProfileComponent } from './student-profile.component';
import { StudentDetailsComponent } from 'src/app/common/component/student-details/student-details.component';
import { GenerateStudentQrCodeComponent } from 'src/app/common/component/generate-student-qr-code/generate-student-qr-code.component';
import { QRCodeModule } from 'angularx-qrcode';
import { PersonalInformationComponent } from 'src/app/common/component/personal-information/personal-information.component';
import { EducationComponent } from 'src/app/common/component/education/education.component';
import { LeadManagementModule } from 'src/app/common/component/lead-management/lead-management.module';
import { NotesComponent } from 'src/app/common/component/notes/notes.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { PipeModule } from 'src/app/common/pipe/pipe.module';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTableModule } from '@angular/material/table';

const routes: Routes = [
  {path:'', component:StudentProfileComponent}
];

@NgModule({
  declarations: [
    EducationComponent,
    StudentProfileComponent,
    StudentDetailsComponent,
    GenerateStudentQrCodeComponent,
    PersonalInformationComponent,
    NotesComponent
  ],
  imports: [
    CommonModule,
    CdkAccordionModule,
    QRCodeModule,
    LeadManagementModule,
    MatButtonModule,
    MatInputModule,
    MatTabsModule,
    MatFormFieldModule,
    MatOptionModule,
    MatSelectModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    MatTableModule,
    MatNativeDateModule,
    PipeModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
  ]
})
export class StudentProfileModule { }
