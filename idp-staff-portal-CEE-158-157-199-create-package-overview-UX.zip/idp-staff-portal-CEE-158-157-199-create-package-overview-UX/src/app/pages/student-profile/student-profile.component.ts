import { Component, OnInit } from '@angular/core';
import { BffService } from '../../providers/bff.service';
import { Router } from '@angular/router';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-student-profile',
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.css']
})
export class StudentProfileComponent implements OnInit {
  userQuestionData:[];
  eventCode = sessionStorage.getItem('eventCode_'+sessionStorage.getItem('tabID'))
  tabChange:number;
  studentId;
  educationGroups;
  personalGroups;
  qualificationQnData;
  englishProficiencyQnData;
  personalInfoQnData;
  dialCodeList;
  showLoadingIcon:boolean = true;
  preferenceGroups;
  preferenceQnData;
  selectedIndex;
  isLoaded:boolean = false
  qualificationAnswer;
  proficiencyAnswer;
  doYouWishAnswer;
  canViewStudentDetails:boolean = false

  constructor(private bff: BffService,private router:Router) { }

  ngOnInit(): void {
    this.getstudentDetails();

    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canViewStudentDetails = data['userAccess'].canViewStudentDetails
    })
  }

getstudentDetails(){
  this.getEducationAnswer();
  this.studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
  this.bff.getUserQuestions("IDP Events",this.studentId,"NP-GA").subscribe(data =>{
    this.showLoadingIcon = !this.showLoadingIcon;
    const studentDetails = data.questions.sections;
    studentDetails.filter(ele =>{
      if(ele.displaySequence == 2){
        const educationValue = ele;
        this.educationGroups = educationValue.groups 
      }else if(ele.displaySequence == 1){
        const personalValue = ele;
        this.personalGroups = personalValue.groups        
      }else if(ele.displaySequence == 3){
        const preferenceValue = ele;
        this.preferenceGroups = preferenceValue.groups
      }
    })
    this.educationGroups.filter(data => {
      if(data.groupSequence == 2){
        const groupData = data;
        this.qualificationQnData = groupData.questions;
      }else if(data.groupSequence == 3){
        const groupData = data;
        this.englishProficiencyQnData = groupData.questions;
      }
    }) 
    this.personalGroups.filter(val =>{
      if(val.groupSequence == 1){
        const personalGroupData = val;
        this.personalInfoQnData = personalGroupData.questions
        let reArrange = this.move(this.personalInfoQnData,2,0)
        this.move(reArrange,7,1)
        if(this.personalInfoQnData){
          this.isLoaded = true ;
          this.selectedIndex = 1;
        }
      }
    })
    this.dialCodeList = data.dialCodeRules;
    this.preferenceGroups.filter(val => {
      if(val.groupSequence == 1){
        const preferenceGroupData = val;
        this.preferenceQnData = preferenceGroupData.questions;
        this.move(this.preferenceQnData,1,2)
      }
    })
  })
}


getEducationAnswer(){
  let studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'));
  let eventId = sessionStorage.getItem('eventId_'+sessionStorage.getItem('tabID'))
  this.bff.getEducationAnswer(studentId).subscribe(data => {
  this.qualificationAnswer = data?.response?.educationDetails?.qualification;
  this.proficiencyAnswer =data?.response?.educationDetails?.englishProficiency;
  })
  this.bff.getEnglishProficiency(eventId,studentId).subscribe(res =>{
   this.doYouWishAnswer = res?.response;
  });
}

overViewPage(){
  this.router.navigateByUrl('idp-staff-portal/events-overview'+ '?eventCode=' + this.eventCode);
}

myTabSelectedTabChange(changeEvent: MatTabChangeEvent) {
  this.tabChange = changeEvent.index 
} 
//This method is used to change the order in array
move(array, from, to) {
  if( to === from ) return array;
  var target = array[from];                         
  var increment = to < from ? -1 : 1;
  for(var k = from; k != to; k += increment){
    array[k] = array[k + increment];
  }
  array[to] = target;
  return array;
}
}
