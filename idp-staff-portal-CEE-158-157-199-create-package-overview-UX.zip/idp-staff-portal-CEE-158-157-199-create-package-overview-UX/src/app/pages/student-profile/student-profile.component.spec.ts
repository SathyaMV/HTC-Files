import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { EducationComponent } from '../../common/component/education/education.component';
import { NotesComponent } from '../../common/component/notes/notes.component';
import { PersonalInformationComponent } from '../../common/component/personal-information/personal-information.component';
import { StudentDetailsComponent } from '../../common/component/student-details/student-details.component';
import { BffService } from '../../providers/bff.service';
import { StudentProfileComponent } from './student-profile.component';
import { CommonMethods } from '../../common/utilities/common-methods';

describe('StudentProfileComponent', () => {
  let component: StudentProfileComponent;
  let fixture: ComponentFixture<StudentProfileComponent>;
  let service: BffService;
  const personalGroups  = [{test:'personal'}]
  const educationGroups = [{test:'education'}]
  const personalInfoAnswer  = [{email:'test@gamil.com'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentProfileComponent,
        StudentDetailsComponent,
        PersonalInformationComponent,
        EducationComponent,
        NotesComponent],
      providers:[BffService, { provide: CommonMethods, useClass: class {} }],
      imports:[RouterTestingModule,
        HttpClientModule,
        MatTabsModule,
        FormsModule,
        ReactiveFormsModule,
        NoopAnimationsModule,
        MatInputModule,
        MatSelectModule,
        MatFormFieldModule,
        MatDatepickerModule,
        MatNativeDateModule,
        CdkAccordionModule]
    })
    .compileComponents();
    service = TestBed.inject(BffService)
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.personalGroups = personalGroups;
    component.educationGroups = educationGroups;

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.personalGroups).not.toBeUndefined();
    expect(component.educationGroups).not.toBeUndefined();
  })

});
