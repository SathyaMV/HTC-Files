import { Component, OnInit } from '@angular/core';
import { BffService } from '../../providers/bff.service';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css']
})
export class OverviewComponent implements OnInit {
  myEventDetails: any;
  myStudentDetails: any;
  attendedStatus: any;
  eventRegisteredStudent: any;
  eventParticipatedStudent: any = [];
  data: any;
  eventRegisteredCount: any;
  eventParticipatedCount: any;
  eventId:any;
  studentDetailsAvailable = false;
  showLoadingIcon:boolean = true;
  eventInformationPage = [];

  constructor(private bff: BffService,private route: ActivatedRoute) { }

  ngOnInit(): void {
  // this.showLoadingIcon  = true
    this.route.queryParams.subscribe(params=>{
      if(params.eventCode){
        this.eventId = params.eventCode
        this.setEventCode(this.eventId)
      }   
    })
    this.getEventOverviewDetail(); 
  }

//Getting event overview page data by calling getEventOverview API
 getEventOverviewDetail(){
  let inPayLoad = 'cventCode=' + this.eventId
    this.bff.getEventsOverviewPageDetails(inPayLoad).subscribe(data=>{
      this.showLoadingIcon = data.eventOverviewDetails.hasOwnProperty('idpEventDetails') ? false : true;
      this.eventInformationPage = data; 
      this.showLoadingIcon = false;
      this.setEventDetails(data.eventOverviewDetails.idpEventDetails)
    })
  }

  setEventCode(eventCode){
    sessionStorage.setItem('eventCode_' +  sessionStorage.getItem('tabID'), eventCode )
  }

  setEventDetails(data){
    sessionStorage.setItem('eventDetails_'+this.eventId,JSON.stringify(data))
  }
}