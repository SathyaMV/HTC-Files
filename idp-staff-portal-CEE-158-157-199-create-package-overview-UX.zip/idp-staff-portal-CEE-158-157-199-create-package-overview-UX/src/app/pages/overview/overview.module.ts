import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OverviewComponent } from './overview.component';
import { RouterModule, Routes } from '@angular/router';
import { OverviewTableComponent } from 'src/app/common/component/overview-table/overview-table.component';
import { GenerateEventQrCodeComponent } from 'src/app/common/generate-event-qr-code/generate-event-qr-code.component';
import { BulkUploadComponent } from 'src/app/common/component/bulk-upload/bulk-upload.component';
import { BulkUploadTableComponent } from 'src/app/common/component/bulk-upload-table/bulk-upload-table.component';
import { EventParticipantsComponent } from 'src/app/common/component/event-participants/event-participants.component';
import { MatTabsModule } from '@angular/material/tabs';
import { ZXingScannerModule } from '@zxing/ngx-scanner';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { EventRegistrationsComponent } from 'src/app/common/component/event-registrations/event-registrations.component';
import { MatSelectModule } from '@angular/material/select';
import { NgxPaginationModule } from 'ngx-pagination';
import { PipeModule } from 'src/app/common/pipe/pipe.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { OverviewReportsModule } from 'src/app/common/component/overview-reports/overview-reports.module';
import { ManualEntryRegistrationFormModule } from 'src/app/common/component/manual-entry-registration-form/manual-entry-registration-form.module';
import { CheckInStaffModule } from 'src/app/common/component/checkin-staff/checkin-staff.module';
import { QRCodeModule } from 'angularx-qrcode';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { BulkUploadSurveyQuestionComponent } from 'src/app/common/component/bulk-upload-survey-question/bulk-upload-survey-question.component';
import { MatRadioModule } from '@angular/material/radio';

const routes: Routes = [
  {path:'', component:OverviewComponent}
];

@NgModule({
  declarations: [
    OverviewComponent,
    OverviewTableComponent,
    GenerateEventQrCodeComponent,
    BulkUploadComponent,
    BulkUploadTableComponent,
    EventParticipantsComponent,
    EventRegistrationsComponent,
    BulkUploadSurveyQuestionComponent
  ],
  imports: [
    CdkAccordionModule,
    CommonModule,
    ClipboardModule,
    CheckInStaffModule,
    LoaderIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatTabsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatRadioModule,
    NgxPaginationModule,
    PipeModule,
    FormsModule,
    QRCodeModule,
    ReactiveFormsModule,
    ZXingScannerModule,
    OverviewReportsModule,
    ManualEntryRegistrationFormModule,
    RouterModule.forChild(routes),
  ],
  exports: [
    BulkUploadSurveyQuestionComponent
  ]
})
export class OverviewModule { }
