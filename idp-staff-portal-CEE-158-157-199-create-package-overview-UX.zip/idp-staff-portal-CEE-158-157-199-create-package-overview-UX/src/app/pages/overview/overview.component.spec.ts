import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { BffService } from '../../providers/bff.service';
import { OverviewComponent } from './overview.component';

describe('OverviewComponent', () => {
  let component: OverviewComponent;
  let fixture: ComponentFixture<OverviewComponent>;
  let service: BffService;
  const eventInformationPage  = [{test:'testName'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverviewComponent ],
      imports: [RouterTestingModule, HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
    fixture = TestBed.createComponent(OverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventInformationPage = eventInformationPage
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventInformationPage).not.toBeUndefined();
  })
});
