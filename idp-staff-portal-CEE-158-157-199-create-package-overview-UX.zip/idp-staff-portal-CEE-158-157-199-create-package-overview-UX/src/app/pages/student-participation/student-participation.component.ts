import { Component } from '@angular/core';

@Component({
  selector: 'app-student-participation',
  templateUrl: './student-participation.component.html',
  styleUrls: ['./student-participation.component.css']
})
export class StudentParticipationComponent { }
