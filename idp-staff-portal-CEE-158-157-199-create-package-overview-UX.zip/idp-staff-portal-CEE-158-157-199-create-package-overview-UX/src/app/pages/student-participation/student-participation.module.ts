import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentParticipationComponent } from './student-participation.component';
import { RouterModule, Routes } from '@angular/router';
import { SideNavModule } from 'src/app/common/component/side-nav/side-nav.module';
import { StudentParticipationTableComponent } from 'src/app/common/component/student-participation-table/student-participation-table.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatSortModule } from '@angular/material/sort';
import { HeaderModule } from 'src/app/common/component/header/header.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  },
};

const routes: Routes = [
  {path:'', component:StudentParticipationComponent}
];

@NgModule({
  declarations: [
    StudentParticipationComponent,
    StudentParticipationTableComponent
  ],
  imports: [
    CommonModule,
    SideNavModule,
    HeaderModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule,
    LoaderIconModule,
    MatDatepickerModule,
    RouterModule.forChild(routes),
  ],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ]
})
export class StudentParticipationModule { }
