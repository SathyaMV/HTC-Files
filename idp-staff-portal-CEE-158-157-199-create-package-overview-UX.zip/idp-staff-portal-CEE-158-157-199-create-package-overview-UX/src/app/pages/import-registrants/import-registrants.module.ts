import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportRegistrantsComponent } from './import-registrants.component';
import { SideNavModule } from 'src/app/common/component/side-nav/side-nav.module';
import { RegistrantsTableComponent } from 'src/app/common/component/registrants-table/registrants-table.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { DateAdapter, MatOptionModule, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RouterModule, Routes } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatSortModule } from '@angular/material/sort';
import { MatTableModule } from '@angular/material/table';
import { NgxPaginationModule } from 'ngx-pagination';
import { AuditLogComponent } from 'src/app/common/component/audit-log/audit-log.component';
import { HeaderModule } from 'src/app/common/component/header/header.module';
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module';

import { MatDatepickerModule } from '@angular/material/datepicker';
import { MomentDateAdapter } from '@angular/material-moment-adapter';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  },
};

const routes: Routes = [
  { path: '', component: ImportRegistrantsComponent }
];

@NgModule({
  declarations: [
    ImportRegistrantsComponent,
    RegistrantsTableComponent,
    AuditLogComponent
  ],
  imports: [
    CommonModule,
    SideNavModule,
    FormsModule,
    HeaderModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    NgxPaginationModule,
    LoaderIconModule,
    MatDatepickerModule,
    RouterModule.forChild(routes),
  ],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ]
})
export class ImportRegistrantsModule { }
