import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportRegistrantsComponent } from './import-registrants.component';

describe('ImportRegistrantsComponent', () => {
  let component: ImportRegistrantsComponent;
  let fixture: ComponentFixture<ImportRegistrantsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportRegistrantsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportRegistrantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
