import { Component } from '@angular/core';

@Component({
  selector: 'app-import-registrants',
  templateUrl: './import-registrants.component.html',
  styleUrls: ['./import-registrants.component.css']
})
export class ImportRegistrantsComponent { }
