import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserManagementComponent } from './user-management.component';
import { HeaderModule } from 'src/app/common/component/header/header.module';
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatSelectModule } from '@angular/material/select';
import { ReactiveFormsModule } from '@angular/forms';
import { SideNavModule } from 'src/app/common/component/side-nav/side-nav.module';
import { MatInputModule } from '@angular/material/input';

const routes: Routes = [
  {path:'', component:UserManagementComponent}
];

@NgModule({
  declarations: [
    UserManagementComponent
  ],
  imports: [
    CommonModule,
    HeaderModule,
    LoaderIconModule,
    MatInputModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatOptionModule,
    MatSelectModule,
    NgxPaginationModule,
    ReactiveFormsModule,
    SideNavModule,
    RouterModule.forChild(routes),
  ]
})
export class UserManagementModule { }
