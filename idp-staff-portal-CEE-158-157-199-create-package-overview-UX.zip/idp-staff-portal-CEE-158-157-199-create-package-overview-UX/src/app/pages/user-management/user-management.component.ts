import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { BffService } from 'src/app/providers/bff.service';

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  myControl = new FormControl('');
  options: string[] = [];
  filteredOptions!: Observable<string[]>;
  userListArray  = []
  upcomingPageNumber = 1
  searchtype = new FormControl('email')
  searchType = 'email'
  displayUserListArray = []
  showLoaderIcon = true;
  initialValue: number = 1;
  itemsPerpage: number = 10;
  lastValue: number = this.itemsPerpage;

  constructor(private bff :BffService, private router:Router) { }

  ngOnInit(): void {

    this.getUserList()

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
    this.filteredOptions.subscribe(() => {
      this.paginationValue(this.upcomingPageNumber, this.displayUserListArray.length);
    })

    //Redirecting to landing page, if user don't have access
    this.bff.userPermission.subscribe(data=>{
      if(!data['userAccess'].canManageAccess){
        this.router.navigateByUrl('idp-staff-portal/events-dashboard')
      }
    })
  }
  private _filter(value: string): string[] {
    if(value.length >= 3){
      this.displayUserListArray = []
      const filterValue = value.toLowerCase();
      if(this.searchType == 'email'){
        this.options = []
        this.userListArray.forEach(ele=>{
          if(ele.email?.toLowerCase().includes(filterValue)){
            this.displayUserListArray.push(ele)
            this.options.push(ele.email)
          }
        })
        return this.options
      }
      if(this.searchType == 'name'){
        const name = filterValue.trim().split(' ')
        if(name.length == 1){
          this.options = []
          this.userListArray.forEach(ele=>{
            if(ele.firstName?.toLowerCase().includes(name[0].toLowerCase()) || ele.lastName?.toLowerCase().includes(name[0].toLowerCase())){
              this.displayUserListArray.push(ele)
              this.options.push(ele.firstName +' '+ ele.lastName)
            }
          })
          return this.options
        }else if(name.length == 2){
          this.options = []
          this.userListArray.forEach(ele=>{
            if(ele.firstName?.toLowerCase().includes(name[0].toLowerCase()) && ele.lastName?.toLowerCase().includes(name[1].toLowerCase())){
              this.displayUserListArray.push(ele)
              this.options.push(ele.firstName +' '+ ele.lastName)
            }
          })
          return this.options
        }
      }
    }else{
      this.displayUserListArray = this.userListArray
    }
    this.upcomingPageNumber = 1
  }

  getUserList(){
    this.bff.getUserList().subscribe(res=>{
      this.userListArray = res.staffDetails
      this.displayUserListArray = this.userListArray
      this.showLoaderIcon = false
      this.paginationValue(this.upcomingPageNumber, this.displayUserListArray.length)
      // console.log(res.staffDetails,'res', typeof res.staffDetails)
    })
  }

  searchTypeDropDown(type){
    this.searchType = type;
    this.myControl.setValue('');
  }

  scrollTop() {
    document.getElementById('listTop').scrollIntoView({ behavior: "smooth" });
  }

  paginationValue(event, count) {
    this.initialValue = ((event-1)*this.itemsPerpage)+1;
    this.lastValue = event*this.itemsPerpage > count ? count : event*this.itemsPerpage;
  }

  userProfile(id){
    this.router.navigate(['idp-staff-portal/user-profile'],
    {
      queryParams: {
      'id':id
      }
    })
  }
}
