import { ComponentFixture, TestBed } from '@angular/core/testing'
import { HttpClientModule } from '@angular/common/http'
import { of } from 'rxjs'
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { StudentEventComponent } from './student-event.component'

describe('StudentEventComponent', () => {
  let component: StudentEventComponent
  let fixture: ComponentFixture<StudentEventComponent>
  let service: SimBbfService
  let MockService: any
  beforeEach(async () => {
    MockService = {
      getStudentEventTabList: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [StudentEventComponent],
      imports: [HttpClientModule],
      providers: [{ provide: SimBbfService, useClass: SimBbfService }]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentEventComponent)
    service = TestBed.inject(SimBbfService)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })

  it('should call tabs method', () => {
    const fixture = TestBed.createComponent(StudentEventComponent)
    const app = fixture.componentInstance
    app.tabs()
  })

  it('should return event getStudentEventTabList', async () => {
    const expectRes = {
      data: [
        {
          id: 'student-event-overview',
          tabname: 'Event Overview',
          display: true
        },
        {
          id: 'event-details',
          tabname: 'Event Details',
          display: true
        },
        {
          id: 'design-event',
          tabname: 'Design Event',
          display: true
        }
      ]
    }
    jest.spyOn(service, 'getStudentEventTabList').mockReturnValue(of(expectRes))
    component.tabs()
    expect(component.tabList).toEqual(expectRes.data)
  })
})
