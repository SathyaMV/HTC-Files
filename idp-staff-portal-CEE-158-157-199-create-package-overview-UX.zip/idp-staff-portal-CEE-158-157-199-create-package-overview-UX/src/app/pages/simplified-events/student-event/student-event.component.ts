/*
 * Creates an student event page
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-student-event',
  templateUrl: './student-event.component.html',
  styleUrls: ['./student-event.component.css']
})
export class StudentEventComponent implements OnInit {
  tabList: any[] = []
  eventType: string
  eventCategory: string
  selectedTab = ''
  subscriptions = new Subscription()
  constructor (private readonly bbfService: SimBbfService) {
  //
    this.tabs()
  }

  ngOnInit (): void {
  }

  /**
   * @function tabs
   * @todo Fetch tabs from JSON file
   */
  tabs (): void {
    this.subscriptions.add(
      this.bbfService.getStudentEventTabList().subscribe((res: any) => {
        this.tabList = res?.data
        this.modifyTabList()
      })
    )
  }

  /**
   * @function modifyTabList
   * @todo Modify tabs based on event type selection
   */
  modifyTabList (): void {
    this.subscriptions.add(
      this.bbfService.eventData.subscribe(res => {
        const type = res.type
        if (type.length > 0) {
          sessionStorage.setItem('eventType', res.type)
          sessionStorage.setItem('eventCategory', res.category)
        } else {
          sessionStorage.setItem('eventType', sessionStorage.getItem('eventTypeName'))
          sessionStorage.setItem('eventCategory', sessionStorage.getItem('eventCategoryName'))
          this.bbfService.eventData.next({
            ...this.bbfService.eventData.value,
            type: sessionStorage.getItem('eventTypeName'),
            category: sessionStorage.getItem('eventCategoryName'),
            typeId: sessionStorage.getItem('eventTypeId'),
            categoryId: sessionStorage.getItem('eventCategoryId'),
            classificationId: sessionStorage.getItem('studentEventId')
          })
        }

        this.eventType = sessionStorage.getItem('eventType')
        this.eventCategory = sessionStorage.getItem('eventCategory')
        const display = this.eventType === 'Hybrid'
        this.tabList.map((result: any) => {
          if (result.id === 'physical-event-details' || result.id === 'virtual-event-details') {
            result.display = display
          } else if (result.id === 'event-details') {
            result.display = !display
          } else {
            result.display = true
          }
          return result
        })
      }))
  }

  /**
   * @function onTabChanged
   * @todo hold selected tab id
   */
  onTabChanged (event: any): void {
    // this.selectedTab = this.tabList[event.index].id
    // this.tabList.filter((e) => { e.id === event.tab.textLabel })

    const dd = this.tabList.filter((x: any) => (x.tabname === event.tab.textLabel))
    this.selectedTab = dd[0].id
    this.bbfService.sEventSave.next({ ...this.bbfService.sEventSave.value, currentTab: this.selectedTab })
    sessionStorage.setItem('sEvent_selectedTab', this.selectedTab)
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
