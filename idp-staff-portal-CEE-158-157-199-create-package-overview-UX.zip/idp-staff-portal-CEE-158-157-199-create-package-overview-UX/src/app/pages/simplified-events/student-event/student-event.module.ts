import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatTabsModule } from '@angular/material/tabs'
import { StudentEventComponent } from './student-event.component'
import { StudentEventRoutingModule } from './student-event-routing.module'
import { SimHeaderModule } from '../../../common/component/simEventComponents/SimHeader/sim-header.module'
import { StudentEventHeaderModule } from 'src/app/common/component/simEventComponents/student-event-header/student-event-header.module'
import { EventInfoModule } from '../../../common/component/simEventComponents/event-info/event-info.module'
import { StudentEventOverviewModule } from '../../../common/component/simEventComponents/student-event-overview/student-event-overview.module'
import { EventDetailsModule } from '../../../common/component/simEventComponents/event-details/event-details.module'
import { PhysicalEventDetailsModule } from '../../../common/component/simEventComponents/physical-event-details/physical-event-details.module'
import { VirtualEventDetailsModule } from '../../../common/component/simEventComponents/virtual-event-details/virtual-event-details.module'
import { StudentRegistrationFormModule } from 'src/app/common/component/simEventComponents/student-registration-form/student-registration-form.module'

@NgModule({

  declarations: [StudentEventComponent],
  exports: [],
  imports: [
    CommonModule,
    MatTabsModule,
    StudentEventRoutingModule,
    SimHeaderModule,
    StudentEventHeaderModule,
    EventInfoModule,
    StudentEventOverviewModule,
    EventDetailsModule,
    PhysicalEventDetailsModule,
    VirtualEventDetailsModule,
    StudentRegistrationFormModule
    
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class StudentEventModule { }
