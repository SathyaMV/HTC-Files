import { ComponentFixture, TestBed } from '@angular/core/testing'
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { EventTypeComponent } from './event-type.component'

describe('EventTypeComponent', () => {
  let component: EventTypeComponent
  let fixture: ComponentFixture<EventTypeComponent>
  let service: SimBbfService
  let MockService: any

  beforeEach(async () => {
    MockService = {
      getEventType: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [EventTypeComponent],
      imports: [HttpClientModule, RouterTestingModule],
      providers: [{ provide: SimBbfService, useClass: SimBbfService }]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(EventTypeComponent)
    service = TestBed.inject(SimBbfService)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })

  it('should return event getMasterEventId', async () => {
    const expectRes = [
      {
        id: 'ff0c7258-4a67-448a-aeff-c08f931441e2',
        name: 'Physical Event',
        description: 'A physical event takes place in person for all those who are attending the event.',
        icon: 'home_work',
        eventCategories: [
          {
            id: '98a12c40-25b7-41d4-a356-3a030eeabc7a',
            name: 'Seminar',
            description: 'An information session designed to deliver key insights to students about studying abroad. Can be IDP hosted or held in conjunction with an IDP partner.'
          },
          {
            id: '2859c07c-b7b7-4804-bf04-8051b87b79e5',
            name: 'Pre Departure',
            description: 'IDP hosted event for students before they move to their study destination.'
          },
          {
            id: '8f8afa18-588e-48e9-b86b-8768cc754070',
            name: 'IELTS Events',
            description: 'An IELTS event is conducted to deliver any information session to students on taking an IELTS exams.'
          },
          {
            id: '7035313a-8537-4d51-a197-5d036921e72f',
            name: 'Student Essential Events',
            description: 'An SES information session.'
          },
          {
            id: '1e33564c-7533-4277-87c2-35ac311d09f6',
            name: 'On Arrival',
            description: 'An on-arrival events is conducted for students who have arrived in their destination country.'
          },
          {
            id: '717b8fe7-d7a4-4f2c-a9e8-6089ff2c5584',
            name: 'Student Engagement Event',
            description: 'A social event or community building activity held for students.'
          },
          {
            id: '218a99f9-53c0-429d-8714-aa153de98c71',
            name: 'Local Institution Visit',
            description: 'For events where IDP staff visit schools, colleges or universities to attract new students.'
          }
        ]
      }
    ]
    jest.spyOn(service, 'getMasterEventId').mockReturnValue(of(expectRes))
    component.getEventTypesList()
    component.getIcon('Physical Event')
    expect(component.iconName).toEqual('home_work')
    expect(component.eventTypes).toBeDefined()
  })
})
