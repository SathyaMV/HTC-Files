/**
 * Creates an event type and category page
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { Subscription } from 'rxjs'
import { SimBbfService } from '../../../providers/sim-bbf.service'

@Component({
  selector: 'app-event-type',
  templateUrl: './event-type.component.html',
  styleUrls: ['./event-type.component.css']
})
export class EventTypeComponent implements OnInit {
  eventTypes: any = []
  iconName: any
  studentTypeData: any
  subscriptions = new Subscription()
  showLoaderIcon: boolean = false
  typesData: any = [
    { name: 'Physical Event', icon: 'home_work' },
    { name: 'Virtual Event', icon: 'computer' },
    { name: 'Hybrid Event', icon: 'co_present' },
    { name: 'Webinar', icon: 'video_camera_front' }
  ]

  constructor (private readonly service: SimBbfService) {
  }

  ngOnInit (): void {
    sessionStorage.setItem('eventTypeId', '')
    sessionStorage.setItem('eventType', '')
    sessionStorage.setItem('eventCategoryId', '')
    sessionStorage.setItem('eventCategory', '')
    this.getEventTypesList()
  }

  /**
   * @function getIcon
   * @todo Fetching icon related to event type name
   */

  getIcon (name: any): any {
    this.typesData.filter((x: any) => {
      if (x.name === name) {
        this.iconName = x.icon
      }
    })
    return this.iconName
  }

  /**
   * @function getEventTypeCategoryList
   * @todo Calling eventTypeCategory API call
   */

  getEventTypesList (): void {
    this.showLoaderIcon = true
    this.subscriptions.add(this.service.eventTypeData.subscribe(res => {
      this.showLoaderIcon = false
      this.studentTypeData = res.eventTypeCategory
      if (this.studentTypeData.length > 0) {
        this.eventTypes = this.studentTypeData.map((map: any) => {
          return {
            id: map.id,
            name: map.name,
            description: map.description,
            icon: this.getIcon(map.name),
            eventCategories: map.eventCategories
          }
        })
      } else {
        this.service.eventTypeData.next({ eventTypeCategory: JSON.parse(sessionStorage.getItem('studentTypeList')) })
      }
    }))
  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
