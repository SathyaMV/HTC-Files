import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { EventTypeComponent } from './event-type.component'
import { MatCardModule } from '@angular/material/card'
import { EventTypeRoutingModule } from './event-type-routing.module'
import { SimHeaderModule } from 'src/app/common/component/simEventComponents/SimHeader/sim-header.module'
import { EventTypeCategoryComponent } from 'src/app/common/component/simEventComponents/event-type-category/event-type-category.component'
import { EventInfoModule } from 'src/app/common/component/simEventComponents/event-info/event-info.module'
import { StudentEventHeaderModule } from 'src/app/common/component/simEventComponents/student-event-header/student-event-header.module'
import { LoaderIconModule } from 'src/app/common/component/loader-icon/loader-icon.module'
@NgModule({
  declarations: [EventTypeComponent, EventTypeCategoryComponent],
  imports: [
    CommonModule,
    MatCardModule,
    SimHeaderModule,
    EventInfoModule,
    StudentEventHeaderModule,
    LoaderIconModule,
    EventTypeRoutingModule
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EventTypeModule {
}
