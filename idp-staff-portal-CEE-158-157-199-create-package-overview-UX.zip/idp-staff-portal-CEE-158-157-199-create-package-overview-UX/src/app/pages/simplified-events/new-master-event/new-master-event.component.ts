/*
 * Creates a New master event page
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router'
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-new-master-event',
  templateUrl: './new-master-event.component.html',
  styleUrls: ['./new-master-event.component.css']
})
export class NewMasterEventComponent implements OnInit {
  subscriptions = new Subscription()
  showloaderIcon: boolean = false
  constructor (private readonly http: HttpClient, private readonly router: Router,
    private readonly bbfService: SimBbfService) { }

  masterEvents: any = {}
  tabList: any = []

  ngOnInit (): void {
    this.getMasterEventId()
    this.tabs()
  }

  /**
   * @function getMasterEventId - get master event id from masterEvents.api */
  getMasterEventId (): void {
    this.showloaderIcon = true
    const eventParam = { eventClassificationId: sessionStorage.getItem('MasterEventId') }
    this.subscriptions.add(this.bbfService.getMasterEventId(eventParam).subscribe((res: any) => {
      this.showloaderIcon = false
      if (res.status === 'success') {
        this.masterEvents = res?.result
      }
    }))
  }

  /**
   * @function tabs
   * @todo Fetch tabs from JSON file
   */
  tabs (): void {
    this.subscriptions.add(this.bbfService.getTabList().subscribe((res: any) => {
      this.tabList = res?.data
    }))
  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
