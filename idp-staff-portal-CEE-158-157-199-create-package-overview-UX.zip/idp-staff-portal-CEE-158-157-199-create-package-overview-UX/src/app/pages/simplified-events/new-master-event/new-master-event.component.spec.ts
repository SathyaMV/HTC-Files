import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { NewMasterEventComponent } from './new-master-event.component';

describe('NewMasterEventComponent', () => {
  let component: NewMasterEventComponent;
  let fixture: ComponentFixture<NewMasterEventComponent>;
  let service: SimBbfService;
  let MockService: any;

  beforeEach(async () => {
    MockService = {
      getMasterEventId: jest.fn(),
      getTabList: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [ NewMasterEventComponent ],
      imports: [HttpClientModule, RouterTestingModule],
      providers:[{provide: SimBbfService, useClass: SimBbfService}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewMasterEventComponent);
    service= TestBed.inject(SimBbfService)
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return event getMasterEventId', async () => {
    const expectRes = {
      status: 'success',
      statusCode: 201,
      body: {
        masterEvent: {
          id: '3b5ac80b-514d-451d-aa28-0bab7e09f8c7',
          eventCode: '7F2RX1TOBIZ'
        },
        message: 'A master event has been created successfully.'
      }
    }
    jest.spyOn(service, 'getMasterEventId').mockReturnValue(of(expectRes))
    component.getMasterEventId()
    expect(component.masterEvents).toEqual(expectRes.body)
  })

  it('should return event getTabList', async () => {
    const expectRes = {
      'data': [
          {
              'id': 'eventOverview',
              'tabname': 'Event Overview',
              'disabled': false
          },
          {
              'id': 'idpContacts',
              'tabname': 'IDP Contacts',
              'disabled': false
          },
          {
              'id': 'attachments',
              'tabname': 'Attachments',
              'disabled': false
          },
          {
              'id': 'events',
              'tabname': 'Events',
              'disabled': false
          }
      ]
  }
    jest.spyOn(service, 'getTabList').mockReturnValue(of(expectRes))
    component.tabs()
    expect(component.tabList).toEqual(expectRes.data)
  })
});
