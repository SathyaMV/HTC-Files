import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewMasterEventComponent } from './new-master-event.component'

const routes: Routes = [
  { path: '', component: NewMasterEventComponent }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewMasterEventRoutingModule { }
