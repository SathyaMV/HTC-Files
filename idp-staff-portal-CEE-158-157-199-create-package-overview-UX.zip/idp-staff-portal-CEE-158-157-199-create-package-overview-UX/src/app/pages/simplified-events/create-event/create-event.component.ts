/**
 * Creates an event classification page
 * @class
 */

import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { MatDialog } from '@angular/material/dialog'
import { Subscription } from 'rxjs'
import { simConstants } from '../../../common/utilities/sim-constants'
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { ErrorHandlingDialogComponent } from '../../../common/component/simEventComponents/errorHandling/error-handling.component'
import { LangTranslateService } from '../../../providers/lang-translate.service'

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})

export class CreateEventComponent implements OnInit {
  showLoaderIcon: boolean = false
  eventTypes: any = []
  studentTypeList: any
  menuList = []
  subscriptions = new Subscription()
  errorMsg: any
  /**
 * @constructs CreateEventComponent
 * @param bbfService - Service File to handle api request
 * @param router - Router instance to call routing url
 */
  constructor (private readonly bbfService: SimBbfService, private readonly router: Router, public dialog: MatDialog,
    private readonly langTranslateService: LangTranslateService) {
  }

  ngOnInit (): void {
    this.getEventClassification()
  }

  /** @function getEventClassification - call api and fill the json with relevant events */
  getEventClassification (): void {
    this.showLoaderIcon = true
    this.subscriptions.add(this.bbfService.getEventClassifications().subscribe((res) => {
      this.showLoaderIcon = false
      if (res?.statusCode === 200) {
        this.eventTypes = res.result.eventClassifications.map((map: any) => {
          if (map.name === 'Student Event') {
            this.studentTypeList = map.eventTypes
            sessionStorage.setItem('studentTypeList', JSON.stringify(map.eventTypes))
          }
          return {
            id: map.id,
            name: (map.name === 'Student Event') ? 'stud_event' : 'client_stud',
            describe: (map.name === 'Student Event') ? 'only_stud' : 'client_Stud_only',
            iconName: (map.name === 'Student Event') ? 'person' : 'people',
            eventType: map.eventTypes
          }
        })
        this.bbfService.eventTypeData.next({ ...this.bbfService.eventTypeData.value, eventTypeCategory: this.studentTypeList })
      } else {
        this.errorHandling(res.result?.message)
      }
    }))
  }

  /** @function loadStudentEvent - load student event page */
  loadStudentEvent (): void {
    this.router.navigateByUrl(simConstants.routingUrl.EventType)
  }

  /** @function loadNewMasterEvent - load new master event page */
  loadNewMasterEvent (): void {
    this.router.navigateByUrl(simConstants.routingUrl.newMasterEvent)
  }

  /** @function loadNewEvent - call routing url based on event name
   * @param type - to get the selected event type data
   */
  loadNewEvent (type: any): void {
    if (type.name === 'stud_event') {
      sessionStorage.setItem('studentEventId', type.id)
      this.bbfService.eventData.next({ ...this.bbfService.eventData.value, classificationId: type.id })
      this.loadStudentEvent()
    } else if (type.name === 'client_stud' && type.status === 'active') {
      sessionStorage.setItem('MasterEventId', type.id)
      this.bbfService.eventData.next({ ...this.bbfService.eventData.value, classificationId: type.id })
      this.loadNewMasterEvent()
    }
  }

  /**
   * @function errorHandling
   * @todo Http Error Handling
  */
  errorHandling (message: string): void {
    const dialogRef = this.dialog.open(ErrorHandlingDialogComponent, {
      data: { title: 'Technical Error', content: message, agree: 'Ok' }
    })
    dialogRef.afterClosed()
  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
