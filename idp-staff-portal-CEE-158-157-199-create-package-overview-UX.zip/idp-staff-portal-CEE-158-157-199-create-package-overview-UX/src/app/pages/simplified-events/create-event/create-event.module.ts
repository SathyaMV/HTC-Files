import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatDialogModule } from '@angular/material/dialog'
import { CreateEventComponent } from './create-event.component'
import { MatCardModule } from '@angular/material/card'
import { LoaderIconModule } from '../../../common/component/loader-icon/loader-icon.module'
import { SimHeaderModule } from '../../../common/component/simEventComponents/SimHeader/sim-header.module'
import { CreateEventRoutingModule } from './create-event-routing.module'
import { TranslateModule } from '@ngx-translate/core'

@NgModule({
  declarations: [CreateEventComponent],
  imports: [
    CommonModule,
    MatCardModule,
    SimHeaderModule,
    CreateEventRoutingModule,
    MatDialogModule, LoaderIconModule, TranslateModule
  ],
  providers: []
})
export class CreateEventModule { }
