import { ComponentFixture, TestBed } from '@angular/core/testing'
import { SimBbfService } from '../../../providers/sim-bbf.service'
import { CreateEventComponent } from './create-event.component'
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { RouterTestingModule } from '@angular/router/testing'
import { MatCardModule } from '@angular/material/card'
import { SimHeaderComponent } from '../../../common/component/simEventComponents/SimHeader/sim-header.component'
import { NewMasterEventComponent } from '../new-master-event/new-master-event.component'
import { Router } from '@angular/router'
import { simConstants } from '../../../common/utilities/sim-constants'
import { of } from 'rxjs'
import { MatDialogModule } from '@angular/material/dialog'
import { EventTypeCategoryComponent } from '../../../common/component/simEventComponents/event-type-category/event-type-category.component'
import { TranslateModule } from '@ngx-translate/core'
import { LoaderIconModule } from '../../../common/component/loader-icon/loader-icon.module'

describe('CreateEventComponent', () => {
  let component: CreateEventComponent
  let fixture: ComponentFixture<CreateEventComponent>
  let router: Router
  let service: SimBbfService
  let MockService: any

  beforeEach(async () => {
    MockService = {
      getEventClassificationList: jest.fn(),
      getEventClassifications: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [CreateEventComponent, SimHeaderComponent],
      imports: [HttpClientTestingModule, MatDialogModule, TranslateModule.forRoot(), LoaderIconModule,
        RouterTestingModule.withRoutes([
          { path: 'idp-staff-portal/event-type', component: EventTypeCategoryComponent },
          { path: 'idp-staff-portal/new-master-event', component: NewMasterEventComponent }
        ]), MatCardModule],
      providers: [
        { provide: 'SimBbfService', useValue: MockService }]

    }).compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateEventComponent)
    service = TestBed.inject(SimBbfService)
    router = TestBed.inject(Router)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should return event getEventClassificationList', async () => {
    const expectRes = {
      menu: [
        { name: 'Student Event' }, {
          name: 'Client Student Event'
        }
      ]
    }
    jest.spyOn(service, 'getEventClassificationList').mockReturnValue(of(expectRes))
    // component.getClassificationList()
    expect(component.eventTypes.length).toBeGreaterThan(0)
  })

  it('should fail on return event getEventClassificationList', async () => {
    const expectRes = {
      menu: []
    }
    jest.spyOn(service, 'getEventClassificationList').mockReturnValue(of(expectRes))
    // component.getClassificationList()
    expect(component.eventTypes.length).toBeLessThanOrEqual(0)
  })

  it('should return event getEventClassification with classification', async () => {
    const expectRes = {
      statusMessage: 'A list of the event classifications.',
      statusCode: 200,
      result: {
        eventClassifications: [{
          id: 'dbf66a8f-3a0d-4cdd-b622-d619f437405a',
          name: 'Student Event',
          description: 'This event will only be attended by students',
          status: 'active'
        }, {
          id: 'e5163f9b-55d5-487a-9c9e-3dfcbebc1a5e',
          name: 'Client Student Event',
          description: 'This event will only be attended by students and clients',
          status: 'active'
        }]
      }
    }
    component.eventTypes = [{ name: 'Student Event' }, {
      name: 'Client Student Event'
    }]
    jest.spyOn(service, 'getEventClassifications').mockReturnValue(of(expectRes))
    component.getEventClassification()
    expect(component.menuList.length).toBeGreaterThan(0)
  })

  it('should return event getEventClassification with empty data', async () => {
    const expectRes = {
      statusMessage: 'A list of the event classifications.',
      statusCode: 200,
      result: {
        eventClassifications: []
      }
    }
    component.eventTypes = [{ name: 'Student Event' }, {
      name: 'Client Student Event'
    }]
    jest.spyOn(service, 'getEventClassifications').mockReturnValue(of(expectRes))
    component.getEventClassification()
    expect(component.menuList.length).toEqual(0)
  })

  it('student event navigation test', () => {
    const spy = jest.spyOn(router, 'navigateByUrl')
    component.loadStudentEvent()
    expect(spy).toHaveBeenCalledWith(simConstants.routingUrl.EventType)
  })

  it('new master event navigation test', () => {
    const spy = jest.spyOn(router, 'navigateByUrl')
    component.loadNewMasterEvent()
    expect(spy).toHaveBeenCalledWith(simConstants.routingUrl.newMasterEvent)
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
