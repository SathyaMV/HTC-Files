import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BffService } from '../../providers/bff.service';
import { DashboardComponent } from './dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let service: BffService;
  const eventListPageData = [{test:'testname'}];
  const upcomingEvents = [{event : 'virtual'}]
  const pastEvents = [{event : 'webinar'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      imports: [HttpClientModule, RouterTestingModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventListPageData = eventListPageData;
    component.upcomingEventsData = upcomingEvents;
    component.pastEventsData = pastEvents;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventListPageData).not.toBeUndefined();
    expect(component.upcomingEventsData).not.toBeUndefined();
    expect(component.pastEventsData).not.toBeUndefined();
  })
});
