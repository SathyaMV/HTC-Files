import { Component, OnInit } from '@angular/core';
import { Auth } from 'aws-amplify';
import { environment } from 'src/environments/environment';
import { constants } from '../../common/utilities/constants'
import { BffService } from '../../providers/bff.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  upcomingEventsData = []
  pastEventsData = []
  eventListPageData = []
  showloaderIcon = true;
  emailId = ''
  constructor(private bff : BffService) {
   
   }

  ngOnInit(): void {
    if(environment.enableAutentication){
      Auth.currentAuthenticatedUser().then(user=>{
        this.emailId = user.attributes.email
        this.dashBoardData();
      })
    }else{
      this.emailId = environment.authenticationEmail
      this.dashBoardData();
    }    
  }

  dashBoardData(){
    this.bff.getEventsListPageDetails(this.emailId).subscribe(data=>{
      this.eventListPageData = data;
      if(this.eventListPageData['message'] == "No Event records found for the country"){
        this.showloaderIcon = false;
      }
      this.upcomingEventsData = data?.idpEvents?.upcoming;
      this.pastEventsData = data.idpEvents.past;  
      let currentDate = new Date() //'2022-07-31'
      if(this.upcomingEventsData != undefined && this.upcomingEventsData != null ){
        this.upcomingEventsData.forEach(ele=>{
          if (currentDate >= new Date(ele.startDate) && currentDate <= new Date(ele.endDate)) {
            ele.liveEvent = true;
          }
        })
      } 
      if(this.pastEventsData != undefined && this.pastEventsData != null){
        this.pastEventsData.forEach(ele=>{
          if (currentDate >= new Date(ele.startDate) && currentDate <= new Date(ele.endDate)) {
            ele.liveEvent = true;
          }
        })
      }     
      this.showloaderIcon = false;
     })
  }

}
