import { Component, OnInit, ViewChild } from '@angular/core';
import { map, Observable, startWith } from 'rxjs';
import { BffService } from 'src/app/providers/bff.service';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Auth } from 'aws-amplify';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  rolesArray = []
  countryListArray = []
  userProfile = []
  filteredOptions!: Observable<string[]>
  myControl = new FormControl('')
  role = new FormControl('')
  selectedCountryArray = []
  id
  fullName = new FormControl('')
  showSuccess:boolean = false
  countryError:boolean = false
  showLoaderIcon:boolean = true
  emailId = ''
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;

  constructor(private bff: BffService, private route: ActivatedRoute,private router: Router) { 
    Auth.currentAuthenticatedUser().then(user=>{
      this.emailId = user.attributes.email
    })
  }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''), map(value => this._filterMyControl(value || '')),
    );

    this.route.queryParams.subscribe(params => {
      this.id = params.id;
      this.getUserInformation()
    });

    //Redirecting to landing page, if user don't have access
    this.bff.userPermission.subscribe(data=>{
      if(!data['userAccess'].canManageAccess){
        this.router.navigateByUrl('idp-staff-portal/events-dashboard')
      }
    })
  }


  private _filterMyControl(value: string): string[] {
    const filterValue = value.toLowerCase();
    let typeMatchArray = []
    if(filterValue.length >= 3){
      this.countryListArray.forEach(ele=>{
        if(ele.name.toLowerCase().includes(filterValue)){
          typeMatchArray.push(ele)
        }
      })
      return typeMatchArray
    }
  }

  getUserInformation() {
    this.bff.getStaffProfile(this.id,this.emailId).subscribe(res => {
      this.rolesArray = res?.roleDetails
      this.countryListArray = res?.countryList
      this.userProfile = Object.assign(this.userProfile, res?.userProfile)
      if(res?.userProfile?.supportedCountries){
        this.selectedCountryArray = this.selectedCountryArray.concat(res?.userProfile?.supportedCountries)
      }
      this.role.setValue(res?.userProfile?.role)
      this.fullName.setValue(res?.userProfile['firstName'] + ' ' + res?.userProfile['lastName'])
      this.showLoaderIcon = false
    })
  }

  removeCountry(country) {
    this.selectedCountryArray.splice(this.selectedCountryArray.indexOf(country), 1);
  }

  addCountry(event) {
    if (this.selectedCountryArray && this.selectedCountryArray.indexOf(event.option.value)) {
      this.selectedCountryArray.push(event.option.value)
      this.countryError = false;
    }
    const tmp = [...new Set(this.selectedCountryArray)]
    this.selectedCountryArray  = tmp
    this.myControl.setValue('');
  }

  save() {
    this.showLoaderIcon = true
    if(this.selectedCountryArray.length == 0){
      this.countryError = true
      return
    }

    let payload = {
      "staffProfile": {
        "staffId": this.id,
        "supportedCountries": this.selectedCountryArray,
        "roleName": this.role.value,
        'staffEmailId' : this.emailId
      }
    }

    this.bff.putStaffProfile(payload).subscribe(() => {
      this.showSuccessMessage()
      Auth.currentAuthenticatedUser().then(user => {
        this.bff.getUserPermission(user.attributes.email).subscribe({
          next: (res) => {
            this.bff.userPermission.next(res)
            this.showLoaderIcon = false
          }, error: (error) => {
            console.log(error, 'error')
          }
        })
      })
    })
  }

  showSuccessMessage(){
    this.showSuccess = true
    setTimeout(() => {
      this.showSuccess = false;
    }, 5000);
  }

  cancel() {
    this.role.setValue(this.userProfile['role'])
    this.selectedCountryArray = this.userProfile['supportedCountries']
  }
}
