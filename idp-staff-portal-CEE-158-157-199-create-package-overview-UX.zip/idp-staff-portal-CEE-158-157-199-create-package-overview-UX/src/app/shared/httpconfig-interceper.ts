
import { Injectable } from '@angular/core';
import {
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpErrorResponse
} from '@angular/common/http';

import { from, Observable, of, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Auth } from 'aws-amplify';

@Injectable()
export class HttpConfigInterceptor implements HttpInterceptor {
    token: string = ""

    constructor() { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // convert promise to observable using 'from' operator
        return from(this.handle(req, next))
    }


    createNonseKey() {
        const UTCDate = new Date().toISOString();
        const sha1 = require('sha1');
        const beforeEncryptedValue = UTCDate + 'b65uqIB8k49X1QyzPcTU46s3jBBlEsLn8tWVBnK6';
        const encryptedValue = sha1(beforeEncryptedValue);
        const accessKey = UTCDate + '####' + encryptedValue + '####' + 'b65uqIB8k49X1QyzPcTU46s3jBBlEsLn8tWVBnK6';
        const accessData = {
            accessKey,
            accessKeyCreatedTime: UTCDate
        };
        localStorage.setItem('accessObject', JSON.stringify(accessData));
        return accessData;
    }

    //Clone JWT token in the http header
    async handle(request: HttpRequest<any>, next: HttpHandler) {
        environment.enableAutentication ? await this.getToken() : this.token = environment.authenticationToken
        if (!request.url.includes('search') && !request.url.includes('getCheckstaffExist')) {
            request = request.clone({ setHeaders: { 'Authorization': 'Bearer ' + this.token } });
        } else {
            request = request.clone({ setHeaders: { access_code: this.createNonseKey().accessKey } });
        }
        // request = request.clone({ setHeaders: { 'Authorization': 'Bearer ' + this.token } });
        return next.handle(request).pipe(tap(evt => {
            if (evt instanceof HttpResponse) {
                if (evt.body && evt.body.status === 200) {

                }
            }
        }), catchError((error) => {
            console.log(error)
            setTimeout(() => {
                // this.uiUtilsService.hideLoader();
            }, 500)

            let handled = false;
            if (error instanceof HttpErrorResponse) {
                if (error.error instanceof ErrorEvent) {
                    console.error('Error Event');
                } else {
                    console.log(`error status 401/403: ${error.status} ${error.statusText}`);
                    switch (error.status) {
                        case 401:
                            console.log('401');
                            // this.utilService.logoutUser();
                            handled = false;
                            break;
                        case 403:
                            // forbidden
                            console.log(`forbidden`);
                            handled = false;
                            break;
                    }
                }
            } else {
                console.error('Other Errors');
            }
            if (handled) {
                console.log('return back ');
                return of(error);
            } else {
                console.log('throw error back to to the subscriber');
                return throwError(error);
            }
        })
        ).toPromise()
    }

    getToken() {
        return new Promise(async resolve => {
            await Auth.currentSession().then(session => {
                this.token = session.getIdToken().getJwtToken()
                resolve(session);
            }).catch(e => {
                if (e == 'No current user') {
                    resolve('notoken');
                    localStorage.clear();
                } else {
                    resolve('Unable to refresh Token');
                    console.log('Unable to refresh Token', e);
                }
            });
        })
    }
}