import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InteractionService {
  private menuClassSource = new Subject<boolean>();
  navActive = this.menuClassSource.asObservable();
  constructor() { }
  openSideNav(navActive: boolean){
    this.menuClassSource.next(navActive);
  }
}
