import { BrowserModule } from '@angular/platform-browser'
import { NgModule } from '@angular/core'
import { AppRoutingModule } from './app-routing.module'
import { AppComponent } from './app.component'
import { SanitizeHtmlPipe } from './app.bind'
import { WelcomeComponent } from './pages/welcome/welcome.component'
import { CookieModule } from 'ngx-cookie'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MAT_DATE_LOCALE } from '@angular/material/core'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { RouterModule } from '@angular/router'
import { FooterComponent } from './common/component/footer/footer.component'
import { DatePipe } from '@angular/common'
import { HttpConfigInterceptor } from './shared/httpconfig-interceper'
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http'
import { MatSelectModule } from '@angular/material/select'
import { CommonMethods } from './common/utilities/common-methods'
// import { VirtualScrollerModule } from 'ngx-virtual-scroller';
import { DropzoneDirective } from './common/directives/dropzone.directive'
import { Amplify } from 'aws-amplify'
import { environment } from 'src/environments/environment'
import { MatAutocompleteModule } from '@angular/material/autocomplete'
import { NgxPaginationModule } from 'ngx-pagination'
// import { UserProfileComponent } from './pages/user-profile/user-profile.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core'
import { TranslateHttpLoader } from '@ngx-translate/http-loader'

@NgModule({
  declarations: [
    AppComponent,
    SanitizeHtmlPipe,
    WelcomeComponent,
    FooterComponent,
    DropzoneDirective
    // UserProfileComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    CookieModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    MatSelectModule,
    MatAutocompleteModule,
    NgxPaginationModule,
    MatDatepickerModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
    // VirtualScrollerModule
  ],
  providers: [
    DatePipe,
    CommonMethods,
    { provide: HTTP_INTERCEPTORS, useClass: HttpConfigInterceptor, multi: true },
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    {
      provide: 'virtual-scroller-default-options',
      useValue: {
        checkResizeInterval: 0,
        // modifyOverflowStyleOfParentScroll: true,
        // resizeBypassRefreshThreshold: 5,
        scrollAnimationTime: 0,
        scrollDebounceTime: 0,
        scrollThrottlingTime: 0,
        stripedTable: false
      }
    }
  ],
  exports: [

  ],
  bootstrap: [AppComponent]
})
export class AppModule {

}

// SSO changes. Adding this class to get and set the token in cookies instead of local storage
const js_cookie__WEBPACK_IMPORTED_MODULE_0__ = require('js-cookie')
class MyCookieStorage {
  // the promise returned from sync function
  static syncPromise = null
  // set item with the key
  static setItem (key: string, value: string) {
    key = key.replace('.' + environment.userPoolWebClientId, '')
    const myDate = new Date()
    myDate.setMonth(myDate.getMonth() + 12)
    const options = {
      path: '/',
      expires: myDate,
      domain: environment.cognitoDomain
    }
    js_cookie__WEBPACK_IMPORTED_MODULE_0__.set(key, value, options)
    return js_cookie__WEBPACK_IMPORTED_MODULE_0__.get(key)
  }

  // get item with the key
  static getItem (key: string) {
    key = key.replace('.' + environment.userPoolWebClientId, '')
    return js_cookie__WEBPACK_IMPORTED_MODULE_0__.get(key)
  }

  // remove item with the key
  static removeItem (key: string) {
    key = key.replace('.' + environment.userPoolWebClientId, '')
    const myDate = new Date()
    myDate.setMonth(myDate.getMonth() + 12)
    const options = {
      path: '/',
      expires: myDate,
      domain: environment.cognitoDomain
    }
    return js_cookie__WEBPACK_IMPORTED_MODULE_0__.remove(key, options)
  }

  // clear out the storage
  static clear () {
    const cookies = js_cookie__WEBPACK_IMPORTED_MODULE_0__.get()
    const numKeys = Object.keys(cookies).length
    for (let index = 0; index < numKeys; ++index) {
      this.removeItem(Object.keys(cookies)[index])
    }
    return {}
  }
}

Amplify.configure({
  Auth: {
    region: environment.region, // REQUIRED - Amazon Cognito Region
    // identityPoolId: environment.identityPoolId, // REQUIRED - Amazon Cognito Region
    userPoolId: environment.userPoolId, // OPTIONAL - Amazon Cognito User Pool ID
    userPoolWebClientId: environment.userPoolWebClientId, // OPTIONAL - Amazon Cognito Web Client ID (26-char alphanumeric string)
    mandatorySignIn: true, // OPTIONAL - Enforce user authentication prior to accessing AWS resources or not
    storage: MyCookieStorage,
    // authenticationFlowType: 'USER_PASSWORD_AUTH', // OPTIONAL - Manually set the authentication flow type. Default is 'USER_SRP_AUTH'
    oauth: { // OPTIONAL - Hosted UI configuration
      domain: environment.identityServer,
      scope: ['email', 'profile', 'openid', 'aws.cognito.signin.user.admin'],
      redirectSignIn: environment.redirectSignIn,
      redirectSignOut: environment.redirectSignOut,
      // tslint:disable-next-line: max-line-length
      responseType: 'code', // code or 'token', note that REFRESH token will only be generated when the responseType is code
      options: {
        AdvancedSecurityDataCollectionFlag: false
      }
    }
  }
})

// required for AOT compilation
export function HttpLoaderFactory (http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http)
}
