import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component'
import { AuditLogComponent } from './common/component/audit-log/audit-log.component'
import { AuthenticatedUserGuard } from './common/guard/authenticated-user.guard'

const routes: Routes = [
  {
    path: 'idp-staff-portal/events-dashboard',
    loadChildren:() => import('./pages/dashboard/dashboard.module').then(m => m.DashboardModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/events-overview',
    loadChildren:() => import('./pages/overview/overview.module').then(m => m.OverviewModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/student-profile',
    loadChildren:() => import('./pages/student-profile/student-profile.module').then(m => m.StudentProfileModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/user-management',
    loadChildren:() => import('./pages/user-management/user-management.module').then(m => m.UserManagementModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/user-profile',
    loadChildren:() => import('./pages/user-profile/user-profile.module').then(m => m.UserProfileModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/student-participation',
    loadChildren:() => import('./pages/student-participation/student-participation.module').then(m => m.StudentParticipationModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/import-registrants',
    loadChildren:() => import('./pages/import-registrants/import-registrants.module').then(m => m.ImportRegistrantsModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/import-registrants-details',
    component: AuditLogComponent,
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/create-new-event',
    loadChildren: () => import('./pages/simplified-events/create-event/create-event.module').then(m => m.CreateEventModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/new-master-event',
    loadChildren: () => import('./pages/simplified-events/new-master-event/new-master-event.module').then(m => m.NewMasterEventModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/student-event',
    loadChildren: () => import('./pages/simplified-events/student-event/student-event.module').then(m => m.StudentEventModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/event-type',
    loadChildren: () => import('./pages/simplified-events/event-type/event-type.module').then(m => m.EventTypeModule),
    canActivate: [AuthenticatedUserGuard]
  },
  {
    path: 'idp-staff-portal/packages-dashboard',
    loadChildren: () => import('./pages/packages/packages-dashboard/packages-dashboard.module').then(m => m.PackagesDashboardModule)
  },
  {
    path: 'idp-staff-portal/create-package',
    loadChildren: () => import('./pages/packages/create-package/create-package.module').then(m => m.CreatePackageModule)
  },
  {
    path: '**',
    component: PageNotFoundComponent,
    canActivate: [AuthenticatedUserGuard]
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })], // {onSameUrlNavigation: 'reload'}
  exports: [RouterModule]
})
export class AppRoutingModule { }
