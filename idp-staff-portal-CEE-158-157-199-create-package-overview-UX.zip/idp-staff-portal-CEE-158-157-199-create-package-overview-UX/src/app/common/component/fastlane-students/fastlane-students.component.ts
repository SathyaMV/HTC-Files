import { Component } from '@angular/core';

@Component({
  selector: 'app-fastlane-students',
  templateUrl: './fastlane-students.component.html',
  styleUrls: ['./fastlane-students.component.css']
})
export class FastlaneStudentsComponent { }
