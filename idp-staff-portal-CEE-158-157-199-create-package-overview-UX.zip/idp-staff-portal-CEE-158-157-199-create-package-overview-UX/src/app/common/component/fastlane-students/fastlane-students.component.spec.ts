import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FastlaneStudentsComponent } from './fastlane-students.component';

describe('FastlaneStudentsComponent', () => {
  let component: FastlaneStudentsComponent;
  let fixture: ComponentFixture<FastlaneStudentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FastlaneStudentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FastlaneStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
