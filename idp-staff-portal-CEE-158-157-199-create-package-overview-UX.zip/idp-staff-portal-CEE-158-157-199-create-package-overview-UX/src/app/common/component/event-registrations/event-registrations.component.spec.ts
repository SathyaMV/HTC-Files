import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';
import { BffService } from '../../../providers/bff.service';
import { EventRegistrationsComponent } from './event-registrations.component';
import{ studentDetailSearchPipe} from '../.././pipe/student-search.pipe'

describe('EventRegistrationsComponent', () => {
  let component: EventRegistrationsComponent;
  let fixture: ComponentFixture<EventRegistrationsComponent>;
  let service: BffService;
  const eventDetails = [{test:'testname'}];
  const registerData = [{checkIn:true}]
  

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[RouterTestingModule.withRoutes([]),HttpClientModule,MatAutocompleteModule,NgxPaginationModule],
      declarations: [ EventRegistrationsComponent,studentDetailSearchPipe ],
      providers: [BffService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventRegistrationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    service = TestBed.inject(BffService);
    component.myEventDetails = eventDetails;
    component.eventRegisteredStudent = registerData;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.myEventDetails).not.toBeUndefined();
    expect(component.eventRegisteredStudent).not.toBeUndefined();
  })
});
