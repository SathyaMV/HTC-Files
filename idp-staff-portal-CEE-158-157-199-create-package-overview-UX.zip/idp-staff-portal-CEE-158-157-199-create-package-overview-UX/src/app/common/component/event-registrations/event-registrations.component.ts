import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-event-registrations',
  templateUrl: './event-registrations.component.html',
  styleUrls: ['./event-registrations.component.css']
})
export class EventRegistrationsComponent implements OnInit {
  @Input() eventRegisteredStudent;
  @Input() myEventDetails;
  myControl = new FormControl('');
  mobileDevice = this.methods.isMobileUser();
  labelValue: any;
  registerStartCount: any;
  registerLastCount: any;
  registeredPage: any;
  registerSearchLastCount: any;
  eventRegisteredCount: any;
  registerDefaultOption = 'Email';
  searchData: any = '';
  filterMetadata: any = { count: 0 };
  dragAndDrop:boolean = false;
  importCheck:boolean=false;
  fileName;
  showBulkUploadTable:boolean = false;
  bulkUploadTableData:any
  canBulkuploadRegistrants:boolean = false
  
  constructor(private router:Router, private bff:BffService, private methods:CommonMethods) { }

  ngOnInit(): void {
    this.eventRegisteredCount = this?.eventRegisteredStudent?.length;
    this.bff.detectManualRegisterForm.subscribe(detect => {
      if(detect){
        this.bff.eventRegistrantData.subscribe(data =>{
          if(data){
            this.eventRegisteredStudent = data
            this.eventRegisteredCount =  this.eventRegisteredStudent?.length;
            this.bff.detectManualRegisterForm.next(false);
          } 
        })
      }
    })
    this.getRegisterSearchLabel(this.registerDefaultOption);
    if (this.eventRegisteredCount <= 10) {
      this.registerLastCount = this.eventRegisteredCount;
    } else {
      this.registerLastCount = 10;
    }
    this.registerStartCount = 1;


    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canBulkuploadRegistrants = data['userAccess'].canBulkuploadRegistrants
    })
  }

   //This method is used to find the  label in the registered search dropdown
   getRegisterSearchLabel(value) {
    this.labelValue = value
  }

  getMaskedMobileNumber(mobileNumber) {
    return this.methods.getMobileNumber(mobileNumber)
  }

  //This method is used to find the no of records of the  in registered student in pagination
  registerListCount(count, value) {
    this.registerStartCount = count
    this.registerStartCount = this.registerStartCount * 10 - 9;
    this.registerLastCount = count * 10;
    if (this.registerLastCount > value) {
      this.registerLastCount = value;
    }
  }

  //This method is used to find the no of records for the searched registered student in pagination
  registerSearchListCount(count, value) {
    this.registerSearchLastCount = count * 10;
    if (this.registerSearchLastCount > value) {
      this.registerSearchLastCount = value
    }
  }

  
  //This method is used to show the registered search results in first page
  onChangeRegister(e) {
    if (e.length > 2) {
      this.registeredPage = 1;
      this.registerStartCount = 1;
      this.registerSearchLastCount = 10
      if (this.eventRegisteredCount <= 10) {
        this.registerLastCount = this.eventRegisteredCount;
      } else {
        this.registerLastCount = 10;
      }

    }
  }

  seperateDestination(data) {
    let str = ''
    // let arr = data.split(',');
    // if (arr.length > 0) {
    //   for (let i = 0; i < arr.length; i++) {
    //     str += '<div class="dest_point dest_loc">' + arr[i] + '</div>'
    //   }
    // }
    str += '<div class="dest_point dest_loc">' + data + '</div>'
    return str
  }

  studentProfilePage(studentEmail,studentId,attendedStatus,walkInStatus){
    let eventCode = this.myEventDetails.cventCode
    sessionStorage.setItem('studentEmail_'+sessionStorage.getItem('tabID'),studentEmail)
    sessionStorage.setItem('eventCode_'+ sessionStorage.getItem('tabID'),eventCode)
    sessionStorage.setItem('eventTitle_'+sessionStorage.getItem('tabID' + eventCode),this.myEventDetails.eventTitle)
    sessionStorage.setItem('studentId_'+sessionStorage.getItem('tabID'),studentId)
    sessionStorage.setItem('eventId_'+sessionStorage.getItem('tabID'),this.myEventDetails.eventId)
    sessionStorage.setItem('attendedStatus_' + sessionStorage.getItem('tabID'),attendedStatus)
    sessionStorage.setItem('walkInStatus_' + sessionStorage.getItem('tabID'),walkInStatus)
    this.router.navigateByUrl('idp-staff-portal/student-profile');
  }

  scrollTop(tab) {
    if (tab === 'registeredStudent') {
      document.getElementById('registeredStudent').scrollIntoView({ behavior: "smooth" });
    } 
  }

  toggleupload(){
      document.body.classList.add('hide_event');
      this.bff.showBulkUploadSurveyQn.next(true);
  }

  dragAndDropEmit(event){
    this.dragAndDrop = true; 
  }

  showBulkUploadTableMethod(event){
    this.showBulkUploadTable = true
  }

  bulkUploadTableDataEmit(event){
    this.bulkUploadTableData = event;
  }

  fileNameEmit(event){
    this.fileName = event
  }

  closeSurveyEmit(event){
    if(this.importCheck == event){
      this.importCheck = true;
      document.body.classList.add('hide_body');
    }else{
      this.importCheck = false;
      document.body.classList.remove('hide_body');
    }  }


}
