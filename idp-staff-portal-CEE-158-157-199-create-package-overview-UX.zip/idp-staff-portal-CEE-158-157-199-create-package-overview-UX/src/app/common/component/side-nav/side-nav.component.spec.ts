import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InteractionService } from '../../../interaction.service';
import { SideNavComponent } from './side-nav.component';

describe('SideNavComponent', () => {
  let component: SideNavComponent;
  let fixture: ComponentFixture<SideNavComponent>;
  let service: InteractionService
  const navActivenew: boolean = true;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SideNavComponent ],
      providers: [InteractionService],
      imports:[RouterTestingModule]
    })
    .compileComponents();
    service = TestBed.inject(InteractionService);

    fixture = TestBed.createComponent(SideNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.navActivenew =navActivenew
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.navActivenew).not.toBeUndefined();
  })
});
