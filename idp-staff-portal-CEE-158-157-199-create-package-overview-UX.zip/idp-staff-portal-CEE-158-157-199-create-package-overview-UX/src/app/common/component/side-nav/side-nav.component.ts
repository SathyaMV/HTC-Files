import { Component, OnInit } from '@angular/core';
import { InteractionService } from '../../../interaction.service';
import { Router, Event, NavigationStart, NavigationEnd, NavigationError} from '@angular/router';
import { BffService } from 'src/app/providers/bff.service';
import { Auth } from 'aws-amplify';
import { CookieService } from 'ngx-cookie';
import { environment } from '../../../../environments/environment'
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})

export class SideNavComponent implements OnInit {
  public toggle : boolean = false;
  navActivenew:boolean=false;
  menuActive:boolean=false;
  currentRoute: string;
  allEventUrl;
  canManageAccess :boolean = false;
  canViewAdminReports: boolean = false;
  firstName:string;
  lastName:string = ''
  nameInitials:string  = ''
  
  constructor(private dataservice: InteractionService,
              private router: Router,
              private bff:BffService,
              private cookies:CookieService) {
    this.currentRoute = "";
    this.router.events.subscribe((event: Event) => {
        if (event instanceof NavigationEnd) {
          if(event.url != "/"){
            this.menuActive = true;
          }
        }
    });
  }
  ngOnInit(): void {
    this.dataservice.navActive.subscribe(data=>{
      this.navActivenew = data;
    });
    this.allEventUrl ="idp-staff-portal/events-dashboard"

    this.checkPermisson()    
  }
  openSideNav(){
    this.navActivenew = false;
  }
  menu_drop(){
    this.toggle = !this.toggle;
  }
  openMenu(){
    this.menuActive = !this.menuActive;
  }

  //Check user permission
  checkPermisson(){
    this.bff.userPermission.subscribe(data=>{
      this.canManageAccess = data['userAccess'].canManageAccess
      this.canViewAdminReports = data['userAccess'].canViewAdminReports
      this.firstName = data['firstName'] ? data['firstName'] : ''
      this.lastName = data['lastName'] ? data['lastName'] : ''
      this.nameInitials = (this.firstName ? this.firstName.charAt(0).toUpperCase() : '' )+(this.lastName ? this.lastName.charAt(0).toUpperCase() : '' );
    })
  }

  logoutUser(){
    Auth.signOut({ global: true }).then((res) => {
      localStorage.clear()
      sessionStorage.clear()
      this.cookies.removeAll()
    }).catch((error) => {
      console.log('error signing out: ', error);
    });
  }
}
