import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderIconComponent } from './loader-icon.component';



@NgModule({
  declarations: [LoaderIconComponent],
  imports: [
    CommonModule
  ],
  exports:[LoaderIconComponent]
})
export class LoaderIconModule { }
