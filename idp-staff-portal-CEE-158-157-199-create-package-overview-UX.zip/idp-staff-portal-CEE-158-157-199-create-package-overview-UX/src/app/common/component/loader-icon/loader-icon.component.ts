import { Component, OnInit } from '@angular/core';
import { BffService } from '../../../providers/bff.service';

@Component({
  selector: 'app-loader-icon',
  templateUrl: './loader-icon.component.html',
  styleUrls: ['./loader-icon.component.css']
})
export class LoaderIconComponent implements OnInit {
  showLoaderIcon:boolean = false;
  constructor(private bff : BffService) { }

  ngOnInit(): void {

    this.bff.showLoaderIcon.subscribe(data=>{
      this.showLoaderIcon = data;
    })
  }

}
