import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { LoaderIconComponent } from './loader-icon.component';

describe('LoaderIconComponent', () => {
  let component: LoaderIconComponent;
  let fixture: ComponentFixture<LoaderIconComponent>;
  let service: BffService;
  const loaderIcon : boolean = true;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoaderIconComponent ],
      imports:[HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoaderIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.showLoaderIcon = loaderIcon;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.showLoaderIcon).not.toBeUndefined();
  })
});
