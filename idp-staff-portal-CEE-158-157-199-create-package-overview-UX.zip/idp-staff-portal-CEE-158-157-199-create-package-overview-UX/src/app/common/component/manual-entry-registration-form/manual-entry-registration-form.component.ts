import { Component, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonMethods } from '../../utilities/common-methods';
import { BffService } from '../../../providers/bff.service';

@Component({
  selector: 'app-manual-entry-registration-form',
  templateUrl: './manual-entry-registration-form.component.html',
  styleUrls: ['./manual-entry-registration-form.component.css']
})

export class ManualEntryRegistrationFormComponent implements OnInit {

  entryCheck:boolean = false;
  eventCode = sessionStorage.getItem('eventCode_'+ sessionStorage.getItem('tabID'));
  dialCodeList:any = [];
  eventDetails:any = [];
  formQuestions:any = [];
  submitted:boolean = false;
  registrationForm:FormGroup;
  registrationSuccess:boolean = false;
  fName:any
  lName:any
  showLoaderIcon:boolean = true;
  hideSuccessMessage:boolean = false;
  showErrorMessage:boolean = false;

  constructor(private bff:BffService,
              private methods: CommonMethods,
              private formBuilder : FormBuilder,
              private el: ElementRef,
              ) { }

  ngOnInit(): void {

    this.bff.enableRegistrationForm.subscribe(data=>{
      this.entryCheck = data;
    })

    this.getRegistrationFormQuestion();

    this.registrationForm = this.formBuilder.group({
      dialCode : ['0',Validators.required]
    })
  }
  
  printPopup(){
    this.submitted = true;
  }

  getRegistrationFormQuestion(){
    this.bff.getRegistrationFormQuestion(this.eventCode).subscribe(response=>{
      this.dialCodeList = response.dialCode;
      this.eventDetails = response.eventDetails;
      this.formQuestions = this.methods.sortByDisplaySequence(response.items[0].fields.questions,'displaySequence');
      this.buildForm(this.formQuestions);
    })
  }

  buildForm(questions){
    questions.filter(ele=>{
      this.registrationForm.addControl(ele.mappingField,new FormControl('',this.getValidators(ele)))
    })
    this.showLoaderIcon = false
  }

  getValidators(field) {
    let fieldValidators = [];
    if (field.mandatory) {
      if(field.displayFormat.value != 'CHECKBOX'){
        fieldValidators.push(Validators.required);
      }else{
        fieldValidators.push(Validators.requiredTrue)
      }
    }
    
    if (field.maxLength != '') {
      fieldValidators.push(Validators.maxLength(field.maxLength));
    }

    if (field.mappingField == 'primary_email') {
      let emailPattern = /^\w+([-+.'']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
      fieldValidators.push(Validators.pattern(emailPattern));
    }

    if (field.mappingField == 'primary_mobile_number') {
      let numberPattern = '[0-9]*'
      fieldValidators.push(Validators.pattern(numberPattern));
    }
    return fieldValidators;
  }

  phoneNumValidation() {
    let minLen = parseInt(this.dialCodeList[this.registrationForm.controls.dialCode.value].minLength)
    let maxLen = parseInt(this.dialCodeList[this.registrationForm.controls.dialCode.value].maxLength)
    let mobNum = this.registrationForm.controls.primary_mobile_number.value.length;
    let isDigit = this.methods.checkOnlyDigit(this.registrationForm.controls.primary_mobile_number.value)
    if (isDigit) {
      if (mobNum < minLen || mobNum > maxLen || mobNum == 0) {
        this.registrationForm.controls['primary_mobile_number'].setErrors({ invalidPhoneNumber: false })
      } else {
        this.registrationForm.controls['primary_mobile_number'].setErrors(null)
      }
    } else {
      this.registrationForm.controls['primary_mobile_number'].setErrors({ invalidPhoneNumber: false })
    }
  }
  
  regPopup(){
    this.bff.enableRegistrationForm.next(false);
    document.body.classList.remove('hide_event');
  }

  submitForm(){
    if (this.registrationForm.invalid) { // Focusing the error field
      for (const key of Object.keys(this.registrationForm.controls)) {
        if (this.registrationForm.controls[key].invalid) {
          const invalidControl = this.el.nativeElement.querySelector('[id="' + key + '"]');
          invalidControl.focus();
          break;
        }
      }
      return;
    }
    this.showLoaderIcon = !this.showLoaderIcon
    let data = this.registrationForm.controls
    let eventRegistrationPayload = []
    let tmpObj = {
      "modeOfRegistration": 'MANUAL',
      "firstName": data.first_name.value ? data.first_name.value : '',
      "lastName": data.last_name.value ? data.last_name.value : '',
      "mobileNumber": data.primary_mobile_number.value ? this.dialCodeList[data.dialCode.value].optionKey + ' ' + data.primary_mobile_number.value.toString() : '',
      "email": data.primary_email.value ? data.primary_email.value : '',
      "howDidYouHearAboutIdpEvent" : data.howDidYouHear.value ? data.howDidYouHear.value : '', 
      "nearestIdp" : data.nearestldpOffice.value ? data.nearestldpOffice.value : '',
      "tcAcceptance": data.termsAndConditionsAcceptance.value ? true : false,
      "contactMeBy" : data.contactMeBy.value ?  true : false,
      "marketingAcceptance" : data['marketing_acceptance_flag.acceptPhoneCall, marketing_acceptance_flag.acceptEmail, marketing_acceptance_flag.acceptSms'].value ? true : false,
      "nationality": '',
      "preferredStudyDestination": '',
      "preferredStudyDestinationCode": '',
      "preferredStudyLevel": '',
      "preferredCounsellingMode" : '',
      "studyPlanMonthYear" : '',
      "preferredSubject" : '',
      "primaryFinancialSource": '',
      "highestEducation": '',
      "cventCode": this.eventDetails.cventCode,
      "correlationId": this.methods.correlationId(),
      "idpEventId": this.eventDetails.idpEventId,
      "cventAccountId": this.eventDetails.cventAccountId,
      "eventJoinNow" : true,
      "confirmationEmailConsent": 'Yes'
    }
    eventRegistrationPayload.push(tmpObj)
    this.bff.searchEventRegistration(this.eventDetails.cventCode,data.primary_email.value ).subscribe(data =>{
      if(data?.isRegistered !== true){
        this.bff.sendBulkUploadRegistration(eventRegistrationPayload).subscribe(response=>{
          this.fName = response['firstName']
          this.lName = response['lastName']
          this.registrationSuccess = true;
          this.submitted = false;
          this.showLoaderIcon = !this.showLoaderIcon
          setTimeout(() => {
            this.bff.detectManualRegisterForm.next(true);
            let inPayLoad = 'cventCode=' + this.eventCode
            this.bff.getEventsOverviewPageDetails(inPayLoad).subscribe(data=>{
              this.bff.eventRegistrantData.next(data?.eventOverviewDetails?.studentDetails);
            })
            this.bff.getRegisterParticipant(this.eventDetails.idpEventId,'').subscribe(data =>{
              this.bff.reportRegistrantCount.next(data?.registrationPaticipants);
            })
            this.closeScuccessPopup();
            this.registrationForm.reset();
            this.bff.enableRegistrationForm.next(false);
          }, 5000);
        })
        this.hideSuccessMessage = true;
        this.showErrorMessage = false
      }else{
        this.hideSuccessMessage = false;
        this.showErrorMessage = true;
        this.showLoaderIcon = !this.showLoaderIcon; 
      }
    }) 
  }

  closeScuccessPopup(){
    this.registrationSuccess = !this.registrationSuccess;
  }

  ngOnDestroy(){
    this.regPopup();
  }

  get fields() {
    return this.registrationForm.controls;
  }

  errorCloseBtn(){
    this.showErrorMessage =!this.showErrorMessage
  }
}