import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { ManualEntryRegistrationFormComponent } from './manual-entry-registration-form.component';

describe('ManualEntryRegistrationFormComponent', () => {
  let component: ManualEntryRegistrationFormComponent;
  let fixture: ComponentFixture<ManualEntryRegistrationFormComponent>;
  let service: BffService;
  const eventDetails = [{eventName:'VE-DEV'}];
  const dialCodeList = [{IN:'+91'}];
  const formQuestions = [{test:'testName'}]


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManualEntryRegistrationFormComponent ],
      imports:[HttpClientModule],
      providers: [BffService,
        { provide: CommonMethods, useClass: class {}},
        FormBuilder
      ]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryRegistrationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.dialCodeList = dialCodeList;
    component.formQuestions = formQuestions;
    component.eventDetails = eventDetails
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.dialCodeList).not.toBeUndefined();
    expect(component.formQuestions).not.toBeUndefined();
    expect(component.eventDetails).not.toBeUndefined();
  })

  it('should create 1 of that', () => {
    const fields = Object.keys(component.registrationForm.controls);
    expect(fields.length).toBe(1);
  });
});
