import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination';
import { EventParticipantsComponent } from './event-participants.component';
import{ studentDetailSearchPipe} from '../.././pipe/student-search.pipe'

describe('EventParticipantsComponent', () => {
  let component: EventParticipantsComponent;
  let fixture: ComponentFixture<EventParticipantsComponent>;
  const eventDetails = [{test:'testname'}];
  const participantData = [{checkIn:true}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[RouterTestingModule.withRoutes([]),
       MatAutocompleteModule,NgxPaginationModule
    ],
      declarations: [ EventParticipantsComponent,studentDetailSearchPipe ],

    })
    .compileComponents();
   
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventParticipantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.myEventDetails = eventDetails;
    component.eventParticipatedStudent = participantData;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should have data',()=>{
    expect(component.myEventDetails).not.toBeUndefined();
    expect(component.eventParticipatedStudent).not.toBeUndefined();
  })
});
