import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { BffService } from 'src/app/providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-event-participants',
  templateUrl: './event-participants.component.html',
  styleUrls: ['./event-participants.component.css']
})
export class EventParticipantsComponent implements OnInit {
  @Input() eventParticipatedStudent;
  @Input() myEventDetails;
  mobileDevice = this.methods.isMobileUser();
  labelValue: any;
  participatedPage;
  participantStartCount;
  participantSearchLastCount;
  eventParticipatedCount;
  participantLastCount;
  participateDefaultOption = 'Email';
  filterMetadata: any = { count: 0 };
  searchResults: any = '';
  filteredOptions!: Observable<string[]>;
  myControl = new FormControl('');
  dragAndDrop:boolean = false;
  importCheck:boolean=false;
  fileName;
  showBulkUploadTable:boolean = false;
  bulkUploadTableData:any
  canBulkuploadRegistrants:boolean = false
  
  constructor(private router:Router, private bff:BffService,private methods:CommonMethods) { }

  ngOnInit(): void {
    this.eventParticipatedCount = this.eventParticipatedStudent?.length;
    this.bff.detectManualRegisterForm.subscribe(detect => {
      if(detect){
        this.bff.eventParticipantCount.subscribe(count => {
          this.eventParticipatedCount = count;
        })
      }
    })
    this.geParticpatedSearchLabel(this.participateDefaultOption);
    if (this.eventParticipatedCount <= 10) {
      this.participantLastCount = this.eventParticipatedCount;
    } else {
      this.participantLastCount = 10;
    }
    this.participantStartCount = 1;

    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canBulkuploadRegistrants = data['userAccess'].canBulkuploadRegistrants
    })
  }

  //This method is used to seperate the comma seperated values in JSON
  seperateDestination(data) {
    console.log(data,'data')
    let str = ''
    // let arr = data.split(',');
    // if (arr.length > 0) {
    //   for (let i = 0; i < arr.length; i++) {
    //     str += '<div class="dest_point dest_loc">' + arr[i] + '</div>'
    //   }
    // }
    str += '<div class="dest_point dest_loc">' + data + '</div>'

    console.log(str,'str')
    return str
  }

   //This method is used to find the  label in the participated search dropdown
   geParticpatedSearchLabel(value) {
    this.labelValue = value
  }

  getMaskedMobileNumber(mobileNumber) {
    return this.methods.getMobileNumber(mobileNumber)
  }
 
  //This method is used to show the participant search results in first page
  onChangeParticipant(e) {
    if (e.length > 2) {
      this.participatedPage = 1;
      this.participantStartCount = 1;
      this.participantSearchLastCount = 10;
      if (this.eventParticipatedCount <= 10) {
        this.participantLastCount = this.eventParticipatedCount;
      } else {
        this.participantLastCount = 10;
      }
    }
  }

  //This method is used to find the no of records of the  in participated student in pagination
  participatedListCount(count, value) {
    this.participantStartCount = count
    this.participantStartCount = this.participantStartCount * 10 - 9;
    this.participantLastCount = count * 10
    if (this.participantLastCount > value) {
      this.participantLastCount = value;
    }
  }
  //This method is used to find the no of records for the searched participated student in pagination
  participantSearchListCount(count, value) {
    this.participantSearchLastCount = count * 10;
    if (this.participantSearchLastCount > value) {
      this.participantSearchLastCount = value
    }
  }

  studentProfilePage(studentEmail,studentId,attendedStatus,walkInStatus){
    let eventCode = this.myEventDetails.cventCode
    sessionStorage.setItem('studentEmail_'+sessionStorage.getItem('tabID'),studentEmail)
    sessionStorage.setItem('eventCode_'+ sessionStorage.getItem('tabID'),eventCode)
    sessionStorage.setItem('eventTitle_'+sessionStorage.getItem('tabID' + eventCode),this.myEventDetails.eventTitle)
    sessionStorage.setItem('studentId_'+sessionStorage.getItem('tabID'),studentId)
    sessionStorage.setItem('eventId_'+sessionStorage.getItem('tabID'),this.myEventDetails.eventId)
    sessionStorage.setItem('attendedStatus_' + sessionStorage.getItem('tabID'),attendedStatus)
    sessionStorage.setItem('walkInStatus_' + sessionStorage.getItem('tabID'),walkInStatus)
    this.router.navigateByUrl('idp-staff-portal/student-profile');
  }

  scrollTop(tab) {
    if (tab === 'participatedStudent') {
      document.getElementById('participatedStudent').scrollIntoView({ behavior: "smooth" });
    } 
  }

  toggleupload() {
    document.body.classList.add('hide_event');
    this.bff.showBulkUploadSurveyQn.next(true);
  }

  dragAndDropEmit(event){
    this.dragAndDrop = true; 
  }

  showBulkUploadTableMethod(event){
    this.showBulkUploadTable = true
  }

  bulkUploadTableDataEmit(event){
    this.bulkUploadTableData = event;
  }

  fileNameEmit(event){
    this.fileName = event
  }

  closeSurveyEmit(event){
    if(this.importCheck == event){
      this.importCheck = true;
      document.body.classList.add('hide_body');
    }else{
      this.importCheck = false;
      document.body.classList.remove('hide_body');
    }  }

}
