import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';


@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.css']
})
export class PreferencesComponent implements OnInit {
  preferenceQnDataConvsersion; 
  preferenceForm:FormGroup;
  @Input() preferenceQnData;
  @Input() preferenceAnswer

  constructor(private bff: BffService,private fb: FormBuilder) { }

  ngOnInit(): void {
    this.preferenceForm = this.fb.group({
      preferredCountryCode: '',
      preferredStudyLevel: '',
      studyPlanDate: ''
    })
    this.getPreferenceDetails();  
  }

  getPreferenceDetails(){
    let planToStudy = this.preferenceAnswer?.planToStudy;    
    let planToStudyConversion = planToStudy !== undefined && planToStudy.includes('-') ? planToStudy.split('-'): planToStudy !== undefined && planToStudy.includes(" ") ? planToStudy.split(" ") : '';      
    this.preferenceForm.get('preferredCountryCode').patchValue(this.preferenceAnswer?.preferredDestination ? this.preferenceAnswer?.preferredDestination : '')
    this.preferenceForm.get('preferredStudyLevel').patchValue(this.preferenceAnswer?.studyLevel ? this.preferenceAnswer?.studyLevel : '' )
    this.preferenceForm.get('studyPlanDate').patchValue(planToStudyConversion[1] !== undefined ? planToStudyConversion[1] : '' )
  }
}
