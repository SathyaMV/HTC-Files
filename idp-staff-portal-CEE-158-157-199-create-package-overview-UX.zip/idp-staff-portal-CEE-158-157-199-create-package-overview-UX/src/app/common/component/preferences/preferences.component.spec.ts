
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';
import { PreferencesComponent } from './preferences.component';

describe('PreferencesComponent', () => {
  let component: PreferencesComponent;
  let fixture: ComponentFixture<PreferencesComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreferencesComponent ],
      imports: [HttpClientModule,CdkAccordionModule],
      providers: [BffService,FormBuilder]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PreferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
