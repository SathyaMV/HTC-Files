import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-bulk-upload-survey-question',
  templateUrl: './bulk-upload-survey-question.component.html',
  styleUrls: ['./bulk-upload-survey-question.component.css']
})
export class BulkUploadSurveyQuestionComponent implements OnInit {

  @Input() importCheck
  @Output() public dragAndDropEmit = new EventEmitter<any>();
  @Output() public closeSurveyEmit = new EventEmitter<any>();
  surveyForm: FormGroup;
  eventQuestions:any;
  cventCode;
  bulkUploadFeatureArray = [{}];
  filteredData=[];
  confirmFilteredData = [];
  isLiveOrFutureEvent: boolean = false;
  isPastEvent: boolean = false;
  isFormSubmitted: boolean = false;
  eventDetails;
  dialCode

  constructor(private fb : FormBuilder, private methods: CommonMethods,private bff: BffService,
    private route : ActivatedRoute) {
      this.bulkUploadFeatureArray = [
        {
          formControlName:'option1',
          label: 'Contact Centre Qualified Leads',
          isChecked:false
        },
        {
          formControlName:'option2',
          label: 'Infrastructure Outage',
          isChecked:false
        },
        {
          formControlName:'option3',
          label: 'School or College Visit',
          isChecked:false
        },
        {
          formControlName:'option4',
          label: 'Social Media Forms',
          isChecked:false
        },
        {
          formControlName:'option5',
          label: 'Other',
          isChecked:false
        },
      ]
    }

  ngOnInit(): void {
    this.surveyForm = this.fb.group({
      option1: [false],
      option2: [false],
      option3: [false],
      option4: [false],
      option5: [false],
      notes:[''],
      confirmation: [''],
    })
    this.getEventDetails()
    this.bff.getBulkUploadPPQuestions(this.cventCode,'EN').subscribe(data=>{
      this.eventQuestions = data.items[0].fields.questions
      this.dialCode = data['dialCode']
    })
  }

  getEventDetails(){
    this.route.queryParams.subscribe(params=>{
      if(params.eventCode){
        this.cventCode = params.eventCode
        this.eventDetails = JSON.parse(sessionStorage.getItem('eventDetails_' + this.cventCode));
        this.setEventDetails();
      }   
    })
  }

  toggleimportfiles(){
    this.isFormSubmitted = true;
    if ((this.filteredData.length > 0 && !this.filteredData.includes('Other')) || this.isValidNotes()) {
      //if (this.isLiveOrFutureEvent || (this.isPastEvent && this.surveyForm.value.confirmation !== '')) {
        this.dragAndDropEmit.emit(true);
        this.bff.showBulkUploadSurveyQn.next(false);
        this.bff.showFileUploadScreen.next(true);
        this.bff.bulkUploadSurvey.next({
          options: this.filteredData,
          notes: this.surveyForm.value.notes,
          emailConfirmation: this.surveyForm.value.confirmation
        })
      //}
    }
  }

  surveyOption(i,e){
    this.bulkUploadFeatureArray[i]['isChecked'] = e.checked;
    this.filteredData = this.bulkUploadFeatureArray.filter((data)=>{
      return data['isChecked'];
    }).map(ele=>ele['label']);
  }

  closeSurvey(){
    document.body.classList.remove('hide_event');
    this.closeSurveyEmit.emit(false);
    this.bff.showBulkUploadSurveyQn.next(false);
    this.bff.showFileUploadScreen.next(false);
    document.body.classList.remove('hide_event');
  }

  downLoadTemplate(){
    this.methods.downLoadTemplate(this.eventQuestions,this.dialCode)
  }

  isValidNotes() {
    return (this.filteredData.includes('Other') && this.surveyForm.value.notes.length >=4 && this.surveyForm.value.notes.length <= 255);
  }

  isValidOption() {
    return (!this.filteredData.includes('Other') || this.isValidNotes());
  }

  setEventDetails() {
    let currentDate = new Date();
    let endDate = new Date(this.eventDetails.eventEndDate);

    if (currentDate > endDate) {
      this.isPastEvent = true;
    } else {
      this.isLiveOrFutureEvent = true;
    }
  }

}
