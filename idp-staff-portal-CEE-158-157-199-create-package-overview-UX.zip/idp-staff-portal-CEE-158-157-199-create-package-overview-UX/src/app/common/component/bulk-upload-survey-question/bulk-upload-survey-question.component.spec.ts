import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { BulkUploadSurveyQuestionComponent } from './bulk-upload-survey-question.component';

describe('BulkUploadSurveyQuestionComponent', () => {
  let component: BulkUploadSurveyQuestionComponent;
  let fixture: ComponentFixture<BulkUploadSurveyQuestionComponent>;
  let service: BffService;
  const eventQuestion = [{email:'test@gmail.com'}];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadSurveyQuestionComponent ],
      imports: [HttpClientModule,RouterTestingModule.withRoutes([])],
      providers: [BffService,FormBuilder,
        { provide: CommonMethods, useClass: class {} }
      ]

    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkUploadSurveyQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventQuestions = eventQuestion;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  
  it('should have data',()=>{
    expect(component.eventQuestions).not.toBeUndefined();
  })

  it('should create 6 of that', () => {
    const fields = Object.keys(component.surveyForm.controls);
    expect(fields.length).toBe(6);
  });
});
