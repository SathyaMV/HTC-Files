import { Component, OnInit } from '@angular/core';
import { ChartConfiguration,ChartOptions,Chart} from 'chart.js';
import { Subject, takeUntil } from 'rxjs';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-destination',
  templateUrl: './reports-destination.component.html',
  styleUrls: ['./reports-destination.component.css']
})
export class ReportsDestinationComponent implements OnInit {
  preferredDestinationData:any;
  destinationLabel = [];
  destinationData = [];
  isDataLoaded:boolean=false;
  scrWidth = window.innerWidth;
  testArray = [];
  private unsubscribe$ = new Subject<void>();
  public barChartOptions: ChartOptions

  constructor(private bff : BffService, private methods : CommonMethods) {
  }
  
  ngOnInit(): void {
    this.getwindowidth();
    this.getDestinationDetails()
  }
  
  getwindowidth(){
    if(this.scrWidth < 1200){
      Chart.defaults.datasets.bar.barThickness = 18;
    }else{
      Chart.defaults.datasets.bar.barThickness = 32;
    }
  }

  getDestinationDetails(){
    // setTimeout(() => {
      this.bff.destination.pipe(takeUntil(this.unsubscribe$)).subscribe(data =>{
        this.preferredDestinationData = data['destination'];
        this.testArray = [];
        this.preferredDestinationData.filter(ele => {
          this.testArray.forEach((itm: any) => itm.optionKey === ele.optionKey || itm.optionSequence === ele.optionSequence ?  itm.optionValue = ele.optionValue + itm.optionValue : ele.optionValue)
        if(!this.testArray.find((itm: any) => itm.optionKey === ele.optionKey || itm.optionSequence === ele.optionSequence)){
          this.testArray.push(ele); 
        }});
        this.preferredDestinationData = this.testArray.sort((a,b)=>a.optionSequence - b.optionSequence) 
        const index = this.preferredDestinationData.findIndex(ele=>ele.optionSequence == 7); 
        if(index != -1){
          this.preferredDestinationData[index].optionKey = 'No Data';
        }
         let totalRegistrationCount= data['totalRegistrationCount'];
         this.destinationLabel = [];
         this.destinationData = []; 
         if(this.preferredDestinationData?.length > 0){ 
           this.preferredDestinationData.map((e)=>{
             e.percent = Math.round((e.optionValue/totalRegistrationCount) * 100); 
             this.destinationLabel.push(e.optionKey);
             this.destinationData.push(e.optionValue);
           })
         }
         this.isDataLoaded = true;    
         this.barChartData= { 
           labels: this.destinationLabel,
           datasets: [
             { data: this.destinationData, backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df'}
           ]
         };
         this.barChartOptions= this.methods.barChartObject('chartjs-tooltip2',this.destinationData,'vertical')
       })      
      // }, 1000);
    }
  

  public barChartData: ChartConfiguration<'bar'>['data'] = {
    labels: this.destinationLabel,
    datasets: [
      { data: this.destinationData, backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df'}
    ],
  };
  
  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
