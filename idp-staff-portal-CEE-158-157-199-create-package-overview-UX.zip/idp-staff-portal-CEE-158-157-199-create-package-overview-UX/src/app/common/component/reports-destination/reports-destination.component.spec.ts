import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReportsDestinationComponent } from './reports-destination.component';

describe('ReportsDestinationComponent', () => {
  let component: ReportsDestinationComponent;
  let fixture: ComponentFixture<ReportsDestinationComponent>;
  let service: BffService

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsDestinationComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService)
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsDestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
