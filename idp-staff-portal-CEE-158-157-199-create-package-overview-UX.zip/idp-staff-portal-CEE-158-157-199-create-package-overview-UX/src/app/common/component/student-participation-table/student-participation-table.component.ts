import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { SelectionModel } from '@angular/cdk/collections';
import * as XLSX from 'xlsx';
import { BffService } from 'src/app/providers/bff.service';
import { Auth } from 'aws-amplify';
import * as moment from 'moment';

@Component({
  selector: 'app-student-participation-table',
  templateUrl: './student-participation-table.component.html',
  styleUrls: ['./student-participation-table.component.css']
})

export class StudentParticipationTableComponent implements OnInit {

  dataSource = new MatTableDataSource;
  filteredValue = new MatTableDataSource;
  displayValue = new MatTableDataSource;
  displayedColumns: string[] = ['select', 'eventName', 'hostedCountry', 'totalRegistrationCount', 'totalParticipantCount'];
  myControl = new FormControl('');
  countries: string[] = [];
  eventsName: string[] = [];
  filteredOptions!: Observable<string[]>;
  selection = new SelectionModel(true, []);
  disclaimerPopup: boolean = false;
  successPopup: boolean = false;
  startDate: Date;
  endDate: Date;
  currentPage: number = 1;
  itemsPerPage: number = 15;
  showLoaderIcon: boolean = false;
  canViewAdminReports: boolean = false;
  emailId: string = '';
  selectedEvents: string[] = [];
  maxRegistrations: number = 0;
  isLimitExceed: boolean = false;
  range = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
  });
  eventStartDates: Date[] = [];
  eventEndDates: Date[] = [];
  filteredCountry: string[] = [];
  searchValue: string = '';

  constructor(private _liveAnnouncer: LiveAnnouncer, private bff: BffService) { }
  private sort: MatSort
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
    Auth.currentAuthenticatedUser().then(user => {
      this.emailId = user.attributes.email
      this.bff.userPermission.subscribe(data => {
        this.canViewAdminReports = data['userAccess'].canViewAdminReports;
        if (this.canViewAdminReports) {
          this.getStudentParticipation();
        }
      })
    })
  }

  getStudentParticipation() {
    this.showLoaderIcon = true;
    this.bff.getStudentParticipation(this.emailId).subscribe({
      next: (res) => {
        this.dataSource.data = res.studentParticipantsDetails;
        this.filteredValue.data = this.dataSource.data;
        this.displayValue.data = this.filteredValue.data.slice(0, this.itemsPerPage);
        this.setStudentParticipation();
        this.showLoaderIcon = false;
      },
      error: () => { this.showLoaderIcon = false; }
    })
  }

  setStudentParticipation() {
    this.dataSource.data.forEach(element => {
      this.countries.push(element['hostedCountry']);
      this.eventStartDates.push(new Date(element['startDate']));
      this.eventEndDates.push(new Date(element['endDate']));
    });
    this.countries = [...new Set(this.countries)];
    this.filteredCountry = this.countries;
    this.eventStartDates.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    this.eventEndDates.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    this.startDate = this.eventStartDates[0];
    this.endDate = this.eventEndDates[this.eventEndDates.length - 1];
    this.myControl.setValue('');
  }

  private _filter(value: string): string[] {
    this.searchValue = value.toLowerCase();
    let searchFilter = this.appliedFilters();
    this.eventsName = [];
    if (this.searchValue.length >= 3) {
      this.filteredValue.data = searchFilter.filter((val) => val['eventName'].toLowerCase().includes(this.searchValue));
      this.currentPage = 1;
      this.eventsName = this.filteredValue.data.filter(option => option['eventName'].toLowerCase().includes(this.searchValue)).map(event => event['eventName']);
      this.eventsName = [...new Set(this.eventsName)];
    } else {
      this.filteredValue.data = searchFilter.slice(0);
    }
    this.setDisplayValue(this.currentPage);
    return this.eventsName;
  }

  appliedFilters() {
    let appliedFilters = this.dataSource.data.filter(value => 
      new Date(value['startDate']) >= this.startDate 
      && new Date(value['endDate']) <= this.endDate 
      && this.filteredCountry.includes(value['hostedCountry']))
    return appliedFilters;
  }

  announceSortChange(sortState: Sort) {
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.dataSource.data);
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.eventName + 1}`;
  }

  rowSelected(row) {
    this.maxRegistrations = 0;
    this.selection.selected.forEach(value => this.maxRegistrations += value.totalRegistrationCount)
    if (this.maxRegistrations > 3000) {
      this.selection.toggle(row);
      this.isLimitExceed = true;
      setTimeout(() => {
        this.isLimitExceed = false;
      }, 3000);
    }
  }

  checkBoxSelected(event, row) {
    this.maxRegistrations = 0;
    this.selection.selected.forEach(value => this.maxRegistrations += value.totalRegistrationCount)
    if (event.checked) {
      if ((this.maxRegistrations + row.totalRegistrationCount) > 3000) {
        event.checked = false;
        event.source.checked = false;
        this.isLimitExceed = true;
        setTimeout(() => {
          this.isLimitExceed = false;
        }, 3000);
      } else {
        this.selection.toggle(row);
      }
    } else {
      this.selection.deselect(row);
    }
  }

  closeLimitPopup() {
    this.isLimitExceed = false;
  }

  toggleDownload() {
    this.disclaimerPopup = !this.disclaimerPopup;
  }

  proceedReports() {
    this.disclaimerPopup = false;
    this.selectedEvents = [];
    if (this.selection.selected.length > 0) {
      this.selection.selected.forEach(value => {
        this.selectedEvents.push(value.cventEventCode);
      })
      this.getDownloadReports();
    }
  }

  getDownloadReports() {
    let downloadReports;
    let payLoad = {
      source: 'importStudentParticipantsReport',
      downloadFlag: 'Yes',
      staffEmailId: this.emailId,
      eventCode: this.selectedEvents
    }
    this.successPopup = true;
    setTimeout(() => {
      this.successPopup = false;
    }, 5000);
    this.bff.getStudentParticipationDownload(payLoad).subscribe({
      next: (res) => {
        if (res.studentParticipantsDetails?.length > 0) {
          downloadReports = res.studentParticipantsDetails.filter(value => {
            return this.selectedEvents.indexOf(value.eventCode) >= 0;
          });
          this.generateXLFile(downloadReports);
        }
      }
    })
  }

  generateXLFile(downloadReports) {
    let workbook = XLSX.utils.book_new();
    let wsTemplate = XLSX.utils.json_to_sheet(downloadReports);
    XLSX.utils.book_append_sheet(workbook, wsTemplate, "Participation");
    XLSX.writeFile(workbook, 'Students-Participation.csv');
  }

  closePopup() {
    this.successPopup = false;
  }

  filterByDate(type) {
    if (type == 'startDate') {
      this.startDate = moment(this.range.controls.startDate.value).isValid() ? new Date(this.range.controls.startDate.value) : this.eventStartDates[0];
    } else {
      this.endDate = moment(this.range.controls.endDate.value).isValid() ? new Date(this.range.controls.endDate.value) : this.eventEndDates[this.eventEndDates.length -1];
      this.endDate.setHours(23, 59, 59);
    }
    this.applyFilter();
  }

  filterByCountry(value) {
    this.filteredCountry = [];
    this.filteredCountry.push(value);
    this.applyFilter();
  }

  applyFilter() {
    this.filteredValue.data = this.appliedFilters()
    this.displayValue.data = this.filteredValue.data.slice(0, this.itemsPerPage);
    this.currentPage = 1;
    this.myControl.setValue(this.searchValue);
  }

  getPagination(pageNumber) {
    let startValue = ((pageNumber - 1) * this.itemsPerPage) + 1;
    let endValue = pageNumber * this.itemsPerPage > this.filteredValue.data.length ? this.filteredValue.data.length : pageNumber * this.itemsPerPage;
    return `Showing ${startValue} to ${endValue} of ${this.filteredValue.data.length}`
  }

  setDisplayValue(pageNumber) {
    let startValue = (pageNumber - 1) * this.itemsPerPage;
    let endValue = pageNumber * this.itemsPerPage;
    this.displayValue.data = this.filteredValue.data.slice(startValue, endValue);
    document.getElementById('studentHeader').scrollIntoView({ behavior: "smooth" });
  }

  setDataSourceAttributes() {
    this.displayValue.sort = this.sort;
  }

}
