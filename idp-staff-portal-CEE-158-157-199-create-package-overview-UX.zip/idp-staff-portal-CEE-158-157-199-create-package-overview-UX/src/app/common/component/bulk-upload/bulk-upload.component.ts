import { Component, EventEmitter, HostListener, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BffService } from '../../../providers/bff.service';
import * as XLSX from 'xlsx';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-bulk-upload',
  templateUrl: './bulk-upload.component.html',
  styleUrls: ['./bulk-upload.component.css']
})
export class BulkUploadComponent implements OnInit {

  importfiles;
  recordStatus;
  @Input() dragAndDrop:any;
  @Output() public showBulkUploadTable = new EventEmitter<any>();
  arrayBuffer:any
  @Output() public bulkUploadTableData = new EventEmitter<any>();
  @Output() public fileName = new EventEmitter<any>();
  privacyNotification = false;
  templateNotification = false;
  eventQuestions:any;
  totalRecords;
  cventCode;
  maximumRecordsError:boolean = false;
  dialCode

  constructor(private methods: CommonMethods, private bff: BffService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getCventCode();
    this.getEventQuestion();
  }
  getCventCode(){
    this.route.queryParams.subscribe(params=>{
      if(params.eventCode){
        this.cventCode = params.eventCode       
      }   
    })
  }

  getEventQuestion(){
    this.bff.getBulkUploadPPQuestions(this.cventCode,'EN').subscribe(data=>{
      this.eventQuestions = data.items[0].fields.questions
      this.dialCode = data['dialCode']
    })
    // this.eventQuestions = this.bff.getBulkUploadPPQuestion().questions[0].fields.questions
  }
  uploadstatus(){

  }

  toggleimportfiles(){
   document.body.classList.remove('hide_event');
   this.bff.showFileUploadScreen.next(false);
   this.bff.showBulkUploadSurveyQn.next(false);
  }

  droppedFiles(allFiles: File[]): void {
    const filesAmount = allFiles.length;
    // for (let i = 0; i < filesAmount; i++) {
    //   const file = allFiles[i];
    //   // this.allFiles.push(file);
    // }
    this.loadDropFile(allFiles)
  }

  loadDropFile(allFiles){
    this.recordStatus = true;
    let file = allFiles[0];   
    let fileName = allFiles[0].name;
    let fileReader = new FileReader(); 
    fileReader.readAsArrayBuffer(file);
    let bstr:any;     
    fileReader.onload = (e) => {  
        // errors = {}  
        this.templateNotification = false;
        this.arrayBuffer = fileReader.result;    
        let data = new Uint8Array(this.arrayBuffer);
        
        let arr = new Array();    
        for(var i = 0; i != data.length; ++i) 
          arr[i] = String.fromCharCode(data[i]);    
          bstr = arr.join("");    
        
        let workbook = XLSX.read(bstr, {type:"binary"});    
        let studentDetails = workbook.SheetNames[0];    
        let worksheet = workbook.Sheets[studentDetails];    
        let arraylist = XLSX.utils.sheet_to_json(worksheet,{raw:true,defval:''});
        this.totalRecords = arraylist.length;
        allFiles = '';
        let index=0;
        let excelArray = []
        let questionLabel = []
        this.eventQuestions?.filter(ele=>{
          questionLabel.push(ele.label) 
        })
        let mappingField = []
        this.eventQuestions?.filter(ele=>{
          mappingField.push(ele.mappingField) 
        })
        arraylist.forEach(list=>{
          let tmpObj = {}
          tmpObj['id'] = index;
          index++;
          Object.keys(list).forEach(ele=>{
            let condition = questionLabel.indexOf(ele)
            if(condition != -1){
              tmpObj[mappingField[condition]] = list[ele]
            }
          })
          excelArray.push(tmpObj);
        })
        if(mappingField.length == Object.keys(excelArray[0]).length - 1 && excelArray.length <= 1000){
          let excelJson = {
            excelData : excelArray,
            fileName : fileName
          }
          this.bff.excelFileObj.next(excelJson)
          // this.bulkUploadTableData.emit(excelArray)
          // this.showBulkUploadTable.emit(true);
          this.fileName.emit(fileName);
          this.bff.showbulkUploadTable.next(true);
        }else{
          excelArray.length > 1000 ? this.maximumRecords() : this.maximumRecordsError = false;
          mappingField.length != Object.keys(excelArray[0]).length - 1 ? this.incompatibleTemplate() : this.templateNotification = false;
        }
        setTimeout(() => {
          this.recordStatus = !this.recordStatus
        }, 1000);
    } 
  }

  loadFile(event) {
    this.recordStatus = true;
    let file = event.target.files[0];
    let fileName = event.target.files[0].name;
    let fileType = event.target.files[0].type.split('/')[1];
    if (fileName.includes('.csv') && fileType == 'csv') {
      let fileReader = new FileReader();
      fileReader.readAsArrayBuffer(file);
      let bstr: any;
      fileReader.onload = (e) => {
        // errors = {}  
        this.templateNotification = false;
        this.arrayBuffer = fileReader.result;
        let data = new Uint8Array(this.arrayBuffer);

        let arr = new Array();
        for (var i = 0; i != data.length; ++i)
          arr[i] = String.fromCharCode(data[i]);
        bstr = arr.join("");

        let workbook = XLSX.read(bstr, { type: "binary" });
        let studentDetails = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[studentDetails];
        let arraylist = XLSX.utils.sheet_to_json(worksheet, { raw: true, defval: '' });
        this.totalRecords = arraylist.length;
        event.target.value = '';
        let index = 0;
        let excelArray = []
        let questionLabel = []
        this.eventQuestions?.filter(ele => {
          questionLabel.push(ele.label)
        })
        let mappingField = []
        this.eventQuestions?.filter(ele => {
          mappingField.push(ele.mappingField)
        })
  
        if (arraylist.length > 0 && this.checkAttributes(questionLabel, arraylist[0])) {
        arraylist.forEach(list => {
          let tmpObj = {}
          tmpObj['id'] = index;
          index++;
          Object.keys(list).forEach(ele => {
            let condition = questionLabel.indexOf(ele)
            if (condition != -1) {
              tmpObj[mappingField[condition]] = list[ele]
            }
          })
          excelArray.push(tmpObj);
        })
        if (mappingField.length === Object.keys(arraylist[0]).length && mappingField.length == Object.keys(excelArray[0]).length - 1 && excelArray.length <= 1000) {
          let excelJson = {
            excelData: excelArray,
            fileName: fileName
          }
          this.bff.excelFileObj.next(excelJson)
          // this.bulkUploadTableData.emit(excelArray)
          // this.showBulkUploadTable.emit(true);
          this.fileName.emit(fileName);
          this.bff.showbulkUploadTable.next(true);
        } else {
          excelArray.length > 1000 ? this.maximumRecords() : this.maximumRecordsError = false;
          mappingField.length != Object.keys(arraylist[0]).length - 1 ? this.incompatibleTemplate() : this.templateNotification = false;
        }
        setTimeout(() => {
          this.recordStatus = !this.recordStatus
        }, 1000);
      } else {
        this.incompatibleTemplate();
        this.recordStatus = false;
      }
    }
    } else {
      this.incompatibleTemplate();
      this.recordStatus = false;
    }
  }

  checkAttributes(questions, value) {
    let keys = Object.keys(value)
    keys.sort();
    questions.sort();
    return JSON.stringify(keys) === JSON.stringify(questions)
  }

  downLoadTemplate(){
    this.methods.downLoadTemplate(this.eventQuestions,this.dialCode)
  }

  incompatibleTemplate(){
    this.templateNotification = !this.templateNotification;
  }

  maximumRecords(){
    this.maximumRecordsError = !this.maximumRecordsError;
  }
  

  privacyDisclaimer(){
    this.privacyNotification = !this.privacyNotification;
  }

  toggleupload(){

  }
}
