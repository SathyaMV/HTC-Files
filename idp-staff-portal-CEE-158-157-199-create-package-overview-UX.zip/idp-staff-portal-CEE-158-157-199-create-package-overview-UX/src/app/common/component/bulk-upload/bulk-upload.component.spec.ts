import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { BulkUploadComponent } from './bulk-upload.component';

describe('BulkUploadComponent', () => {
  let component: BulkUploadComponent;
  let fixture: ComponentFixture<BulkUploadComponent>;
  let service: BffService;
  const eventQuestion = [{email:'test@gmail.com'}];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadComponent],
      imports: [HttpClientModule,RouterTestingModule.withRoutes([])],
      providers: [BffService,
        { provide: CommonMethods, useClass: class {} }
      ]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventQuestions = eventQuestion;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventQuestions).not.toBeUndefined();
  })
});
