import { Component, OnInit } from '@angular/core';
import { ChartConfiguration, Chart} from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-pre-register-walkin',
  templateUrl: './reports-pre-register-walkin.component.html',
  styleUrls: ['./reports-pre-register-walkin.component.css']
})
export class ReportsPreRegisterWalkinComponent implements OnInit {

  preRegistrationCount : any;
  walkinCount : any;
  totalRegistrationCount : any;
  preRegisterPercentage : any;
  walkinPercentage : any;
  preRegisterWalkinArray = []
  isLoaded : boolean = false;
  scrWidth = window.innerWidth;
  public doughnutChartOptions4: ChartConfiguration<'doughnut'>['options']

  constructor(private bff : BffService, private methods : CommonMethods) {
  }

  ngOnInit(): void {
    this.getwindowidth();
    this.getPreRegisterWalkinDetails();
  }
  

  getwindowidth(){
    if(this.scrWidth < 1200){
      Chart.overrides.doughnut.cutout = 78
    }else{
      Chart.overrides.doughnut.cutout = 88
    }
  }

  getPreRegisterWalkinDetails(){
    setTimeout(() => {
      this.bff.preRegisterWalkin.subscribe((data)=>{
        this.preRegistrationCount = data['preRegistrationWalkin']['preRegistration'];
        this.walkinCount = data['preRegistrationWalkin']['walkIn'];
        this.totalRegistrationCount = data['totalRegistrationCount']
        this.preRegisterWalkinArray = [];
        this.preRegisterPercentage = Math.round((this.preRegistrationCount/this.totalRegistrationCount) * 100);
        this.walkinPercentage = Math.round((this.walkinCount/this.totalRegistrationCount) * 100);
        this.preRegisterWalkinArray.push( this.preRegistrationCount,this.walkinCount);
        this.isLoaded = true;  
        this.doughnutChartDatasets4 = [
          { data: this.preRegisterWalkinArray,
            backgroundColor: [
              '#FF8300',
              '#008260'
            ],
            hoverBackgroundColor:[
              '#e67700',
              '#007556'
            ],
            borderWidth:0
          }
        ];
        this.doughnutChartOptions4= this.methods.dognughtChartObj('chartjs-tooltip6',this.preRegisterWalkinArray)
      })
    }, 1000);
  }

  public doughnutChartDatasets4: ChartConfiguration<'doughnut'>['data']['datasets'] = [
    { data: this.preRegisterWalkinArray,
      backgroundColor: [
        '#FF8300',
        '#008260'
      ],
      hoverBackgroundColor:[
        '#e67700',
        '#007556'
      ],
      borderWidth:0
    }
  ];
}
