import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReportsPreRegisterWalkinComponent } from './reports-pre-register-walkin.component';

describe('ReportsPreRegisterWalkinComponent', () => {
  let component: ReportsPreRegisterWalkinComponent;
  let fixture: ComponentFixture<ReportsPreRegisterWalkinComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsPreRegisterWalkinComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsPreRegisterWalkinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
