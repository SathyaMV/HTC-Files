import { NgModule } from "@angular/core";
import { ReportsPreRegisterWalkinComponent } from "./reports-pre-register-walkin.component";
import { NgChartsModule } from 'ng2-charts'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from "@angular/common";


@NgModule({
    declarations: [ReportsPreRegisterWalkinComponent],
    imports:[NgChartsModule,
        MatFormFieldModule,
        MatOptionModule,
        MatSelectModule,
        CommonModule],
    exports:[
        ReportsPreRegisterWalkinComponent
    ]
})

export class PreRegisterWalkinModule{}