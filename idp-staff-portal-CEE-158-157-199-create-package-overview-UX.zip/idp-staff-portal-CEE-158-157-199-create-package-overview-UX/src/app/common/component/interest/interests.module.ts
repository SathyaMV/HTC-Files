import { CdkAccordionModule } from '@angular/cdk/accordion';
import { NgModule } from '@angular/core';
import { InterestsComponent } from './interests.component';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
    declarations: [InterestsComponent],
    imports:[CdkAccordionModule,MatButtonModule],
    exports:[
        InterestsComponent
    ]
})

export class InterestModule{

}