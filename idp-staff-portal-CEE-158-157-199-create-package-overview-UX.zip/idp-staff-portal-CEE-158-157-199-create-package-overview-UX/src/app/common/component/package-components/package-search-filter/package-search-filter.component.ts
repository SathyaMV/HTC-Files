import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Router } from '@angular/router';

@Component({
  selector: 'app-package-search-filter',
  templateUrl: './package-search-filter.component.html',
  styleUrls: ['./package-search-filter.component.css']
})
export class PackageSearchFilterComponent implements OnInit {

  check: boolean = false;
  searchmyControl = new FormControl('');
  filteredSearchOptions: any;
  resultCount = 0;
  searchValueBoolean: boolean = true;
  filterBtnLabel: string = 'Apply';
  upcomingSelectedIndex = null;
  pastSelectedIndex = null;
  upcomingContainer: ElementRef;
  pastContainer: ElementRef;
  hostCounntryList: Array<any> = [
    {
      "countryName": "Australia",
      "checked": false
    }, {
      "countryName": "Canada",
      "checked": true
    }, {
      "countryName": "USA",
      "checked": false
    }, {
      "countryName": "UK",
      "checked": false
    }
  ]

  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;
  


  constructor(private router: Router, @Inject(DOCUMENT) private document: Document) {
    this.document.addEventListener('click', this.offClickHandler.bind(this));
  }

  offClickHandler(event: any) {
    if (this.upcomingContainer != undefined && !this.upcomingContainer.nativeElement.contains(event.target)) {
      this.upcomingSelectedIndex = null;
    }
    if (this.pastContainer != undefined && !this.pastContainer.nativeElement.contains(event.target)) {
      this.pastSelectedIndex = null
    }

  }
  @ViewChild('upcomingPopup', { static: false }) set upcomingEventPopup(upcomingEventPopup: ElementRef) {
    if (upcomingEventPopup) { // initially setter gets called with undefined
      this.upcomingContainer = upcomingEventPopup;
    }
  }

  @ViewChild('pastPopup', { static: false }) set pastEventPopup(pastEventPopup: ElementRef) {
    if (pastEventPopup) { // initially setter gets called with undefined
      this.pastContainer = pastEventPopup;
    }
  }


  ngOnInit(): void {
  }

  openFilter() {
    if (!this.check) {
      this.check = true;
      document.body.classList.add('hide_body');
    } else {
      // this.removeSelectedFilters();
      this.check = false;
      document.body.classList.remove('hide_body');
    }
  }

  clearAllFilter() {
    this.hostCounntryList.forEach(ele => ele.checked = false)
  }

}
