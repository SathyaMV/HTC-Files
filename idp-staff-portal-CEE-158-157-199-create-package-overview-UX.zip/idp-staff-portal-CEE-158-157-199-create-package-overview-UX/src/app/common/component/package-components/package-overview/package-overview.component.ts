import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'

@Component({
  selector: 'app-package-overview',
  templateUrl: './package-overview.component.html',
  styleUrls: ['./package-overview.component.css']
})
export class PackageOverviewComponent implements OnInit {
  packageOverviewForm!: FormGroup
  invalidForm: boolean = false

  ngOnInit (): void {
    this.packageOverviewForm = new FormGroup({
      title: new FormControl('', [Validators.required]),
      description: new FormControl('', [Validators.required]),
      packageType: new FormControl('public'),
      boothSharing: new FormControl('no'),
      contactEmailId: new FormControl('', [Validators.required, Validators.email])
    })
  }
}
