import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'

import { EventGroup } from 'src/app/common/models/client-package.model'
import { ClientPackagesService } from 'src/app/providers/client-packages.service'

@Component({
  selector: 'app-event-group',
  templateUrl: './event-group.component.html',
  styleUrls: ['./event-group.component.css']
})
export class EventGroupComponent implements OnInit {
  pkgEventGroupList!: FormGroup

  eventGroups: EventGroup[] = []
  itemsPerPage: number = 20
  upcomingPageNumber: number = 1

  constructor (private readonly pkgService: ClientPackagesService) {}

  ngOnInit (): void {
    this.pkgEventGroupList = new FormGroup({
      selectedEventGroup: new FormControl([])
    })

    this.getEventGroupList()
    console.log(this.eventGroups)
  }

  getEventGroupList (): void {
    this.pkgService.getEventGroup().subscribe((groupList) => {
      this.eventGroups = []
      this.eventGroups = JSON.parse(JSON.stringify(groupList)).map(
        (data) => data
      )
    })
  }

  scrollTop (): void {
    document.getElementById('eventGroupContainer').scrollIntoView({ behavior: 'smooth' })
  }

  getPaginationNumber (pageNumber, len: number): string {
    const startValue = (pageNumber - 1) * this.itemsPerPage + 1
    const endValue =
      pageNumber * this.itemsPerPage > len
        ? len
        : pageNumber * this.itemsPerPage
    return `Showing ${startValue} to ${endValue} of ${len}`
  }
}
