import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { LocationStrategy } from '@angular/common';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../../common/utilities/common-methods'
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-overview-table',
  templateUrl: './overview-table.component.html',
  styleUrls: ['./overview-table.component.css']
})
export class OverviewTableComponent implements OnInit, OnDestroy {
  public toggle: boolean = false;
  myControl = new FormControl('');
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions!: Observable<string[]>;
  show = false;
  // qr popup start
  check: boolean = false;
  regCheck: boolean = false;
  qrCheck: boolean = false;
  entryCheck: boolean = false;
  // qr popup end

  @Input() eventInformationPage;
  myEventDetails;
  studentDetailsAvailable = false;
  eventRegisteredStudent = [];
  eventRegisteredCount: any;
  eventRegisteredSearchCount: number;
  attendedStatus: any;
  eventParticipatedStudent: any = [];
  eventParticipatedCount: any
  participantPercentage: any;
  circleProgress: any;
  match: any;
  searchData: any = '';
  searchResults: any = '';
  labelValue: any;
  showBtn: boolean = true;
  participatedPage: any;
  registeredPage: any;
  registerLastCount: number;
  registerStartCount: number;
  registerSearchLastCount: number = 10;
  participantStartCount: number;
  participantLastCount: number;
  participantSearchLastCount: number = 10;
  registerDefaultOption = 'Email';
  participateDefaultOption = 'Email';
  allEventsUrl = "idp-staff-portal/events-dashboard";
  filterMetadata: any = { count: 0 };
  mobileNumber;
  showQrScan: false;
  cventcode: string = '';
  eventUrl:string;
  eventTitle:string;
  scanQrData:boolean = false;
  showCheckInSuccess:boolean = false;
  showCheckInFail:boolean = false;
  importCheck:boolean=false;
  importfiles:boolean=false;
  recordStatus:boolean=false;
  dragAndDrop:boolean = false;
  showBulkUploadTable:boolean = false;
  bulkUploadTableData:any
  isLiveEvent;
  fileName;
  futureEvent;
  pastEvent
  showbulkUploadTable:boolean = false;
  isMobileUser:boolean = this.customMethod.isMobileUser();
  isEventCompleted:boolean = true;
  checkInResData:any
  notRegisteredMsg:boolean = false;
  eventCopyUrl:string = ''
  canViewReports:boolean = false
  canRegisterStudent:boolean = false
  isLinkCopied: boolean = false;
  canBulkuploadRegistrants: boolean = false;
  sanitizedCode:SafeHtml;
  isTruncated: boolean = false;
  isCollapsed: boolean = true;
  displayText: SafeHtml = '';

  constructor(private router:Router,private url: LocationStrategy, private bff: BffService,
              private customMethod : CommonMethods,private sanitizer: DomSanitizer
              ) { }


  ngOnInit() {
    this.myEventDetails = this.eventInformationPage?.eventOverviewDetails?.idpEventDetails;
    this.eventDescription()
    this.studentDetailsAvailable = this.eventInformationPage?.eventOverviewDetails?.hasOwnProperty('studentDetails')
    this.eventRegisteredStudent = this.eventInformationPage?.eventOverviewDetails?.studentDetails;
    this.eventRegisteredCount = this.eventInformationPage?.eventOverviewDetails?.studentDetails?.length !== undefined ? this.eventInformationPage?.eventOverviewDetails?.studentDetails?.length : '0';
    this.cventcode = this.url.path().split('=')[1]; 
    this.eventRegisteredStudent?.filter(ele => {
        this.attendedStatus = ele.attendedStatus;
        if (this.attendedStatus) {
          this.eventParticipatedStudent.push(ele);          
        }
      });
    this.eventParticipatedCount = this.eventParticipatedStudent?.length;
    this.bff.detectManualRegisterForm.subscribe(detect => {
      if(detect){
        this.bff.eventRegistrantData.subscribe(data =>{
          if(data){
            this.eventRegisteredStudent = data
            this.eventRegisteredCount = this.eventInformationPage?.eventOverviewDetails?.studentDetails?.length !== undefined ? this.eventRegisteredStudent?.length : this.eventInformationPage?.eventOverviewDetails?.studentDetails?.length;
            this.eventParticipatedStudent = [];
            this.eventRegisteredStudent?.filter(ele => { 
                this.attendedStatus = ele.attendedStatus;
                if (this.attendedStatus) {
                  this.eventParticipatedStudent.push(ele);
                }
              })
            this.eventParticipatedCount = this.eventParticipatedStudent?.length;
            this.bff.eventParticipantCount.next(this.eventParticipatedCount);
            this.bff.detectManualRegisterForm.next(false);
          } 
        })
      }
    })
    let startDate = this.myEventDetails.eventStartDate;
    let endDate = this.myEventDetails.eventEndDate;
    const startValues = startDate.split(/[^0-9]/);
    const startyear = parseInt(startValues[0], 10);
    const startmonth = parseInt(startValues[1], 10) - 1;
    const startday = parseInt(startValues[2], 10);
    const starthours = parseInt(startValues[3], 10)
    const startminutes = parseInt(startValues[4], 10)
    const startseconds = parseInt(startValues[5], 10)
    const formattedStartDate = new Date(startyear, startmonth, startday, starthours, startminutes, startseconds);
    const endValues = endDate.split(/[^0-9]/);
    const endYear = parseInt(endValues[0], 10);
    const endMonth = parseInt(endValues[1], 10) - 1;
    const endDay = parseInt(endValues[2], 10);
    const endHours = parseInt(endValues[3], 10)
    const endMinutes = parseInt(endValues[4], 10)
    const endSeconds = parseInt(endValues[5], 10)
    const formattedEndDate = new Date(endYear, endMonth, endDay, endHours, endMinutes, endSeconds);
    this.isLiveEvent = new Date() > formattedStartDate  && new Date() < formattedEndDate;
    this.pastEvent = new Date() > formattedEndDate;
    this.futureEvent = new Date < formattedStartDate;
    this.showBtn = this.myEventDetails?.eventDescription?.length < 301 ? true : false;
    this.eventParticpantPercentage();
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
    this.bff.showFileUploadScreen.subscribe(data=>{
      this.dragAndDrop = data;
    })

    this.bff.showBulkUploadSurveyQn.subscribe(data =>{
      this.importCheck = data;
    })

    this.bff.enableRegistrationForm.subscribe(data=>{
      this.entryCheck = data;
    })

    //read excel data to show table or not
    this.bff.excelFileData.subscribe(data=>{
      let fileName = data['fileName'];
      sessionStorage.setItem('fileName_'+sessionStorage.getItem('tabID'),fileName)
      if(data){
        data['excelData']?.length > 0 ? this.showbulkUploadTable = true : this.showbulkUploadTable = false;
      } 
    })
    this.checkEventStatus();
    this.generatEventUrl(this.myEventDetails.eventCountry.trim())
    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canViewReports = data['userAccess'].canViewReports
      this.canRegisterStudent = data['userAccess'].canRegisterStudent
      this.canBulkuploadRegistrants = data['userAccess'].canBulkuploadRegistrants
    })
  }
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  //This method is used to find participant Percentage 
  eventParticpantPercentage() {
    let eventParticipantPercent = Math.round(((this.eventParticipatedCount / this.eventRegisteredCount) * 100));
    let isNan = isNaN(eventParticipantPercent);
    if(!isNan){
      this.participantPercentage = eventParticipantPercent
    }else{
      this.participantPercentage = '0'   
    }  
    this.circleProgress = (144 - (144 * this.participantPercentage) / 100);
  }
  // qr popup start
  toggleScanner() {
    this.check = !this.check;
    document.body.classList.add('hide_body'); 
  }

  closeScanner() { 
    this.check = !this.check;
    document.body.classList.remove('hide_body');
    document.body.classList.remove('hide_event');
    this.bff.showBulkUploadSurveyQn.next(false);
    this.bff.showFileUploadScreen.next(false);
  }

  errorCloseScanner(){
    this.showCheckInFail = false
  }

  getCameraPermission() {
    navigator.mediaDevices.getUserMedia({ audio: false, video: true })
      .then((stream) => {
        // microphone available
        return true;
      }, e => {
        // microphone not available
        return false;
      });
  }

  regPopup() {
    this.entryCheck = !this.entryCheck;
    this.regCheck = false;
    this.bff.enableRegistrationForm.next(true);
    document.body.classList.add('hide_event');
  }
  togglePopup() {
    this.regCheck = !this.regCheck;
  }
  qrPopup() {
    this.bff.showEventQrCode.next(true)
  }
  // qr popup end

  scanCompleted(data) {
    if (data && 'text' in data && !this.scanQrData) {
      this.scanQrData = true
      this.studentQRCheckIn(data.text);
    }
  }

  studentQRCheckIn(uuid){
    let inPayLoad = {
    "idpEventId": this.eventInformationPage.eventOverviewDetails.idpEventDetails.eventId,
    "studentId": uuid,
    "correlationId": this.customMethod.correlationId(),
    "cventCode": this.eventInformationPage.eventOverviewDetails.idpEventDetails.cventCode,
    "cventAccountId": this.eventInformationPage.eventOverviewDetails.idpEventDetails.cventAccountId
    }
    this.bff.studentQRCheckIn(inPayLoad).subscribe(data=>{
      this.checkInResData = data
      sessionStorage.setItem('studentId_'+sessionStorage.getItem('tabID'),uuid)
      if(data['message'] != 'You cant check-in to the event!'){
        this.showCheckInSuccess = true;
        document.body.classList.remove('hide_body');
        setTimeout(() => {
          this.showCheckInSuccess = false;
          this.router.navigateByUrl('idp-staff-portal/student-profile');
        }, 1000);
      }else{
        // this.notRegisteredMsg = true;
        // setTimeout(() => {
        //   this.check = false;
        // }, 2000);
        this.check = false;
        this.showCheckInFail = true;
      }
    },error =>{
      this.check = false;
      this.showCheckInFail = true;
      this.scanQrData = !this.scanQrData
    });
    
  }

  backToScanner(){
    this.scanQrData = false;
    this.check = true;
    this.showCheckInFail = false
  }

  //event url for the event qr code
  // getEventUrl(){
  //   this.cventcode =  this.url.path().split('=')[1]
  //   this.eventUrl = environment.eventCopyUrl + this.myEventDetails.eventCountry + '/' + this.cventcode;
  //   this.eventTitle = this.myEventDetails?.eventTitle
  // }

  toggleupload() {
    document.body.classList.add('hide_event');
    this.bff.showBulkUploadSurveyQn.next(true);
  }

  // dragAndDropEmit(event){
  //   this.dragAndDrop = true; 
  // }

  showBulkUploadTableMethod(event){
    this.showBulkUploadTable = true
  }

  bulkUploadTableDataEmit(event){
    this.bulkUploadTableData = event;
  }
  fileNameEmit(event){
    this.fileName = event
  }

  closeSurveyEmit(event){
    
    if(this.importCheck == event){
      this.importCheck = true;
      document.body.classList.add('hide_body');
    }else{
      this.importCheck = false;
      document.body.classList.remove('hide_body');
    }  
  }

  kisokPage(){
    window.open(environment.kioskUrl+this.cventcode)
  }

  checkEventStatus() {
    let currentDate = new Date()
    let startDate = new Date(this.myEventDetails.eventStartDate);
    let endDate = new Date(this.myEventDetails.eventEndDate)
    startDate.setHours(startDate.getHours()-2);
    endDate.setHours(endDate.getHours()+2);
    if (currentDate >= startDate && currentDate <= endDate) {
      this.isEventCompleted = false;
    }
  }

  openCopiedPopup() {
    this.isLinkCopied = true;
    setTimeout(() => {
      this.isLinkCopied = false;
    }, 3000);
  }

  closeCopiedPopup() {
    this.isLinkCopied = false;
  }

  generatEventUrl(eventCountry){
    let country = ''
    eventCountry.split(' ').filter(ele=>{
      country += ele
    })
    this.eventCopyUrl = environment.eventCopyUrl + country.trim().toLowerCase() + '/'  + this.myEventDetails.cventCode
  }

  ngOnDestroy(): void {
    this.closeScanner();
    this.bff.showEventQrCode.next(false);
  }
 //This method is used to show the event description by hiding the html tags
  eventDescription(){
    if (this.myEventDetails?.eventDescription.trim().length > 300) {
      const truncatedText = this.myEventDetails?.eventDescription.slice(0, 300) + '...';
      const sanitizedText = this.sanitizer.bypassSecurityTrustHtml(truncatedText);
      this.displayText = sanitizedText;
      this.isTruncated = true;
    }else {
      const sanitizedText = this.sanitizer.bypassSecurityTrustHtml(this.myEventDetails?.eventDescription);
      this.displayText = sanitizedText;
    }
  }
 //This method is used to toggle the event description for show more and show less
  toggleDisplay() {
    this.isCollapsed = !this.isCollapsed;
    if (this.isCollapsed) {
      const truncatedText = this.myEventDetails?.eventDescription.slice(0, 300) + '...';
      const sanitizedText = this.sanitizer.bypassSecurityTrustHtml(truncatedText);
      this.displayText = sanitizedText;
      this.toggle = false
    } else {
      const sanitizedText = this.sanitizer.bypassSecurityTrustHtml(this.myEventDetails?.eventDescription);
      this.displayText = sanitizedText;
      this.toggle = true
    }
  }
}
