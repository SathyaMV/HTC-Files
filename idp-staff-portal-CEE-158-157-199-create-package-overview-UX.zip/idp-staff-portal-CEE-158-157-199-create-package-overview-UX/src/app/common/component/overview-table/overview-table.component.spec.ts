import { CdkAccordionModule } from '@angular/cdk/accordion';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { OverviewTableComponent } from './overview-table.component';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { HttpClientModule } from '@angular/common/http';


describe('OverviewTableComponent', () => {
  let component: OverviewTableComponent;
  let fixture: ComponentFixture<OverviewTableComponent>;
  let service: BffService;
  const myEventDetailsAvailable = [{eventName : 'virtual'}]
  const registeredStudent = [{register : ' student'}]
  const participatedStudent = [{participate : 'student'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverviewTableComponent ],
      imports: [RouterTestingModule, CdkAccordionModule, MatTabsModule, NoopAnimationsModule,HttpClientModule],
      providers: [BffService,
        { provide: CommonMethods, useClass: class {} }
      ]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
    fixture = TestBed.createComponent(OverviewTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.myEventDetails = myEventDetailsAvailable
    component.eventRegisteredStudent = registeredStudent
    component.eventParticipatedStudent = participatedStudent
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.myEventDetails).not.toBeUndefined();
    expect(component.eventRegisteredStudent).not.toBeUndefined();
    expect(component.eventParticipatedStudent).not.toBeUndefined();
  })

  describe('search form with value email',()=>{
    it('should bind the configured value', async(() => {
      expect(component.registerDefaultOption).toBe('Email');
    })); 
    it('should search value',()=>{
      fixture.whenStable().then(() => {
        expect(component.myControl).toBe('vir');
        expect(component.myControl.value.length).not.toBeLessThan(3);
      });
    });
  }) 
});
