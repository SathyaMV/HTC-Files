import { Component, Input, OnInit } from '@angular/core';
import { BffService } from '../../../providers/bff.service';

@Component({
  selector: 'app-generate-student-qr-code',
  templateUrl: './generate-student-qr-code.component.html',
  styleUrls: ['./generate-student-qr-code.component.css']
})
export class GenerateStudentQrCodeComponent implements OnInit {
  studentQrCode = false;
  allEventsUrl = "idp-staff-portal/events-dashboard";
  @Input() eventDetails
  studentId:any;
  constructor(private bffService:BffService) { }

  ngOnInit(): void {
    this.studentId = this.eventDetails?.studentProfileId
  }

  closeStudentQr(){
    this.bffService.showStudentQrCode.next(false);
    document.body.classList.remove('hide_body');
  }

}
