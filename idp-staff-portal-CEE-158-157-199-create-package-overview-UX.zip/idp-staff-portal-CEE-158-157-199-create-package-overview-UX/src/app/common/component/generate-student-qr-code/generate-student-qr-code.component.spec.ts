import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GenerateStudentQrCodeComponent } from './generate-student-qr-code.component';
import { BffService } from '../../../providers/bff.service';
import { HttpClientModule } from '@angular/common/http';

describe('GenerateStudentQrCodeComponent', () => {
  let component: GenerateStudentQrCodeComponent;
  let fixture: ComponentFixture<GenerateStudentQrCodeComponent>;
  let service: BffService;
  const eventDetails = [{test:'testname'}];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ GenerateStudentQrCodeComponent ],
      providers: [BffService]
    })
    .compileComponents();
   
    fixture = TestBed.createComponent(GenerateStudentQrCodeComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(BffService);
    fixture.detectChanges();
    component.eventDetails = eventDetails;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventDetails).not.toBeUndefined();
  })
});
