import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { InterestModule } from 'src/app/common/component/interest/interests.module';
import { PreferenceModule } from 'src/app/common/component/preferences/preferences.module';
import { ReferralModule } from 'src/app/common/component/referrals/referrals.module';
import { LeadManagementComponent } from './lead-management.component';


@NgModule({
    declarations: [LeadManagementComponent],
    imports:[PreferenceModule,
             InterestModule,
             ReferralModule,
             CommonModule],
    exports:[
        LeadManagementComponent
    ]
})

export class LeadManagementModule{}