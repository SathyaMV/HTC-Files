import { Component, Input } from '@angular/core';
import { BffService } from 'src/app/providers/bff.service';

@Component({
  selector: 'app-lead-management',
  templateUrl: './lead-management.component.html',
  styleUrls: ['./lead-management.component.css']
})
export class LeadManagementComponent { 
  @Input() preferenceQnData;
  preferenceAnswer;
  referralData = [{}]

  constructor(private bff: BffService) { }

  ngOnInit(): void {
    this.getLeadManagementDetails();
  }

  getLeadManagementDetails(){
    const eventId = sessionStorage.getItem('eventId_'+sessionStorage.getItem('tabID'))
    const studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
    this.bff.getPreferenceAnswer(eventId,studentId).subscribe(data =>{ 
      this.preferenceAnswer = data['response']['preferences']; 
      this.referralData = data['response']['referral']
    })
  }
}
