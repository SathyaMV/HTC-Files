import { Component, OnInit } from '@angular/core';
import { ChartConfiguration, Chart} from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-new-existing-student',
  templateUrl: './reports-new-existing-student.component.html',
  styleUrls: ['./reports-new-existing-student.component.css']
})
export class ReportsNewExistingStudentComponent implements OnInit {

  newStudentCount : any;
  existingStudentCount : any;
  totalRegistrationCount : any;
  newStudentPercentage : any;
  existingStudentPercentage : any;
  newExistingStudentArray = [];
  isLoaded : boolean = false
  public doughnutChartOptions3: ChartConfiguration<'doughnut'>['options']
  scrWidth = window.innerWidth;
  constructor(private bff : BffService, private methods : CommonMethods) {
  }
  ngOnInit(): void {
    this.getwindowidth();
    this.getNewExistingDetails()
  }
  getwindowidth(){
    if(this.scrWidth < 1200){
      Chart.overrides.doughnut.cutout = 78
    }else{
      Chart.overrides.doughnut.cutout = 88
    }
  }

  getNewExistingDetails(){
    // setTimeout(() => {
      this.bff.newExistingStudent.subscribe((data)=>{
        this.newStudentCount= data['newExistingStudent']?.['newStudent'];
        this.existingStudentCount = data['newExistingStudent']['ExistingStudent'];
        this.totalRegistrationCount = data['totalRegistrationCount'];
        this.newExistingStudentArray = [];
        this.newStudentPercentage = Math.round((this.newStudentCount/this.totalRegistrationCount) * 100);
        this.existingStudentPercentage = Math.round((this.existingStudentCount/this.totalRegistrationCount) * 100);
        this.newExistingStudentArray.push( this.newStudentCount,this.existingStudentCount);
        this.isLoaded = true; 
        this.doughnutChartDatasets3 = [
          { data: this.newExistingStudentArray,
            backgroundColor: [
              '#0086F8',
              '#FF8300'
            ],
            hoverBackgroundColor:[
              '#0077df',
              '#e67700'
            ],
            borderWidth:0
          }
        ];
        this.doughnutChartOptions3 = this.methods.dognughtChartObj('chartjs-tooltip4',this.newExistingStudentArray)
      })
    // }, 1000);
  }

  public doughnutChartDatasets3: ChartConfiguration<'doughnut'>['data']['datasets'] = [
    { data: this.newExistingStudentArray,
      backgroundColor: [
        '#0086F8',
        '#FF8300'
      ],
      hoverBackgroundColor:[
        '#0077df',
        '#e67700'
      ],
      borderWidth:0
    }
  ];
}
