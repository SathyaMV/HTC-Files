import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BffService } from 'src/app/providers/bff.service';

@Component({
  selector: 'app-audit-log',
  templateUrl: './audit-log.component.html',
  styleUrls: ['./audit-log.component.css']
})
export class AuditLogComponent implements OnInit, OnDestroy {

  importRegistrantsDetails;
  eventId: string = '';
  logId: string = '';
  showLoaderIcon: boolean = false;
  constructor(private bff: BffService, private activeRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.showLoaderIcon = true;
    this.activeRoute.queryParams.subscribe((params) => {
      this.eventId = params.eventId;
      this.logId = params.logId;
      this.bff.getRegistrantsDetails(this.eventId, this.logId).subscribe({
        next: (res) => {
          this.importRegistrantsDetails = res.importRegistrantsDetails[0];
          this.showLoaderIcon = false;
        }, error: () => {
          this.showLoaderIcon = false;
        }
      })
    })
  }

  closeAuditLog() {
    this.router.navigateByUrl('idp-staff-portal/import-registrants')
  }

  ngOnDestroy(): void {
    this.closeAuditLog();
  }

}
