import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EducationComponent } from './education.component';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonMethods } from '../../utilities/common-methods';
import { FormBuilder } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';

describe('EducationComponent', () => {
  let component: EducationComponent;
  let fixture: ComponentFixture<EducationComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EducationComponent],
      imports: [CdkAccordionModule,
        BrowserAnimationsModule,
        MatFormFieldModule,
        MatSelectModule,
        MatAutocompleteModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatInputModule,
        HttpClientModule],
        providers:[
          { provide: CommonMethods, useClass: class {} },
          FormBuilder,
          BffService,
          DatePipe
        ]    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EducationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
