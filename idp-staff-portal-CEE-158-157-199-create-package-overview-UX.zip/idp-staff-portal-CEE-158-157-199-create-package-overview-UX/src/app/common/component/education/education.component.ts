import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { CommonMethods } from '../../utilities/common-methods';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { BffService } from '../../../providers/bff.service';
import { DatePipe } from '@angular/common';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD',
  },
  display: {
    dateInput: 'DD MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css'],
  providers:[
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class EducationComponent implements OnInit {
  @Input() qualificationQnData;
  @Input() englishProficiencyQnData;
  @Input() qualificationAnswer;
  @Input() proficiencyAnswer;
  @Input() doYouWishAnswer;
  @Input() tabChange
  qualificationForm:FormGroup;
  proficiencyForm:FormGroup;
  qualificationSubmitted:boolean =false;
  proficiencySubmitted:boolean =false;
  completedStatus:boolean = false;
  showTestType:boolean = false;
  showTestResult:boolean = false;
  showExamWish:boolean = false;
  isDigit:boolean = false;
  studentId;
  countryCode;
  graduationDate;
  currentlyStudyingActive:boolean = false;
  qualificationSuccessMessage:boolean = false;
  proficiencySuccessMessage:boolean = false;
  proficiencyInitialValue;
  qualificationInitialValue
  instutionName;
  status;
  testTypeMandatory :boolean =false; 
  canEditStudentDetails:boolean = false
  countryArr = [
    {
      option_value : '2415',
      option_desc : 'Stanford University'
    },
    {
      option_value : '2416',
      option_desc : 'University of Cambridge'
    },
    {
      option_value : '2414',
      option_desc : 'Victoria University'
    },
    {
      option_value : '2417',
      option_desc : 'University of California'
    },
    {
      option_value : '2418',
      option_desc : 'Princeton University'
    }
  ]

  constructor(private commanMethods:CommonMethods,private fb: FormBuilder,private bff: BffService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.qualificationForm = this.fb.group({});
    this.proficiencyForm = this.fb.group({
      doYouWish : [this.doYouWishAnswer?.doYouWishToTakeTheIELTSExamWithIDP ? this.doYouWishAnswer?.doYouWishToTakeTheIELTSExamWithIDP : '']
    })
    this.qualificationFormControl();
    this.englishProficiencyFormControl();  
     let testStatusData = this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest ?  this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest : '' ;
     this.loadQuestion(testStatusData); 

    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canEditStudentDetails = !data['userAccess'].canEditStudentDetails
    })
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.tabChange != undefined){
      this.proficiencySubmitted = false
    } 
  }


  qualificationFormControl(){
    this.qualificationQnData?.forEach(element => {
      if(element){  
        if(element.mappingField === 'highestEducation'){
          this.qualificationForm.addControl(element.mappingField, new FormControl(this.qualificationAnswer?.highestQualification ? this.qualificationAnswer?.highestQualification : ''));
        }else if(element.mappingField === 'issuedCountry'){
          let countryOfQualification = this.qualificationAnswer?.countryOfQualification ? this.qualificationAnswer?.countryOfQualification.split('-') : '';
          this.qualificationForm.addControl(element.mappingField, new FormControl(countryOfQualification[1] ? countryOfQualification[1] : ''));
        }else if(element.mappingField === 'graduationDate'){
          this.qualificationForm.addControl(element.mappingField, new FormControl(this.qualificationAnswer?.dateOfCompletion ? this.qualificationAnswer?.dateOfCompletion : ''));
        }else if(element.mappingField === 'institution'){
          this.qualificationForm.addControl(element.mappingField, new FormControl(this.qualificationAnswer?.currentSchoolUniversity ? this.qualificationAnswer?.currentSchoolUniversity : ''));
        }else if(element.mappingField === 'percentage'){
          this.qualificationForm.addControl(element.mappingField, new FormControl(this.qualificationAnswer?.score ? this.qualificationAnswer?.score : '' , [Validators.pattern("^[0-9]*$")]));
        }else if(element.mappingField === 'numberOfBacklogsOrRetakes'){
          this.qualificationForm.addControl(element.mappingField, new FormControl(this.qualificationAnswer?.backlogs ? this.qualificationAnswer?.backlogs : '' ,[Validators.pattern("^[0-9]*$")]));
        }
      }
    })
    this.qualificationInitialValue = this.qualificationForm.value
  }

  englishProficiencyFormControl(){  
    this.englishProficiencyQnData?.forEach(ele =>{
      let testType = '';
      let testResult = '';
      if(this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest === 'Completed' && this.proficiencyAnswer?.testType !== ''){
        testType = this.proficiencyAnswer?.testType;
        testResult = this.proficiencyAnswer?.testResult;
        this.proficiencyForm.get('doYouWish').patchValue('');
      }else if (this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest === 'Currently Studying' && this.proficiencyAnswer?.testType !== ''){
        testType = this.proficiencyAnswer?.testType;
        testResult = ''
        this.proficiencyForm.get('doYouWish').patchValue(this.doYouWishAnswer?.doYouWishToTakeTheIELTSExamWithIDP);
      }else{
        this.proficiencyForm.get('doYouWish').patchValue(this.doYouWishAnswer?.doYouWishToTakeTheIELTSExamWithIDP);
      }
      if(ele.mappingField === 'englishLanguageTestStatus'){  
        this.proficiencyForm.addControl(ele.mappingField, new FormControl(this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest ? this.proficiencyAnswer?.whatIsTheStatusOfEnglishLanguageTest : ''));  
      }else if(ele.mappingField === 'englishTestType'){
        this.proficiencyForm.addControl(ele.mappingField, new FormControl(testType));
      }else if(ele.mappingField === 'englishLangOverallScore'){
        this.proficiencyForm.addControl(ele.mappingField, new FormControl(this.proficiencyAnswer?.testResult ? this.proficiencyAnswer?.testResult : ''));
      } 
    })
    this.proficiencyInitialValue = this.proficiencyForm.value
  }

  backlogValidation(){
    const noOfBacklog = this.qualificationForm.controls.numberOfBacklogsOrRetakes.value
    const pattern = /^[0-9]*$/;
    if (!isNaN(noOfBacklog) && (noOfBacklog < 0 || noOfBacklog > 50)) {
      this.qualificationForm.controls['numberOfBacklogsOrRetakes'].setErrors({ 'incorrect': true })
    }
    if (!pattern.test(noOfBacklog)) {
      this.qualificationForm.controls['numberOfBacklogsOrRetakes'].setErrors({ 'patternError': true })
    }
  }

  scoreValidation(){
    const score = this.qualificationForm.controls.percentage.value
    const pattern = /^[0-9]*$/;
    if (!isNaN(score) && (score < 0 || score > 100)) {
      this.qualificationForm.controls['percentage'].setErrors({ 'scoreIncorrect': true })
    }
    if (!pattern.test(score)) {
      this.qualificationForm.controls['percentage'].setErrors({ 'scorePatternError': true })
    }
  }

  qualificationSaveBtn(){
    this.qualificationSubmitted = true;
    this.scoreValidation();
    this.backlogValidation();  
    if (this.qualificationForm.invalid) {
      return;
    }else{
      let studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
      const dateFormat = this.qualificationForm.value.graduationDate._d
      this.graduationDate = !this.qualificationForm.value.graduationDate.hasOwnProperty('_d')? this.qualificationForm.value.graduationDate : this.datePipe.transform(dateFormat,'YYYY-MM-dd');
      this.qualificationQnData.filter(ele => {
        if(ele.mappingField === "issuedCountry"){
            ele.options.filter(response =>{
            if(response.option_desc === this.qualificationForm.value.issuedCountry) {
              this.countryCode = response.option_value+'-'+response.option_desc;
            }
          })
        }
      });
    this.countryArr.forEach(data =>{
      if(data.option_value === this.qualificationForm.value.institution){
        this.instutionName = data.option_desc;
      }   
    })
      const qualificationPayload = {
        studentEducationDetails : {
        studentUuid: studentId,
        highestQualification: this.qualificationForm.value.highestEducation ? this.qualificationForm.value.highestEducation : '',
        countryOfQualification: this.countryCode ? this.countryCode : '',
        dateOfCompletion: this.graduationDate ? this.graduationDate  : '',
        currentSchoolUniversity: this.qualificationForm.value.institution ? this.qualificationForm.value.institution: '',
        score: this.qualificationForm.value.percentage ? this.qualificationForm.value.percentage : '',
        backlog: this.qualificationForm.value.numberOfBacklogsOrRetakes ? this.qualificationForm.value.numberOfBacklogsOrRetakes : '',
        whatIsTheStatusOfEnglishLanguageTest:"",
        testType:"",
        testResult:"",
        institutionName: ""
        }
      }
      this.bff.updateEducationDetails(qualificationPayload).subscribe(data =>{ 
        if(data){
          this.qualificationSuccessMessage = true
          setTimeout(() => {
            this.qualificationSuccessMessage = !this.qualificationSuccessMessage
          }, 3000);
        }    
      }) 
    }
  }

  testStatus(status){ 
    this.status = status;
    if(status === 'Completed'){
      this.currentlyStudyingActive = false;
      this.showTestType = true;
      this.showTestResult = true
      this.showExamWish = false;
      this.proficiencySubmitted = false;
      this.testTypeMandatory = true;
      this.proficiencyForm.get('englishLangOverallScore').patchValue('');
      this.proficiencyForm.get('englishTestType').patchValue('');
      this.proficiencyForm.get('doYouWish').patchValue('');
    }else if(status === 'Not taken'){
      this.currentlyStudyingActive = false;
      this.showTestType = false;
      this.showTestResult = false;
      this.showExamWish = true; 
      this.testTypeMandatory = false;
      this.proficiencyForm.get('doYouWish').patchValue('');
    }else if(status === 'Currently Studying'){
      this.currentlyStudyingActive = true;
      this.showTestType = true;
      this.showExamWish = true;
      this.showTestResult = false;
      this.proficiencySubmitted = false;
      this.testTypeMandatory = false;
      this.proficiencyForm.get('doYouWish').patchValue('');
      this.proficiencyForm.get('englishTestType').patchValue('');
    }
  }

  loadQuestion(testStatusData){
     let status = testStatusData
     if(status === 'Completed'){
       this.currentlyStudyingActive = false;
       this.showTestType = true;
       this.showTestResult = true
       this.showExamWish = false;
       this.proficiencySubmitted = false;
     }else if(status === 'Not taken'){
       this.currentlyStudyingActive = false;
       this.showTestType = false;
       this.showTestResult = false;
       this.showExamWish = true; 
     }else if(status === 'Currently Studying'){
       this.currentlyStudyingActive = true;
       this.showTestType = true;
       this.showExamWish = true;
       this.showTestResult = false;
       this.proficiencySubmitted = false;
     }
  }

  proficiencySaveBtn(){
    this.proficiencySubmitted = true;
    if (this.proficiencyForm.invalid) {
      return;
    }else{ 
      let studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'));
      let eventId = sessionStorage.getItem('eventId_'+sessionStorage.getItem('tabID'));
      const proficiencyPayload = {
        studentEducationDetails : {
          studentUuid: studentId,
          highestQualification: "",
          countryOfQualification:"" ,
          dateOfCompletion: "",
          currentSchoolUniversity: "",
          score:"",
          backlog: "",
          whatIsTheStatusOfEnglishLanguageTest: this.proficiencyForm.value.englishLanguageTestStatus ? this.proficiencyForm.value.englishLanguageTestStatus : '',
          testType: this.proficiencyForm.value.englishTestType ? this.proficiencyForm.value.englishTestType : '',
          testResult: this.proficiencyForm.value.englishLangOverallScore ? this.proficiencyForm.value.englishLangOverallScore : '',
          institutionName: this.instutionName ? this.instutionName : ''
        }
    };
     if(this.proficiencyForm.value.englishLanguageTestStatus !== ''){
      if(this.proficiencyForm.value.englishLanguageTestStatus === 'Completed'){
        if(this.proficiencyForm.value.englishTestType !== '' && this.proficiencyForm.value.englishLangOverallScore !== ''){
          this.updateEducationDetails(proficiencyPayload)
        }
      }else if(this.proficiencyForm.value.englishLanguageTestStatus === 'Currently Studying'){
        this.updateEducationDetails(proficiencyPayload)
      }else if(this.proficiencyForm.value.englishLanguageTestStatus === 'Not taken'){
        proficiencyPayload.studentEducationDetails.testType='';
        proficiencyPayload.studentEducationDetails.testResult='';
        this.updateEducationDetails(proficiencyPayload)
      } 
     }
     
      const doYouWishPayload = {
        studentEducationDetails:{
          doYouWishTakeTheIeltsExamWithIdp: this.proficiencyForm.value.doYouWish ? this.proficiencyForm.value.doYouWish : '',
          idpEventId:eventId,
          studentUuid:studentId
        }
      }
      if(this.proficiencyForm.value.doYouWish !== "" && this.proficiencyForm.value.englishLanguageTestStatus !== 'Completed'){
      this.bff.updateEnglishProficiency(doYouWishPayload).subscribe()
      }}
  }

  updateEducationDetails(proficiencyPayload) {
    this.bff.updateEducationDetails(proficiencyPayload).subscribe(data =>{
      if(data){
        this.proficiencySuccessMessage = true
        setTimeout(() => {
          this.proficiencySuccessMessage = !this.proficiencySuccessMessage
        }, 3000);
      }    
    })
  }

  qualificationCancelBtn(){
    this.qualificationForm.reset(this.qualificationInitialValue)
  }

  proficiencyCancelBtn(){
    this.proficiencyForm.reset(this.proficiencyInitialValue)
  }
}
