import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BffService } from 'src/app/providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-add-staff',
  templateUrl: './add-staff.component.html',
  styleUrls: ['./add-staff.component.css']
})
export class AddStaffComponent implements OnInit {
  @Output() checkInPopup = new EventEmitter<string>();
  @Output() getStaffData = new EventEmitter<any>()
  addStaffForm: FormGroup;
  submitted:boolean=false;
  showLoaderIcon:boolean = false;
  userLoginStatus:boolean = false

  constructor(private fb: FormBuilder,private methods: CommonMethods,private bff: BffService) { }

  ngOnInit(): void {
    this.addStaffForm = this.fb.group({
      fullName:['',[Validators.required,Validators.maxLength(40),this.methods.removeSpaces]],
      emailAddress:['',[Validators.required,this.methods.emailValidation,this.methods.removeSpaces]]
    })    
  }

  sendInviteBtn(){ 
    this.submitted = true;
    if (this.addStaffForm.invalid) {
      return;
    }else{
      this.showLoaderIcon = true;
      const eventId =  sessionStorage.getItem('idpEventId_'+ sessionStorage.getItem('tabID'));
      this.bff.checkStaffDetails(this.addStaffForm.value.emailAddress.toLowerCase()).subscribe(data => {
        this.userLoginStatus = data?.userLoginStatus ? data?.userLoginStatus : false;
        const staffPayload = {
          addStaffDetails : {
            idpEventId: eventId,
            fullName : this.addStaffForm.value.fullName ? this.addStaffForm.value.fullName : '',
            emailId : this.addStaffForm.value.emailAddress ? this.addStaffForm.value.emailAddress.toLowerCase() : '' ,
            cognitoStubId: "",
            userActiveStatus:true,
            userLoginStatus:this.userLoginStatus
          }
        }
        const payload = {
          fullName: this.addStaffForm.value.fullName,
          emailId: this.addStaffForm.value.emailAddress.toLowerCase(),
          userActiveStaus: true
        }
          this.bff.updateStaffDetails(staffPayload).subscribe(res =>{
            if(res['staffAlreadyExist']){
             this.addStaffForm.controls['emailAddress'].setErrors({ 'alreadyExist': true })
             this.showLoaderIcon = false; 
            }else{
              this.showLoaderIcon = false;
              this.checkInPopup.emit();
              this.getStaffData.emit(payload);
              this.submitted = false;
              this.addStaffForm.reset();
            } 
          })
      })
    }
  }

  emailValidation(){
    const email = this.addStaffForm.controls.emailAddress.value
    if(email.includes('@idp')){
      this.addStaffForm.controls['emailAddress'].setErrors({ 'idpDomain': true }) 
    }
  }

  closeButton(){
    this.addStaffForm.reset();
    this.submitted = false;
    this.checkInPopup.emit();
  }
}
