import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { OverviewReportsComponent } from './overview-reports.component';

describe('OverviewReportsComponent', () => {
  let component: OverviewReportsComponent;
  let fixture: ComponentFixture<OverviewReportsComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OverviewReportsComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OverviewReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
