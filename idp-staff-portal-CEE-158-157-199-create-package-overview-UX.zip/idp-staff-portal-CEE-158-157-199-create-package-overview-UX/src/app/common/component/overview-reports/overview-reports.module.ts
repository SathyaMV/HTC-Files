import { NgModule } from '@angular/core';
import { OverviewReportsComponent } from './overview-reports.component';
import { NgChartsModule } from 'ng2-charts'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { DestinationModule } from '../reports-destination/reports-destination.module';
import { HDYHModule } from '../reports-hdyh/reports-hdyh.module';
import { HighestQualificationModule } from '../reports-highest-qualification/reports-highest-qualification.module';
import { PreRegisterWalkinModule } from '../reports-pre-register-walkin/reports-pre-register-walkin.module';
import { NewExistingStudentModule } from '../reports-new-existing-student/reports-new-existing-student.module';
import { PreferredStudyLevelModule } from '../reports-preferred-study-level/reports-preferred-study-level.module';
import { RegisterParticipantModule } from '../reports-register-participant/reports-register-participant.module';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [OverviewReportsComponent],
    imports:[NgChartsModule,
            MatFormFieldModule,
            MatOptionModule,
            MatSelectModule,
            DestinationModule,
            HDYHModule,
            HighestQualificationModule,
            PreRegisterWalkinModule,
            NewExistingStudentModule,
            PreferredStudyLevelModule,
            RegisterParticipantModule,
            CommonModule,
            FormsModule
        ],
    exports:[
        OverviewReportsComponent
    ]
})

export class OverviewReportsModule{

}