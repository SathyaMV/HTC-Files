import { Component, OnInit } from '@angular/core';
import { BffService } from '../../../providers/bff.service';

@Component({
  selector: 'app-overview-reports',
  templateUrl: './overview-reports.component.html',
  styleUrls: ['./overview-reports.component.css']
})
export class OverviewReportsComponent implements OnInit {
  hdyh:any;
  isdataloaded = false;
  destination :any;
  nearestIdpOffice : any;
  registrationParticipantsData;
  preferredStudyLevel : any;
  preRegisterWalkin : any;
  highestQualification : any;
  selectedOffice='';
  newExistingStudent :any;
  showLoadingIcon:boolean = true;
 
  constructor(private bff: BffService) {
  }

  ngOnInit(): void {
    this.getReportsData(); 
  }

  getReportsData(){
    if(this.selectedOffice === 'All Offices'){
      this.selectedOffice = ''
    }
    let eventId =  sessionStorage.getItem('idpEventId_'+ sessionStorage.getItem('tabID'));
    this.bff.getHowDidYouHearDetails(eventId,this.selectedOffice).subscribe(data => {
      this.hdyh = data;
      this.bff.hdyh.next(data);
    })

    this.bff.getDestinationDetails(eventId,this.selectedOffice).subscribe(data=>{
      this.destination = data;    
      this.bff.destination.next(data);  
    })

    this.bff.getRegisterParticipant(eventId,this.selectedOffice).subscribe(data =>{
      this.nearestIdpOffice = data?.nearestIdpOffice;
      this.showLoadingIcon = false;
      this.registrationParticipantsData = data?.registrationPaticipants;
      this.bff.reportsRegisterParticipant.next(this.registrationParticipantsData);
      this.bff.detectManualRegisterForm.subscribe(detect => {
        if(detect){
          this.bff.reportRegistrantCount.subscribe(data => {
            this.registrationParticipantsData = data;
            this.bff.reportsRegisterParticipant.next(this.registrationParticipantsData);
            this.bff.detectManualRegisterForm.next(false);
          })
        }
      })
    })

    this.bff.getPreferredLevel(eventId, this.selectedOffice).subscribe(data => {
      this.preferredStudyLevel = data
      this.bff.preferredStudyLevel.next( this.preferredStudyLevel)
    })

    this.bff.getPreRegisterWalkinDetails(eventId,this.selectedOffice).subscribe(data =>{ 
      this.preRegisterWalkin = data
      this.bff.preRegisterWalkin.next(this.preRegisterWalkin)
    })

    this.bff.getHighestQualification(eventId,this.selectedOffice).subscribe(data =>{
     this.highestQualification = data;
     this.bff.highestQualification.next(this.highestQualification);
    })

    this.bff.getNewExistingStudentDetails(eventId,this.selectedOffice).subscribe(data =>{
      this.newExistingStudent = data
      this.bff.newExistingStudent.next(this.newExistingStudent);
    })
  }
 }
