import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NotesComponent } from './notes.component';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { HttpClientModule } from '@angular/common/http';
import { FormBuilder, ReactiveFormsModule, FormsModule} from '@angular/forms';

describe('NotesComponent', () => {
  let component: NotesComponent;
  let fixture: ComponentFixture<NotesComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotesComponent ],
      imports: [CdkAccordionModule,
        BrowserAnimationsModule,
        MatFormFieldModule,
        MatInputModule,
        HttpClientModule,
        ReactiveFormsModule],
        providers: [BffService,
          { provide: CommonMethods, useClass: class {} },
          FormBuilder,
          FormsModule
        ]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.notesText).not.toBeUndefined();
  })

  it('should create 1 of that', () => {
    const fields = Object.keys(component.notes.controls);
    expect(fields.length).toBe(1);
  });

  it('should create "notesText"', () => {
    const fields = Object.keys(component.notes.controls);
    expect(fields).toEqual(['notesText']);
  });

  it('should be required', () => {
    const userName = component.notes.get('notesText');
    userName.markAsTouched();
    expect(userName.errors).toEqual({ required: true });
  });
  it('should has at least 3 char', () => {
    const notes = component.notes.get('notesText');
    notes.setValue('hi');
    expect(notes.errors).toEqual({ minlength: { actualLength: 2, requiredLength: 3, } });
  });
  it('should do nothing when form is invalid', () => {
    expect(component.addNote()).toBeFalsy();
  });
});
