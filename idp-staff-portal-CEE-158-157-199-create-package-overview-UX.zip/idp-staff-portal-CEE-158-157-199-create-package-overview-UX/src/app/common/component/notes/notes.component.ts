import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../../common/utilities/common-methods';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {
  @Input() tabChange;
  notesText = [];
  notesData;
  eventId;
  studentId; 
  notes: FormGroup;
  submitted;
  staffFullName: string;

  constructor(private bff: BffService,private fb: FormBuilder,private commanMethods:CommonMethods) { }

  ngOnInit(): void {
    this.getNotesData(); 
    this.notes = this.fb.group({
      notesText: ['',[this.removeSpaces,Validators.required,Validators.minLength(3),Validators.maxLength(300)]]  
    })
  }

  ngOnChanges(changes: SimpleChanges) {
    if(this.tabChange != undefined){
      this.submitted = false
    } 
  }
 
  getNotesData(){
    this.eventId = sessionStorage.getItem('eventId_'+sessionStorage.getItem('tabID'))
    this.studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
    if(this.eventId){
      let inpayload = 'idpEventId='+  this.eventId +'&source='+ 'Notes'+'&studentProfileId='+ this.studentId
      this.bff.getStudentProfileDetails(inpayload).subscribe(data=>{
        this.staffFullName = data?.studentProfileDetails?.staffFullName
        let sortArray= data?.studentProfileDetails?.counsellorNotes;
        this.notesText = sortArray.reverse()
      })
    }
  }

  addNote(){
    this.submitted = true;
    let currentDate = new Date()
    let removeWhiteSpace = this.notesData?.trimStart()
    if(this.notesData?.length >= 3 && removeWhiteSpace?.length > 0 && this.notesData?.length <= 300 ){
      let payload = {
        note : this.notesData.replace((/\n\r?/g), '<br>'),
        createdDateTime : currentDate,
        createdBy : this.staffFullName,
        modifiedDateTime: currentDate,
        modifiedBy: this.staffFullName  
      }
      this.notesText.unshift(payload)
      this.notesData = ''; 
      let inpayload;   
        inpayload = {
          studentProfileId :this.studentId,
          idpeventId : this.eventId,
          notes:[  
              payload
          ]
        };
          this.bff.sendNotesDetails(inpayload).subscribe()
          this.submitted = false
    }  
  }

    //This method is uded to remove whitespace
    removeSpaces(control: AbstractControl) {
      if (control && control.value && !control.value.toString().replace(/\s/g, '').length) {
        control.setValue('');
      }
      return null;
    }

 //This method is used to get formcontrol
 get formControls() { return this.notes.controls; }
}
