import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { StudentDetailsComponent } from './student-details.component';
import { RouterTestingModule } from '@angular/router/testing';


describe('StudentDetailsComponent', () => {
  let component: StudentDetailsComponent;
  let fixture: ComponentFixture<StudentDetailsComponent>;
  let service: BffService;
  const eventDetails = [{eventName:'VE-DEV'}];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule,RouterTestingModule],
      declarations: [ StudentDetailsComponent ],
      providers:[BffService, { provide: CommonMethods, useClass: class {} }],
    })
    .compileComponents();
    service = TestBed.inject(BffService);
    fixture = TestBed.createComponent(StudentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventDetails = eventDetails
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventDetails).not.toBeUndefined();
  })
});
