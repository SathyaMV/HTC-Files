import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import {routingUrl } from '../../utilities/constants';


@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {

  studentQrCode = false;
  eventDetails:any;
  showQrCode:boolean = false;
  cventCode : any;
  eventTitle: any;
  allEventsUrl = routingUrl.eventsListPage;
  overviewPageUrl = routingUrl.eventOverviewPage;
  studentProfileUrl = routingUrl.studentProfileUrl;
  attendedStatus : any;
  walkinStatus;
  attendedCheckBox;
  walkinCheckBox;
  isLiveEvent;
  checkIn: boolean = false;
  sucess_active: boolean = false;
  isFastlane:boolean
  canCheckInStudent:boolean = false

  constructor(private bffService:BffService,
              private customMethod : CommonMethods,
              private router:Router, private bff:BffService){ }

  ngOnInit(): void {
    this.getEventDetils();
    this.bffService.showStudentQrCode.subscribe(data=>{
      this.showQrCode = data == true ? true : false; 
    })

    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canCheckInStudent = data['userAccess'].canCheckInStudent
    })
  }

  showStudentQr() {
    this.showQrCode = true;
    document.body.classList.add('hide_body');
  }

  getEventDetils(){
    this.cventCode = sessionStorage.getItem('eventCode_'+sessionStorage.getItem('tabID'))
    let studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
    let source = 'studentDetails'
    let inPayLoad = 'source=' + source + '&studentProfileId=' + studentId + '&cventCode=' + this.cventCode
    this.eventTitle = sessionStorage.getItem('eventTitle_'+sessionStorage.getItem('tabID' +this.cventCode))
    this.attendedStatus = sessionStorage.getItem('attendedStatus_'+sessionStorage.getItem('tabID'))
    this.walkinStatus = sessionStorage.getItem('walkInStatus_'+sessionStorage.getItem('tabID')) 
    this.attendedCheckBox = this.attendedStatus?.includes(true)
    this.walkinCheckBox = this.walkinStatus?.includes(true)
    let LiveEvent : any =  sessionStorage.getItem('isLiveEvent_'+sessionStorage.getItem('tabID'))
    this.isLiveEvent = LiveEvent?.includes(true) 
    this.bffService.getEventsOverviewPageDetails(inPayLoad).subscribe(response=>{
      this.eventDetails = response?.eventOverviewDetails;
      this.isFastlane = response?.isFastlane
      this.checkIn = this.eventDetails?.attendedStatus
    })
  }

  studentCheckIn(){
    let inPayLoad = {
      correlationId: this.customMethod.correlationId(),
      cventAccountId: this.eventDetails.cventAccountId,
      cventCode: this.eventDetails.cventCode,
      idpEventId: this.eventDetails.eventId,
      studentId: this.eventDetails.studentProfileId
    }
    this.bffService.studentQRCheckIn(inPayLoad).subscribe(data=>{
      this.checkIn = true 
      this.sucess_active = true;
    })
  }
  
  navigateToOverviewPage(){
    this.router.navigateByUrl(this.overviewPageUrl+'?'+ 'eventCode=' + this.cventCode)
  }

  welcomePopup(){
    this.sucess_active = !this.sucess_active
  }

}
