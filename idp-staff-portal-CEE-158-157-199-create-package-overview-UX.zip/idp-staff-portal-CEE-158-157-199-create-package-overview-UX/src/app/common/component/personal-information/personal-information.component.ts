import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonMethods } from '../../../common/utilities/common-methods';
import { BffService } from '../../../providers/bff.service';

@Component({
  selector: 'app-personal-information',
  templateUrl: './personal-information.component.html',
  styleUrls: ['./personal-information.component.css'],
  providers: []
})



export class PersonalInformationComponent implements OnInit {
  @Input() personalInfoQnData = []
  @Input() dialCodeList = []
  personalInfoAnswer:any;
  personalInfoForm: FormGroup;
  userQuestions = [];
  selectedDialCode;
  selected;
  submitted: boolean = false
  studentId:any;
  cventCode;
  countryCode;
  initialValue;
  dateOfBirthAnswer;
  showSuccessMessage:boolean = false;
  personalInfoAnswers;
  canEditStudentDetails:boolean = false;

  constructor(private fb: FormBuilder,private commanMethods:CommonMethods,private bff: BffService) { }

  ngOnInit(): void {
    this.personalInfoForm = this.fb.group(
      {
        dialCode: ['']
      }
    );    
    this.getPersonalAnswer()

    //check user permission
    this.bff.userPermission.subscribe(data=>{
      this.canEditStudentDetails = !data['userAccess'].canEditStudentDetails
    })
  }

  getPersonalAnswer(){
    let eventId = sessionStorage.getItem('eventId_'+sessionStorage.getItem('tabID'))
    this.studentId = sessionStorage.getItem('studentId_'+sessionStorage.getItem('tabID'))
    this.cventCode = sessionStorage.getItem('eventCode_'+sessionStorage.getItem('tabID'))  
    let inpayload = 'idpEventId='+  eventId +'&source='+ 'Personal Info' + '&studentProfileId=' +this.studentId
    this.bff.getStudentProfileDetails(inpayload).subscribe(data=>{
      this.personalInfoAnswer = data?.response?.personalInfoBody;
      this.createFormControl();
      const defaultDialCode = this.personalInfoForm.value.dialCode ? this.personalInfoForm.value.dialCode : ""
      const defaultDialCodeIndex= this.dialCodeList.findIndex(x => x.optionKey === defaultDialCode)
      if (this.dialCodeList[defaultDialCodeIndex]) { 
        this.selectedDialCode = this.dialCodeList[defaultDialCodeIndex]; 
      } 
    })
  }

  get formControls() { return this.personalInfoForm.controls; }

  // Method to create Dynamic form controls
  createFormControl() {
    this.personalInfoQnData?.forEach(element => {
      if(element){
        if(element.mappingField === 'primary_email'){
          this.personalInfoForm.addControl(element.mappingField, new FormControl(this.personalInfoAnswer.emailAddress));
        }else if(element.mappingField === 'first_name'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.firstName,[Validators.maxLength(element.maxLength),this.removeSpaces,Validators.required]))    
        }else if(element.mappingField === 'last_name'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.lastName,[Validators.maxLength(element.maxLength),this.removeSpaces,Validators.required]))
        }else if(element.mappingField === 'primary_mobile_number' ){
          const seperatedMobileNumber = this.personalInfoAnswer.mobileNumber.trim().split(/\s+/);
          if (!this.commanMethods.isBlankOrNull(this.personalInfoAnswer.mobileNumber)) {
            this.personalInfoForm.get('dialCode').setValue(seperatedMobileNumber[0]);
          }
          if(seperatedMobileNumber[1] != 'null'){
            this.personalInfoForm.addControl(element.mappingField,new FormControl(seperatedMobileNumber[1] ? seperatedMobileNumber[1] : '',[Validators.pattern("^[0-9]*$"),this.removeSpaces,Validators.required]))
          }else{
            this.personalInfoForm.addControl(element.mappingField,new FormControl(''))
          }
        }else if(element?.mappingField === 'country_of_residency_code'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.countryOfResidence)) 
        }else if( element?.mappingField === 'nearestldpOffice'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.nearestIdpOffice)) 
        }else if(element?.mappingField === 'date_of_birth'){ 
          this.dateOfBirthAnswer = this.personalInfoAnswer.yearOfBirth
          const formattedDate = new Date(this.dateOfBirthAnswer).getFullYear().toString() 
            if(this.dateOfBirthAnswer != ''){
              this.personalInfoForm.addControl(element.mappingField,new FormControl(formattedDate))
            }else{
              this.personalInfoForm.addControl(element.mappingField,new FormControl('')) 
            }
        }else if(element?.mappingField === 'modeOfCounselling' ){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.preferredModeOfCounselling)) 
        }else if(element?.mappingField === 'primaryFinancialSource'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.primaryFinacialSource)) 
        }else if( element?.mappingField === 'howDidYouHear'){
          this.personalInfoForm.addControl(element.mappingField,new FormControl(this.personalInfoAnswer.howDidYouHear)) 
        }
    }});
    this.initialValue = this.personalInfoForm.value
  }



phoneNumValidation(e){ 
  const index = this.dialCodeList?.findIndex(x => x.optionKey === e)  
  if (this.dialCodeList[index]) { 
    this.selectedDialCode = this.dialCodeList[index]; 
  }
  this.phoneNum()
}
// Phone number validation  
phoneNum(){
  const mobNum = this.personalInfoForm.controls.primary_mobile_number?.value?.length;
  const isDigit = this.commanMethods.checkOnlyDigit(this.personalInfoForm.controls.primary_mobile_number.value)
  if(isDigit && mobNum > 0){ 
      if(mobNum < this.selectedDialCode?.minLength || mobNum > this.selectedDialCode?.maxLength || mobNum == 0){
        this.personalInfoForm.controls['primary_mobile_number'].setErrors({invalidPhoneNumber:false})
      }else{
        this.personalInfoForm.controls['primary_mobile_number'].setErrors(null)
      }
    }else if(!isDigit && mobNum > 0){
      this.personalInfoForm.controls['primary_mobile_number'].setErrors({invalidPhoneNumber:false})
  }     
}

saveBtn(){
  this.submitted = true
  if (this.personalInfoForm.invalid) {
    return;
  }else{
    const dialCodeVal = this.selectedDialCode?.optionKey
    const inPayload = {
      studentPersonalInfo: {
      emailId : this.personalInfoForm.value.primary_email ? this.personalInfoForm.value.primary_email : '',
      firstName: this.personalInfoForm.value.first_name ? this.personalInfoForm.value.first_name : '',
      lastName: this.personalInfoForm.value.last_name ? this.personalInfoForm.value.last_name : '',
      mobileNumber: dialCodeVal+ ' ' +this.personalInfoForm.value.primary_mobile_number ? dialCodeVal+ ' ' +this.personalInfoForm.value.primary_mobile_number : '' ,
      countryOfResidence: this.personalInfoForm.value.country_of_residency_code ? this.personalInfoForm.value.country_of_residency_code : '',
      nearestIdpOffice: this.personalInfoForm.value.nearestldpOffice ? this.personalInfoForm.value.nearestldpOffice : '',
      yearOfBirth : this.dateOfBirthAnswer ? this.dateOfBirthAnswer : '',
      preferredModeOfCounselling: this.personalInfoForm.value.modeOfCounselling ? this.personalInfoForm.value.modeOfCounselling : '',
      primaryFinaceSource: this.personalInfoForm.value.primaryFinancialSource ? this.personalInfoForm.value.primaryFinancialSource : '',
      howDidYouHear: this.personalInfoForm.value.howDidYouHear ? this.personalInfoForm.value.howDidYouHear : '',
      studentUuid: this.studentId,
      cventCode: this.cventCode
      }
  }
      this.bff.updatePersonalInfo(inPayload).subscribe(data => {
      const response = data['response']
      if(response){
        this.showSuccessMessage = true
        setTimeout(() => {
          this.showSuccessMessage = !this.showSuccessMessage
        }, 3000);
      }    
    })
  }
}

cancelBtn(){  
  this.personalInfoForm.reset(this.initialValue)
}

//This method is uded to remove whitespace
removeSpaces(control: AbstractControl) {
  if (control && control.value && !control.value.toString().replace(/\s/g, '').length) {
    control.setValue('');
  }
  return null;
  }
}
