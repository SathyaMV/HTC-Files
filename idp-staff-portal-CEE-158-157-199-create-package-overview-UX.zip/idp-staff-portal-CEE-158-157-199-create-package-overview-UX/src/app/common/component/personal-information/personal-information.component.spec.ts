import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonMethods } from '../../utilities/common-methods';
import { PersonalInformationComponent } from './personal-information.component';


describe('PersonalInformationComponent', () => {
  let component: PersonalInformationComponent;
  let fixture: ComponentFixture<PersonalInformationComponent>;
  const myPersonalInfoDetails = [{primary_email : 'test1234@yopmail.com'}]
  const myDialCodeRules = [{dial_code : '+91'}]
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalInformationComponent ],
      imports: [RouterTestingModule,
        CdkAccordionModule,
        MatFormFieldModule,
        MatInputModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatSelectModule,
        NoopAnimationsModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule
        ],
        providers: [
          { provide: CommonMethods, useClass: class {} },
          FormBuilder,
        ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.personalInfoQnData = myPersonalInfoDetails
    component.dialCodeList = myDialCodeRules
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.personalInfoQnData).not.toBeUndefined();
    expect(component.dialCodeList).not.toBeUndefined();
  })

  it('should test form validity', () => {
    const form = component.personalInfoForm;
    const emailInput = form.controls.primary_email;
    emailInput?.setValue('test123@yopmail.com')
    expect(form.valid).toBeTruthy();
  })

  it('should create a form', () => {
    expect(component.personalInfoForm).not.toBeUndefined();
  });

  it('form valid when empty', () => {
    expect(component.personalInfoForm.valid).toBeTruthy();
  });

  it('should create 1 of that', () => {
    const fields = Object.keys(component.personalInfoForm.controls);
    expect(fields.length).toBe(1);
  });
  it('should do nothing when form is invalid', () => {
    expect(component.saveBtn()).toBeFalsy();
  });
});
 