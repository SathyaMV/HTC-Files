import { Component, OnInit } from '@angular/core';
import { ChartConfiguration,ChartOptions,Chart} from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-highest-qualification',
  templateUrl: './reports-highest-qualification.component.html',
  styleUrls: ['./reports-highest-qualification.component.css']
})
export class ReportsHighestQualificationComponent implements OnInit {

  highestQualificationData:any;
  qualificationLabel = [];
  qualificationData = [];
  isDataLoaded:boolean = false;
  scrWidth =  window.innerWidth
  public barChartOptions3: ChartOptions

  constructor(private bff : BffService, private methods : CommonMethods) {
  }
  
  ngOnInit(): void {
    this.getQualificationDetails();
    this.getwindowidth();
  }

  getwindowidth(){
    if(this.scrWidth < 1200){
      Chart.defaults.datasets.bar.barThickness = 18;
    }else{
      Chart.defaults.datasets.bar.barThickness = 32;
    }
  }

  getQualificationDetails(){
    // setTimeout(() => {
      this.bff.highestQualification.subscribe(data =>{
        this.highestQualificationData = data['highestQualification'];
        let totalRegistrationCount= data['totalRegistrationCount'];
        this.qualificationLabel = [];
        this.qualificationData = [];
        if(this.highestQualificationData?.length > 0){
          this.highestQualificationData.map((e)=>{   
            e.percent = Math.round((e.optionValue/totalRegistrationCount) * 100); 
            this.qualificationLabel.push(e.optionKey);
            this.qualificationData.push(e.optionValue);
          }) 
          this.isDataLoaded = true;
          this.barChartData3= { 
            labels: this.qualificationLabel,
            datasets: [
              { data: this.qualificationData, backgroundColor: '#008260',hoverBackgroundColor:'#007556'}
            ]
          };  
        }
        this.barChartOptions3= this.methods.barChartObject('chartjs-tooltip9',this.qualificationData,'vertical')
      }) 
    // }, 1000); 
  }

  public barChartData3: ChartConfiguration['data'] = {
    labels: this.qualificationLabel,
    datasets: [
      { data: this.qualificationData, backgroundColor: '#008260',hoverBackgroundColor:'#007556'}
    ]
  };
}
