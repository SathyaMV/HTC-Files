import { NgModule } from "@angular/core";
import { ReportsHighestQualificationComponent } from "./reports-highest-qualification.component";
import { NgChartsModule } from 'ng2-charts'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from "@angular/common";


@NgModule({
    declarations: [ReportsHighestQualificationComponent],
    imports:[NgChartsModule,
        MatFormFieldModule,
        MatOptionModule,
        MatSelectModule,
        CommonModule],
    exports:[
        ReportsHighestQualificationComponent
    ]
})

export class HighestQualificationModule{}