import { Component } from '@angular/core';
import { InteractionService } from '../../../interaction.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent {
  navActive:boolean=false;

  constructor(private dataservice: InteractionService) { }
  openSideNav(){
    this.navActive=true;
    this.dataservice.openSideNav(this.navActive);
  }
}
