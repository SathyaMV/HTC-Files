import { LiveAnnouncer } from '@angular/cdk/a11y';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Auth } from 'aws-amplify';
import * as moment from 'moment';
import { map, Observable, startWith } from 'rxjs';
import { BffService } from 'src/app/providers/bff.service';

@Component({
  selector: 'app-registrants-table',
  templateUrl: './registrants-table.component.html',
  styleUrls: ['./registrants-table.component.css']
})

export class RegistrantsTableComponent implements OnInit {

  dataSource = new MatTableDataSource;
  displayData = new MatTableDataSource;
  filteredValue = new MatTableDataSource;
  displayedColumns: string[] = ['eventName', 'uploadedDateAndTime', 'fileName', 'userEmailId'];
  myControl = new FormControl('');
  options: string[] = [];
  startDate: Date;
  endDate: Date;
  filteredOptions!: Observable<string[]>;
  itemsPerPage: number = 15;
  currentPage: number = 1;
  allRegistrantDetails;
  showLoaderIcon: boolean = false;
  canManageAccess: boolean = false;
  emailId: string = '';
  uploadedDates: Date[] = [];
  searchValue: string = '';
  range = new FormGroup({
    startDate: new FormControl(null),
    endDate: new FormControl(null),
  });

  constructor(private _liveAnnouncer: LiveAnnouncer, private bff: BffService, private router: Router) { }
  private sort: MatSort
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  ngOnInit(): void {
    Auth.currentAuthenticatedUser().then(user => {
      this.emailId = user.attributes.email
      this.bff.userPermission.subscribe(data => {
        this.canManageAccess = data['userAccess'].canManageAccess;
        if (this.canManageAccess) {
          this.getImportRegistrants();
        }
      })
    })
  }

  getImportRegistrants() {
    this.showLoaderIcon = true;
    this.bff.getImportRegistrants(this.emailId).subscribe({
      next: (res) => {
        this.dataSource.data = res.importRegistrantsDetails;
        this.filteredValue.data = res.importRegistrantsDetails;
        this.displayData.data = this.dataSource.data.slice(0, this.itemsPerPage);
        this.setValues();
        this.showLoaderIcon = false
      },
      error: (error) => {
        this.showLoaderIcon = false
      }
    });
  }

  setValues() {
    this.dataSource.data?.forEach(value => {
      this.uploadedDates.push(new Date(value['uploadedDateAndTime']));
    });
    this.uploadedDates.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    this.startDate = this.uploadedDates[0];
    this.endDate = this.uploadedDates[this.uploadedDates.length - 1];
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value || '')),
    );
  }

  private _filter(filterValue: string): string[] {
    this.searchValue = filterValue.toLowerCase();
    let filteredValues = this.filteredValues();
    this.options = [];
    if (this.searchValue.length >= 3) {
      this.filteredValue.data = filteredValues.filter((value) => value['eventName'].toLowerCase().includes(this.searchValue));
      this.currentPage = 1;
      this.options = this.filteredValue.data.filter(option => option['eventName'].toLowerCase().includes(this.searchValue)).map(val => val['eventName']);
      this.options = [...new Set(this.options)];
    } else {
      this.filteredValue.data = filteredValues.slice(0);
    }
    this.setData(this.currentPage);
    return this.options;
  }

  filteredValues() {
    return this.dataSource.data.filter(value =>
      new Date(value['uploadedDateAndTime']) >= this.startDate
      && new Date(value['uploadedDateAndTime']) <= this.endDate)
  }

  announceSortChange(sortState: Sort) {
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }

  setDataSourceAttributes() {
    this.displayData.sort = this.sort;
  }

  getPagination(pageNumber) {
    let startValue = ((pageNumber - 1) * this.itemsPerPage) + 1;
    let endValue = pageNumber * this.itemsPerPage > this.filteredValue.data.length ? this.filteredValue.data.length : pageNumber * this.itemsPerPage;
    return `Showing ${startValue} to ${endValue} of ${this.filteredValue.data.length}`
  }

  setData(pageNumber) {
    let startValue = (pageNumber - 1) * this.itemsPerPage;
    let endValue = pageNumber * this.itemsPerPage;
    this.displayData.data = this.filteredValue.data.slice(startValue, endValue);
    document.getElementById('reportsHeader').scrollIntoView({ behavior: "smooth" });
  }

  filterByDate(type) {
    if (type == 'startDate') {
      this.startDate = moment(this.range.controls.startDate.value).isValid() ? new Date(this.range.controls.startDate.value) : this.uploadedDates[0];
    } else {
      this.endDate = moment(this.range.controls.endDate.value).isValid() ? new Date(this.range.controls.endDate.value) : this.uploadedDates[this.uploadedDates.length -1];
      this.endDate.setHours(23, 59, 59);
    }
    this.filteredValue.data = this.dataSource.data.filter(value => 
      new Date(value['uploadedDateAndTime']) >= this.startDate 
      && new Date(value['uploadedDateAndTime']) <= this.endDate)
    this.displayData.data = this.filteredValue.data.slice(0, this.itemsPerPage);
    this.currentPage = 1;
    this.myControl.setValue(this.searchValue);
  }

  viewDetails(row) {
    this.router.navigateByUrl('/idp-staff-portal/import-registrants-details?eventId=' + row.eventId+ '&logId='+row.logId)
  }

}
