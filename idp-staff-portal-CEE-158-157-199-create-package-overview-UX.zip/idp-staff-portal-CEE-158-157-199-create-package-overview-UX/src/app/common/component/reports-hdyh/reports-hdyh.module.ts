import { NgModule } from "@angular/core";
import { ReportsHdyhComponent } from "./reports-hdyh.component";
import { NgChartsModule } from 'ng2-charts'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [ReportsHdyhComponent],
    imports:[NgChartsModule,
        MatFormFieldModule,
        MatOptionModule,
        MatSelectModule,
        CommonModule],
    exports:[
        ReportsHdyhComponent
    ]
})

export class HDYHModule{}