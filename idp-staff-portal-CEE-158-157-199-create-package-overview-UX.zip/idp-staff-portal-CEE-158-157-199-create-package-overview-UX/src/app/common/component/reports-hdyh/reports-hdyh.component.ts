import { Component,OnInit } from '@angular/core';
import { ChartConfiguration,ChartOptions } from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-hdyh',
  templateUrl: './reports-hdyh.component.html',
  styleUrls: ['./reports-hdyh.component.css']
})
export class ReportsHdyhComponent implements OnInit {
  hdyh:any;
  hdyhLabel=[];
  hdyhData=[];
  scrWidth = window.innerWidth;
  isLoaded = false;
  totalRegistrationCount:any;
  barThickness:any;
  public barChartOptions4: ChartOptions 

  constructor(private bff : BffService, private methods : CommonMethods) {
  }

  ngOnInit(): void {
    this.getHdyhDetails();
  }

  getHdyhDetails(){
    // setTimeout(() => {
      this.bff.hdyh.subscribe((data)=>{
        this.hdyh = data['hdyh'];
        let totalRegistrationCount= data['totalRegistrationCount'];
        this.hdyhLabel = [];
        this.hdyhData = [];
          if(this.hdyh?.length > 0){
            this.hdyh.map((e)=>{
              e.percent = Math.round((e.optionValue/totalRegistrationCount) * 100);
              let strLength;
              if(this.scrWidth <= 768){
                strLength = e.optionKey.length > 17 ? e.optionKey.substring(0,17)+'...' : e.optionKey;
              }else{
                strLength = e.optionKey;
              }
              this.hdyhLabel.push(strLength);
              this.hdyhData.push(e.optionValue);
            })
          }
        this.isLoaded = true; 
        if(this.hdyhData?.length < 5){
          this.barThickness = 24
        }else {
          this.barThickness = 12;
        }
        this.barChartData4= {
          labels: this.hdyhLabel,
          datasets: [
            { data : this.hdyhData , backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df',barThickness:this.barThickness}
          ]
        };
        this.barChartOptions4= this.methods.barChartObject('chartjs-tooltip8',this.hdyhData,'horizontal')
      });
    // }, 1000);
  }

  public barChartData4: ChartConfiguration<'bar'>['data'] = {
    labels: this.hdyhLabel,
    datasets: [
      { data : this.hdyhData , backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df',barThickness:12}
    ]
  };
}
