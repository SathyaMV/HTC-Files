import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReportsHdyhComponent } from './reports-hdyh.component';

describe('ReportsHdyhComponent', () => {
  let component: ReportsHdyhComponent;
  let fixture: ComponentFixture<ReportsHdyhComponent>;
  let service: BffService

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsHdyhComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService)
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsHdyhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
