import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { SpeakerDetailsComponent } from './speaker-details.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatCardModule } from '@angular/material/card'
import { MatInputModule } from '@angular/material/input'
import { TranslateModule, TranslateService } from '@ngx-translate/core'
import { LangTranslateService } from 'src/app/providers/lang-translate.service'

@NgModule({
  declarations: [SpeakerDetailsComponent],
  imports: [
    CommonModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    TranslateModule
  ],
  exports: [SpeakerDetailsComponent],
  providers: [TranslateService, LangTranslateService]
})
export class SpeakerDetailsModule { }
