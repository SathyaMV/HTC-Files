import { ComponentFixture, TestBed } from '@angular/core/testing'
import { SpeakerDetailsComponent } from './speaker-details.component'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { TranslateModule } from '@ngx-translate/core'

describe('SpeakerDetailsComponent', () => {
  let component: SpeakerDetailsComponent
  let fixture: ComponentFixture<SpeakerDetailsComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [SpeakerDetailsComponent],
      providers: [LangTranslateService]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(SpeakerDetailsComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
