/*
 * Creates a speaker details component
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { Subscription } from 'rxjs'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'

@Component({
  selector: 'app-speaker-details',
  templateUrl: './speaker-details.component.html',
  styleUrls: ['./speaker-details.component.css']
})
export class SpeakerDetailsComponent implements OnInit {
  speakerDetailsForm: FormGroup = new FormGroup({
    speakerInput: new FormControl('')
  })

  subscriptions = new Subscription()
  isValidForm: boolean = false
  constructor (private readonly langTranslateService: LangTranslateService, private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      this.isValidForm = res.isSave
      if (res.selectTab === 'physical-event-details') {
        this.service.physicalEventDetails.next({
          ...this.service.physicalEventDetails.value,
          speakerDetails: this.speakerDetailsForm
        })
      } else if (res.selectTab === 'event-details') {
        this.service.eventDetails.next({ ...this.service.eventDetails.value, speakerDetails: this.speakerDetailsForm })
      }
    }))
  }

  ngOnInit (): void {

  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
