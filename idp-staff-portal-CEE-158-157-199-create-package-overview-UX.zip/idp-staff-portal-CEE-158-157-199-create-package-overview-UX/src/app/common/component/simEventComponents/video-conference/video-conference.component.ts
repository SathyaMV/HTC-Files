/*
 * Creates a video conference component
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms'
import { MatDialog } from '@angular/material/dialog'
import { Subscription } from 'rxjs'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { ConfirmationDialogComponent } from '../confirmation/confirmation-dialog.component'

@Component({
  selector: 'app-video-conference',
  templateUrl: './video-conference.component.html',
  styleUrls: ['./video-conference.component.css']
})
export class VideoConferenceComponent implements OnInit {
  videoConForm!: FormGroup
  videoConArr!: FormArray
  subscriptions = new Subscription()
  isValidForm: boolean = false
  constructor (private readonly fb: FormBuilder, public dialog: MatDialog,
    private readonly langTranslateService: LangTranslateService, private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      this.isValidForm = res.isSave
      if (res.selectTab === 'virtual-event-details') {
        this.service.virtualEventDetails.next({
          ...this.service.virtualEventDetails.value,
          videoConfDetails: this.videoConArr
        })
      } else if (res.selectTab === 'event-details') {
        this.service.eventDetails.next({ ...this.service.eventDetails.value, videoConfDetails: this.videoConArr })
      }
    }))
  }

  ngOnInit (): void {
    this.videoConForm = this.fb.group({
      videoConArr: this.fb.array([this.createItem()])
    })
    this.videoConArr = this.videoConForm.get('videoConArr') as FormArray
  }

  /**
   * @function get videoConArrControl
   * @todo Getting videoConArr controls
   */

  get videoConArrControl (): any {
    return (this.videoConForm.get('videoConArr') as FormArray).controls
  }

  /**
   * @function createItem
   * @todo Creating FormArray fields
   */

  createItem (): any {
    return this.fb.group({
      title: ['', Validators.required],
      url: ['', [Validators.required, Validators.pattern('^https?://[a-zA-Z0-9!-/:-@[-`{-~]*')]]
    })
  }

  /**
   * @function addItem
   * @todo Adding FormArray Item to videoConArr
   */

  addItem (): void {
    this.videoConArr.push(this.createItem())
  }

  /**
   * @function delete
   * @todo Delete FormArray Item based on the condition
   */

  delete (index: any): any {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: { title: 'Are you sure you want to delete the details?', agree: 'Yes', disagree: 'No' }
    })

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'Yes') {
        this.videoConArr.removeAt(index)
      }
    })
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
