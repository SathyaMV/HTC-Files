import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { StudentCapacityComponent } from './student-capacity.component'
import { NumberonlyDirective } from 'src/app/common/directives/numberonly.directive'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatRadioModule } from '@angular/material/radio'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatCardModule } from '@angular/material/card'
import { MatInputModule } from '@angular/material/input'
import { MatChipsModule } from '@angular/material/chips'
import { TranslateModule } from '@ngx-translate/core'

@NgModule({
  declarations: [StudentCapacityComponent, NumberonlyDirective],
  imports: [
    CommonModule,
    MatFormFieldModule,
    MatRadioModule,
    ReactiveFormsModule,
    MatInputModule,
    FormsModule,
    MatCardModule,
    MatChipsModule,
    TranslateModule
  ],
  exports: [StudentCapacityComponent]
})
export class StudentCapacityModule { }
