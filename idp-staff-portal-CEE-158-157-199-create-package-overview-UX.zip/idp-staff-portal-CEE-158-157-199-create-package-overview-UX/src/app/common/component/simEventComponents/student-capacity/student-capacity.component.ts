/*
 * Creates a student capacityz component
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { Subscription } from 'rxjs'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'

@Component({
  selector: 'app-student-capacity',
  templateUrl: './student-capacity.component.html',
  styleUrls: ['./student-capacity.component.css']
})
export class StudentCapacityComponent implements OnInit {
  studentCapacityForm: FormGroup = new FormGroup({
    capacityOption: new FormControl('limited'),
    capacityInput: new FormControl('')
  })

  isValidForm: boolean = false
  subscriptions = new Subscription()
  selectOption = 'limited'
  placeHolderTxt = ''
  constructor (private readonly langTranslateService: LangTranslateService, private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      this.isValidForm = res.isSave
      if (res.selectTab === 'event-details') {
        this.service.eventDetails.next({
          ...this.service.eventDetails.value,
          studentCapacity: this.studentCapacityForm
        })
      } else if (res.selectTab === 'physical-event-details') {
        this.service.physicalEventDetails.next({
          ...this.service.physicalEventDetails.value,
          studentCapacity: this.studentCapacityForm
        })
      }
    }))
  }

  ngOnInit (): void {
  }

  /**
   * @function onSelectCaption - show capacity input box. based on selection
   * @param e - radio button event
   */
  onSelectCaption (e: any): void {
    this.selectOption = e.value
    if (this.selectOption === 'nolimit') {
      this.studentCapacityForm.controls.capacityInput.reset()
    }
  }

  ngOnDestory (): void {
    this.subscriptions.unsubscribe()
    this.isValidForm = false
  }
}
