import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core'

import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Subscription } from 'rxjs'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'

@Component({
  selector: 'app-input-field',
  templateUrl: './input-field.component.html',
  styleUrls: ['./input-field.component.css']
})
export class InputFieldComponent implements OnInit {
  @Input() field: any
  @Input() formGroup!: FormGroup
  @Output() formGroupValue = new EventEmitter<object>()
  isValidForm: boolean = false
  subscriptions = new Subscription()

  constructor (private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      if (res.currentTab === res.selectTab) {
        this.isValidForm = res.isSave
      }
    }))
  }

  ngOnInit (): void {
  }

  emitInput (fieldName: string) {
    const field = { field: fieldName, value: this.formGroup.controls[this.field.field].value }
    this.formGroupValue.emit(field)
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
