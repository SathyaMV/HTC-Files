/*
 * Creates a create new event component
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { LangTranslateService } from 'src/app/providers/lang-translate.service'
import { simConstants } from '../../../../common/utilities/sim-constants'

@Component({
  selector: 'app-create-new-event',
  templateUrl: './create-new-event.component.html',
  styleUrls: ['./create-new-event.component.css']
})
export class CreateNewEventComponent implements OnInit {
  createEventBtnName = 'Create new event'
  addIcon = 'add'
  constructor (private readonly router: Router, private readonly langTranslateService: LangTranslateService) {

  }

  ngOnInit (): void {
  }

  /**
   * @function loadCreateEvent - loads the create new event page
   */
  loadCreateEvent (): void {
    this.router.navigateByUrl(simConstants.routingUrl.createEvent)
  }
}
