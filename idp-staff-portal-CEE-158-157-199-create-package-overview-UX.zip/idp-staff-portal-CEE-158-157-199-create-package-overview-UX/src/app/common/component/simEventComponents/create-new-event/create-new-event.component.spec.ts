import { ComponentFixture, TestBed } from '@angular/core/testing'
import { CreateNewEventComponent } from './create-new-event.component'

import { RouterTestingModule } from '@angular/router/testing'
import { CreateEventComponent } from '../../../../pages/simplified-events/create-event/create-event.component'
import { Router } from '@angular/router'
import { simConstants } from '../../../../common/utilities/sim-constants'

describe('CreateNewEventComponent', () => {
  let component: CreateNewEventComponent
  let fixture: ComponentFixture<CreateNewEventComponent>
  let router: Router
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CreateNewEventComponent],
      imports: [RouterTestingModule.withRoutes([
        { path: simConstants.routingUrl.createEvent, component: CreateEventComponent }])]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateNewEventComponent)
    component = fixture.componentInstance
    router = TestBed.inject(Router)
    fixture.detectChanges()
  })

  it('create event navigation test', () => {
    const spy = jest.spyOn(router, 'navigateByUrl')
    component.loadCreateEvent()
    expect(spy).toHaveBeenCalledWith(simConstants.routingUrl.createEvent)
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
