import { Component } from '@angular/core'
import { MatDialog } from '@angular/material/dialog'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { StudEventSave } from '../common/stud-event-save'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'app-physical-event-details',
  templateUrl: './physical-event-details.component.html',
  styleUrls: ['./physical-event-details.component.css']
})
export class PhysicalEventDetailsComponent extends StudEventSave {
  constructor (public readonly service: SimBbfService, public dialog: MatDialog, public readonly snackBar: MatSnackBar) {
    super(service, dialog, snackBar)
    this.subscriptions.unsubscribe()
    this.subscriptions.add(this.service.physicalEventDetails.subscribe(res => {
      this.validateData(res)
    }))
    this.subscriptions.add(this.service.eventData.subscribe(res => {
      this.eventType = res.type
      this.eventCategory = res.category
      this.eventId = res.id
      this.eventClassificationId = res.classificationId
    }))
  }

  ngOnInit (): void {
  }

  /**
   * @function getPayloadData - forms Payload data
   * @param res - Form data
   * */
  getPayloadData (res): void {
    this.showLoaderIcon = true
    const payloadData = {
      id: this.eventId,
      requestType: 'update',
      status: 'Draft',
      eventDetails: {
        startDate: this.eventDateAndTime.eventStartDate.replaceAll('/', '-'),
        endDate: this.eventDateAndTime.eventEndDate.replaceAll('/', '-'),
        startTime: this.eventDateAndTime.eventStartTime,
        endTime: this.eventDateAndTime.eventEndTime,
        includePhysicalEvent: true,
        includeVirtualEvent: false
      }
    }
    const addPayload: any = {}
    if ((this.eventType === 'Hybrid') && (this.eventCategory === 'Pre Departure' || this.eventCategory === 'Seminar' || this.eventCategory === 'Thrive Events')) {
      addPayload.venue = res.location.value.venue
      addPayload.address = res.location.value.address
      addPayload.city = res.location.value.city
      addPayload.zipcode = res.location.value.zipcode
    }

    if (this.eventCategory === 'Seminar') {
      addPayload.speakerName = res.speakerDetails.value.speakerInput
    }
    if (this.eventType !== 'Hybrid' && this.eventCategory === 'Thrive Events') {
      addPayload.classifications = res.studentClassification
    }
    if (this.eventType === 'Hybrid') {
      addPayload.capacity = Number(res.studentCapacity.value.capacityInput)
    }
    payloadData.eventDetails = { ...payloadData.eventDetails, ...addPayload }
    this.saveFormData(payloadData)
  }

  /**
   * @function onSave - save tyhe form details
   * */
  onSave (): void {
    this.service.sEventSave.next({ ...this.service.sEventSave.value, isSave: true, selectTab: 'physical-event-details' })
  }

  /**
   * @function updateDateTime
   *  update date and time value in form group
   * */
  updateDateTime (e: any): void {
    this.eventDateAndTime = e
  }

  ngDestroy (): void {
    super.ngDestroy()
    this.subscriptions.unsubscribe()
  }
}
