import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common'
import { PhysicalEventDetailsComponent } from './physical-event-details.component'
import { LoaderIconModule } from '../../loader-icon/loader-icon.module'
import { EventDateTimeModule } from '../event-date-time/event-date-time.module'
import { StudentCapacityModule } from '../student-capacity/student-capacity.module'
import { LocationModule } from '../location/location.module'
import { StudentClassificationModule } from '../student-classification/student-classification.module'
import { MatCardModule } from '@angular/material/card'
import { SpeakerDetailsModule } from '../speaker-details/speaker-details.module'
import { MatSnackBarModule } from '@angular/material/snack-bar'

@NgModule({
  declarations: [
    PhysicalEventDetailsComponent
  ],
  imports: [
    CommonModule,
    LoaderIconModule,
    EventDateTimeModule,
    StudentCapacityModule,
    SpeakerDetailsModule,
    LocationModule,
    StudentClassificationModule,
    SpeakerDetailsModule,
    MatCardModule,
    MatSnackBarModule
  ],
  exports: [
    PhysicalEventDetailsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PhysicalEventDetailsModule {}
