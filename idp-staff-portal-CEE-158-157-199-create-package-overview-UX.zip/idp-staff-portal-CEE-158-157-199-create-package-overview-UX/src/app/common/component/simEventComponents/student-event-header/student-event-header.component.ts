import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-event-header',
  templateUrl: './student-event-header.component.html',
  styleUrls: ['./student-event-header.component.css']
})
export class StudentEventHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
