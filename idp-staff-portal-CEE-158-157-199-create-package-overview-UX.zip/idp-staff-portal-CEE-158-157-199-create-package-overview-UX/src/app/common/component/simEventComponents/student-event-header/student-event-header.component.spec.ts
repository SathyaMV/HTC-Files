import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentEventHeaderComponent } from './student-event-header.component';

describe('StudentEventHeaderComponent', () => {
  let component: StudentEventHeaderComponent;
  let fixture: ComponentFixture<StudentEventHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentEventHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentEventHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
