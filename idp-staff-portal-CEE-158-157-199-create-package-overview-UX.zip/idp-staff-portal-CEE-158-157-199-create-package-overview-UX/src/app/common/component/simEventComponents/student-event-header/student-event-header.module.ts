import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { StudentEventHeaderComponent } from './student-event-header.component'
@NgModule({
  declarations: [
    StudentEventHeaderComponent
  ],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [
    StudentEventHeaderComponent
  ]
})
export class StudentEventHeaderModule{}
