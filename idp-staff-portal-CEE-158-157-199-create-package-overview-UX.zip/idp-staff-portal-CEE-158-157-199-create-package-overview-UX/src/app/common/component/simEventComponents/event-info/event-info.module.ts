import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { EventInfoComponent } from './event-info.component'

@NgModule({
  declarations: [
    EventInfoComponent
  ],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [
    EventInfoComponent
  ]
})
export class EventInfoModule{}