/*
 * Creates an event details page
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { Subscription } from 'rxjs'
import { BffService } from '../../../../providers/bff.service'
import { SimBbfService } from '../../../../providers/sim-bbf.service'

@Component({
  selector: 'app-event-info',
  templateUrl: './event-info.component.html',
  styleUrls: ['./event-info.component.css']
})
export class EventInfoComponent implements OnInit {
  subscriptions = new Subscription()

  fullName: string
  eventType: string
  eventCategory: string
  eventCode: string
  studentEvents: any

  constructor (private readonly simBbfService: SimBbfService, private readonly bbfService: BffService) {
    this.subscriptions.add(this.simBbfService.eventData.subscribe(res => {
      this.eventType = res.type
      this.eventCategory = res.category
      this.eventCode = res.eventCode
      
    }))
  }

  ngOnInit (): void {
    this.getUserDetails()
  }

  /**
   * @function getStudentEventId
   * @todo Fetching student event Api call
   */
  getStudentEventId (): void {
    const eventParam = { eventClassificationId: '2c2a3aac-a05d-11ed-9f61-98fa9b82fe16' }
    this.simBbfService.getStudentEventId(eventParam).subscribe((res: any) => {
      this.studentEvents = res
    })
  }

  getUserDetails (): void {
    this.bbfService.userPermission.subscribe(data => {    
      const firstName = data['firstName'] ? data['firstName'] : ''
      const lastName = data['lastName'] ? data['lastName'] : ''
      this.fullName = firstName +' '+lastName
    })
  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
