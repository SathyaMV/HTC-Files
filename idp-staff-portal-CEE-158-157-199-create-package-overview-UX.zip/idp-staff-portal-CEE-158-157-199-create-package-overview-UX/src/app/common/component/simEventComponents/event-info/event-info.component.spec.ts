import { ComponentFixture, TestBed } from '@angular/core/testing'
import { HttpClientModule } from '@angular/common/http'
import { EventInfoComponent } from './event-info.component'
import { BffService } from '../../../../providers/bff.service'
import { of } from 'rxjs'

describe('EventInfoComponent', () => {
  let component: EventInfoComponent
  let fixture: ComponentFixture<EventInfoComponent>
  let service: BffService
  let MockService: any

  beforeEach(async () => {
    MockService = {
      getUserPermission: jest.fn()
    }
    // 'sathya.magappan@idp.com'
    await TestBed.configureTestingModule({
      declarations: [EventInfoComponent],
      imports: [
        HttpClientModule
      ],
      providers: [
        { provide: 'BffService', useValue: MockService }]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(EventInfoComponent)
    service = TestBed.inject(BffService)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should return event getEventClassificationList', async () => {
    const expectRes = {
      firstName: 'Sathya',
      lastName: 'Nagappan',
      supportedCountries: ['India'],
      userAccess: {
        canAddGuestUser: false,
        canBulkuploadRegistrants: false,
        canCheckInStudent: true,
        canEditStudentDetails: true,
        canManageAccess: false,
        canReferToUniversity: true,
        canRegisterStudent: true,
        canSearchStudent: true,
        canViewAdminReports: false,
        canViewReports: false,
        canViewStudentDetails: true
      },
      validUser: true
    }
    jest.spyOn(service, 'getUserPermission').mockReturnValue(of(expectRes))
    component.getUserDetails()
    expect(component.fullName.length).toBeGreaterThan(0)
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
