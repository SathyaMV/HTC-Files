import { Component, OnInit } from '@angular/core'
import { InteractionService } from '../../../../interaction.service'

@Component({
  selector: 'app-sim-header',
  templateUrl: './sim-header.component.html',
  styleUrls: ['./sim-header.component.css']
})

export class SimHeaderComponent implements OnInit {
  navActive: boolean = false

  constructor (private readonly dataservice: InteractionService) { }
  ngOnInit (): void {

  } 
}
