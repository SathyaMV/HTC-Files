import { NgModule } from '@angular/core'
// import { CommonModule } from '@angular/common'
import { RouterModule } from '@angular/router'
import { SimHeaderComponent } from './sim-header.component'

@NgModule({
  declarations: [
    SimHeaderComponent
  ],
  imports: [
    // CommonModule,
    RouterModule
  ],
  exports: [
    SimHeaderComponent
  ]
})
export class SimHeaderModule { }
