import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClientModule } from '@angular/common/http';
import { InteractionService } from '../../../../interaction.service';
import { SimHeaderComponent } from './sim-header.component';

describe('SimHeaderComponent', () => {
  let component: SimHeaderComponent;
  let fixture: ComponentFixture<SimHeaderComponent>;
  let service: InteractionService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SimHeaderComponent ],
      providers: [InteractionService],
      imports: [HttpClientModule]
    })
    .compileComponents();
    service = TestBed.inject(InteractionService);
    fixture = TestBed.createComponent(SimHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
