import { HttpClientTestingModule } from '@angular/common/http/testing'
import { ComponentFixture, TestBed } from '@angular/core/testing'
import { MatCardModule } from '@angular/material/card'
import { RouterTestingModule } from '@angular/router/testing'
import { NewMasterEventComponent } from '../../../../pages/simplified-events/new-master-event/new-master-event.component'
import { StudentEventComponent } from '../../../../pages/simplified-events/student-event/student-event.component'
import { EventTypeCategoryComponent } from './event-type-category.component'
import { simConstants } from '../../../../common/utilities/sim-constants'
import { Router } from '@angular/router'
import { SimBbfService } from '../../../../providers/sim-bbf.service'

describe('EventTypeCategoryComponent', () => {
  let component: EventTypeCategoryComponent
  let fixture: ComponentFixture<EventTypeCategoryComponent>
  let router: Router
  let service: SimBbfService
  let MockService: any
  const eventType = [{
    name: 'Physical Event',
    id: 'ff0c7258-4a67-448a-aeff-c08f931441e2',
    description: 'A physical event takes place in person for all those who are attending the event.',
    icon: 'home_work',
    eventCategories: [
      {
        name: 'Seminar',
        id: '98a12c40-25b7-41d4-a356-3a030eeabc7a',
        description: 'An information session designed to deliver key insights to students about studying abroad. Can be IDP hosted or held in conjunction with an IDP partner.',
        icon: 'recent_actors'
      },
      {
        name: 'Pre Departure',
        id: '2859c07c-b7b7-4804-bf04-8051b87b79e5',
        description: 'IDP hosted event for students before they move to their study destination.',
        icon: 'flight_takeoff'
      },
      {
        name: 'IELTS Events',
        id: '8f8afa18-588e-48e9-b86b-8768cc754070',
        description: 'An IELTS event is conducted to deliver any information session to students on taking an IELTS exams.',
        icon: 'book'
      },
      {
        name: 'Student Essential Events',
        id: '7035313a-8537-4d51-a197-5d036921e72f',
        description: 'An SES information session.',
        icon: 'school'
      },
      {
        name: 'On Arrival',
        id: '1e33564c-7533-4277-87c2-35ac311d09f6',
        description: 'An on-arrival events is conducted for students who have arrived in their destination country.',
        icon: 'flight_land'
      },
      {
        name: 'Student Engagement Event',
        id: '717b8fe7-d7a4-4f2c-a9e8-6089ff2c5584',
        description: 'A social event or community building activity held for students.',
        icon: 'local_activity'
      },
      {
        name: 'Local Institution Visit',
        id: '218a99f9-53c0-429d-8714-aa153de98c71',
        description: 'For events where IDP staff visit schools, colleges or universities to attract new students.',
        icon: 'transfer_within_a_station'
      },
      {
        name: 'In Office Event',
        id: '218a99f9-53c0-429d-8714-aa153de98c71',
        description: 'An event where clients visit IDP Offices to host or attend workshops and seminars with students.',
        icon: 'apartment'
      }
    ]
  }]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventTypeCategoryComponent],
      imports: [HttpClientTestingModule, RouterTestingModule.withRoutes([
        { path: 'idp-staff-portal/student-event', component: StudentEventComponent },
        { path: 'idp-staff-portal/new-master-event', component: NewMasterEventComponent }
      ]), MatCardModule]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(EventTypeCategoryComponent)
    component = fixture.componentInstance
    router = TestBed.inject(Router)
    fixture.detectChanges()
  })

  it('event category navigation test', () => {
    const spy = jest.spyOn(router, 'navigateByUrl')
    component.eventTitle = 'Select Event Category'
    component.loadEventCategory(eventType)
    expect(spy).toHaveBeenCalledWith(simConstants.routingUrl.studentEvent)
  })

  it('event category creation test', () => {
    component.eventTitle = 'Select Event Type'
    component.loadEventCategory(eventType[0])
  })

  it('back button navigation test', () => {
    const spy = jest.spyOn(router, 'navigateByUrl')
    component.eventTitle = 'Select Event Type'
    component.back()
    expect(spy).toHaveBeenCalledWith(simConstants.routingUrl.createEvent)
  })

  it('event type creation test', () => {
    component.eventTitle = 'Select Event Category'
    component.back()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
