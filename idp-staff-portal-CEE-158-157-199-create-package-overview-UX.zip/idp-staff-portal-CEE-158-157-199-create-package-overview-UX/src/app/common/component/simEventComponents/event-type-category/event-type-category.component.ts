import { Component, Input, OnInit } from '@angular/core'
import { simConstants } from '../../../../common/utilities/sim-constants'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { Router } from '@angular/router'

@Component({
  selector: 'app-event-type-category',
  templateUrl: './event-type-category.component.html',
  styleUrls: ['./event-type-category.component.css']
})
export class EventTypeCategoryComponent implements OnInit {
  eventTypeName: any
  eventCategoryName: any
  @Input() eventTypes: any = []
  eventData: any = []
  iconName: any
  eventTitle = 'Select Event Type'
  categoryData: any
  typesData: any = [
    { name: 'Seminar', icon: 'recent_actors' },
    { name: 'Pre Departure', icon: 'flight_takeoff' },
    { name: 'IELTS Events', icon: 'book' },
    { name: 'Student Essential Events', icon: 'school' },
    { name: 'Thrive Events', icon: 'trending_up' },
    { name: 'Student Engagement Event', icon: 'local_activity' },
    { name: 'Local Institution Visit', icon: 'transfer_within_a_station' },
    { name: 'In Office Event', icon: 'apartment' }
  ]

  constructor (private readonly service: SimBbfService, private readonly router: Router) {
    this.service.eventData.next({ ...this.service.eventData.value, type: '', typeId: '', category: '', categoryId: '' })
  }

  ngOnInit (): void {
  }

  ngOnChanges (data: any): void {
    this.eventData = data.eventTypes.currentValue
  }

  /**
   * @function getIcon
   * @todo Fetching icon related to event category name
   */

  getIcon (name: any): any {
    this.typesData.filter((x: any) => {
      if (x.name === name) {
        this.iconName = x.icon
      }
    })
    return this.iconName
  }

  /**
   * @function getCategory
   * @todo getting event category data to display
   */

  getCategory (categoriesList: any): any {
    this.categoryData = categoriesList.map((x: any) => {
      return {
        id: x.id,
        name: x.name,
        description: x.description,
        icon: this.getIcon(x.name)
      }
    })
    return this.categoryData
  }

  /**
   * @function loadEventCategory
   * @todo loading event categories list
   */

  loadEventCategory (type: any): void {
    if (this.eventTitle !== 'Select Event Category') {
      this.eventTitle = 'Select Event Category'
      this.eventTypes = this.getCategory(type?.eventCategories)
      this.eventTypeName = type.name.split(' ')[0]
      this.service.eventData.next({ ...this.service.eventData.value, type: this.eventTypeName, typeId: type.id, category: '' })
      sessionStorage.setItem('eventTypeId', type.id)
      sessionStorage.setItem('eventTypeName', this.eventTypeName)
      this.service.eventData.next({ ...this.service.eventData.value, classificationId: sessionStorage.getItem('studentEventId') })
    } else {
      this.eventCategoryName = type.name
      this.service.eventData.next({ ...this.service.eventData.value, category: this.eventCategoryName, categoryId: type.id })
      sessionStorage.setItem('eventCategoryId', type.id)
      sessionStorage.setItem('eventCategoryName', this.eventCategoryName)
      this.service.eventData.next({ ...this.service.eventData.value, classificationId: sessionStorage.getItem('studentEventId') })
      this.router.navigateByUrl(simConstants.routingUrl.studentEvent)
    }
  }

  /**
   * @function back
   * @todo back to event type page or event classification page
   */

  back (): void {
    if (this.eventTitle !== 'Select Event Type') {
      this.eventTypes = this.eventData
      this.eventTitle = 'Select Event Type'
      this.service.eventData.next({ ...this.service.eventData.value, type: '', typeId: '', category: '', categoryId: '' })
    } else {
      this.router.navigateByUrl(simConstants.routingUrl.createEvent)
    }
  }
}
