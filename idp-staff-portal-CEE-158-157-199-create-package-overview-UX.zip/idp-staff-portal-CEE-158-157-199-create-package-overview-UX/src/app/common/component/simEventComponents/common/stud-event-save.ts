import { MatDialog } from '@angular/material/dialog'
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar'
import { Subscription } from 'rxjs'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { ErrorHandlingDialogComponent } from '../errorHandling/error-handling.component'

export class StudEventSave {
  eventType: any
  eventTypeId: any
  eventCategory: any
  eventCategoryId: any
  eventClassificationId: any
  eventId = ''
  subscriptions = new Subscription()
  showLoaderIcon: boolean = false
  eventDateAndTime: any
  horizontalPosition: MatSnackBarHorizontalPosition = 'right'
  verticalPosition: MatSnackBarVerticalPosition = 'bottom'
  constructor (public readonly service: SimBbfService, public dialog: MatDialog, public readonly snackBar: MatSnackBar) {
    this.subscriptions.add(this.service.eventData.subscribe(res => {
      this.eventType = res.type
      this.eventCategory = res.category
      this.eventTypeId = res.typeId
      this.eventCategoryId = res.categoryId
      this.eventClassificationId = res.classificationId
      this.eventId = res.id
    }))
  }

  /**
   * @function keyPressNumbers
   * @todo Only Integer allows for date validation
   * */
  keyPressNumbers (event: any): Boolean {
    const charCode = (event?.which) ? event.which : event.keyCode
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault()
      return false
    } else {
      return true
    }
  }

  /**
   * @function saveFormData - call api and update relavent payload
   * @param res - Form data
   * */
  getPayloadData (res): void {
  }

  /**
   * @function saveFormData - call api and update relavent payload
   * @param res - Form data
   * */
  saveFormData (payloadData): void {
    this.showLoaderIcon = true
    this.service.patchStudentEvent(payloadData).subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.statusCode === 200) {
        this.openSnackBar('Data Saved Successfully', 'success-snackbar')
      } else {
        this.openSnackBar('Data could not be saved', 'error-snackbar')
      }
    })
  }

  public createVideoArr (res): any[] {
    const videoConfList: any[] = res
    for (let i = res.length; i < 6; i++) {
      videoConfList.push(
        { title: '', url: '' })
    }
    return videoConfList
  }

  showAlert (): void {
    const dialogRef = this.dialog.open(ErrorHandlingDialogComponent, {
      data: { title: '', content: 'Event Overview field are mandatory?', agree: 'Ok' }
    })

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'Ok') {
        this.loadEventOverView()
      }
    })
  }

  loadEventOverView (): void {

  }

  /**
   * @function onSave - save tyhe form details
   * */
  onSave (): void {
    if (this.eventId.length === 0) {
      this.showAlert()
    } else {
      this.saveFilledData()
    }
  }

  saveFilledData () {}
  /**
   * @function validateDataAndTime - Verifiy the date and time
   * @param res - Form data
   * */
  validateDataAndTime (res): boolean {
    if (this.eventDateAndTime?.eventEndDate && this.eventDateAndTime?.eventEndTime && this.eventDateAndTime?.eventStartDate && this.eventDateAndTime?.eventStartTime) {
      return true
    }
    return false
  }

  /**
   * @function openSnackBar
   * @todo Display Toast Message for success scenario
  */
  openSnackBar (message: string, type: string): void {
    this.snackBar.open(message, '', { horizontalPosition: this.horizontalPosition, verticalPosition: this.verticalPosition, duration: 2000, panelClass: [type] })
  }

  /**
   * @function validateData -Verifiy whether form has valid data or not
   * @param res - Form data
   * */
  validateData (res): void {
    if (!this.validateDataAndTime(this.eventDateAndTime)) return

    if (this.eventCategory === 'Seminar' && res.speakerDetails.status === 'INVALID') return
    if (this.eventType === 'Hybrid' && this.eventCategory === 'Thrive Events' && res.studentClassification.status === 'INVALID') return
    if (this.eventType === 'Hybrid' && res.studentCapacity.status === 'INVALID') return
    if (this.eventType === 'Hybrid' && (this.eventCategory === 'Pre Departure' || this.eventCategory === 'Seminar' ||
    this.eventCategory === 'Thrive Events') && (res.location.status === 'VALID')) {
      this.getPayloadData(res)
    }
  }

  //   /**
  //    * @function onSave - save the form details
  //    * */
  //   onSave (): void {
  //     this.service.sEventSave.next({ isSave: true })
  //   }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
