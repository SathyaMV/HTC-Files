import { StudEventSave } from './stud-event-save';

describe('StudEventSave', () => {
  it('should create an instance', () => {
    // expect(new StudEventSave()).toBeTruthy();
  });
});
