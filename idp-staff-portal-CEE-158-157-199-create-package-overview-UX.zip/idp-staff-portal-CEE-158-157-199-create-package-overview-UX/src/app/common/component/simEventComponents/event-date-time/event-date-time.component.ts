import { DatePipe } from '@angular/common'
import { Component, OnInit, Output, EventEmitter } from '@angular/core'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { MomentDateAdapter } from '@angular/material-moment-adapter'
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YY'
  },
  display: {
    dateInput: 'DD/MM/YY',
    monthYearLabel: 'MMM YYYY'
  }
}
@Component({
  selector: 'app-event-date-time',
  templateUrl: './event-date-time.component.html',
  styleUrls: ['./event-date-time.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    DatePipe
  ]
})
export class EventDateTimeComponent implements OnInit {
  public startdateForm!: FormGroup
  public endDateForm!: FormGroup
  public startTimeForm!: FormGroup
  public endTimeForm!: FormGroup
  today = new Date()
  @Output() dateTimeValue = new EventEmitter<object>()

  startDateField = {
    validation: true,
    placeHolder: 'DD/MM/YY',
    lableName: 'Start Date',
    mandatory: true,
    field: 'eventStartDate',
    min: new Date(new Date().setDate(this.today.getDate() + 1)),
    max: new Date(new Date().setDate(this.today.getDate() + 365))
  }

  endDateField = {
    validation: true,
    placeHolder: 'DD/MM/YY',
    lableName: 'End Date',
    mandatory: true,
    field: 'eventEndDate',
    min: new Date(new Date().setDate(this.today.getDate() + 1)),
    max: new Date(new Date().setDate(this.today.getDate() + 365))
  }

  startTimeField = {
    validation: true,
    placeHolder: '00:00',
    lableName: 'Start Time',
    mandatory: true,
    field: 'eventStartTime',
    type: 'time',
    min: false
  }

  endTimeField = {
    validation: true,
    placeHolder: '00:00',
    lableName: 'End Time',
    mandatory: true,
    field: 'eventEndTime',
    type: 'time',
    min: false
  }

  eventDateForm = new FormGroup({
    eventStartDate: new FormControl('', [Validators.required]),
    eventEndDate: new FormControl('', [Validators.required]),
    eventStartTime: new FormControl('', [Validators.required]),
    eventEndTime: new FormControl('', [Validators.required])
  })

  constructor (private readonly service: SimBbfService, public datePipe: DatePipe) {
  }

  ngOnInit (): void {
    this.startdateForm = new FormGroup({ eventStartDate: new FormControl('') })
    this.endDateForm = new FormGroup({ eventEndDate: new FormControl('') })
    this.startTimeForm = new FormGroup({ eventStartTime: new FormControl('') })
    this.endTimeForm = new FormGroup({ eventEndTime: new FormControl('') })
  }

  /**
   * @function updateFormGroupValue
   *  update date and time value in form group
   * */
  updateFormGroupValue (e: any) {
    this.eventDateForm.controls[e.field].setValue(e.value)
    if (e.field === 'eventStartDate') {
      this.endDateField.min = (new Date(e.value))
    }
    if (e.field === 'eventStartTime' || e.field === 'eventEndTime') {
      this.endTimeField.min = this.eventDateForm.value.eventStartTime >= this.eventDateForm.value.eventEndTime
    }
    // this.service.physicalEventDetails.next({ ...this.service.physicalEventDetails.value, eventDataTime: this.eventDateForm.value })
    this.dateTimeValue.emit(this.eventDateForm.value)
  }
}
