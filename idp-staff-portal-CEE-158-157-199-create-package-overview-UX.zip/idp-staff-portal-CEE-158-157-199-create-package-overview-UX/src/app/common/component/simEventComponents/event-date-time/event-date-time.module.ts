import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatInputModule } from '@angular/material/input'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatNativeDateModule } from '@angular/material/core'
import { EventDateTimeComponent } from './event-date-time.component'
import { LoaderIconModule } from '../../loader-icon/loader-icon.module'
import { InputFieldComponent } from '../input-field/input-field.component'
import { DateFieldComponent } from '../date-field/date-field.component'

@NgModule({
  declarations: [
    EventDateTimeComponent, InputFieldComponent, DateFieldComponent
  ],
  imports: [
    CommonModule,
    MatCardModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    FormsModule,
    MatNativeDateModule,
    LoaderIconModule
  ],
  exports: [
    EventDateTimeComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EventDateTimeModule {}
