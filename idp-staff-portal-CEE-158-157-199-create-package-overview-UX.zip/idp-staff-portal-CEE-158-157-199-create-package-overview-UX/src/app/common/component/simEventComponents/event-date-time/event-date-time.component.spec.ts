import { ComponentFixture, TestBed } from '@angular/core/testing'
import { MatNativeDateModule } from '@angular/material/core'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { FormGroup, FormControl } from '@angular/forms'

import { EventDateTimeComponent } from './event-date-time.component'

describe('EventDateTimeComponent', () => {
  let component: EventDateTimeComponent
  let fixture: ComponentFixture<EventDateTimeComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventDateTimeComponent],
      imports: [MatNativeDateModule,
        MatFormFieldModule, MatInputModule
      ]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(EventDateTimeComponent)
    component = fixture.componentInstance
    component.eventDateForm = new FormGroup({
      eventStartDate: new FormControl(''),
      eventEndDate: new FormControl(''),
      eventStartTime: new FormControl(''),
      eventEndTime: new FormControl('')
    })
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
  it('should call updateFormGroupValue function', () => {
    const formValues = component.eventDateForm
    const eventDateForm = {
      eventStartDate: '',
      eventEndDate: '',
      eventStartTime: '',
      eventEndTime: ''
    }
    expect(formValues.value).toEqual(eventDateForm)
    component.eventDateForm.controls.eventStartDate.setValue('11-12-2023')
    component.eventDateForm.controls.eventEndDate.setValue('12-12-2023')
    component.eventDateForm.controls.eventStartTime.setValue('11:15')
    component.eventDateForm.controls.eventEndTime.setValue('11:30')
  })
})
