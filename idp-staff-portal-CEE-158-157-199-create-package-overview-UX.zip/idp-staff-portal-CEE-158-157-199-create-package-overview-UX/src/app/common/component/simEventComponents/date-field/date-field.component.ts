import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core'
import { FormGroup, Validators } from '@angular/forms'
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE
} from '@angular/material/core'
import { DatePipe } from '@angular/common'
import { MomentDateAdapter } from '@angular/material-moment-adapter'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { Subscription } from 'rxjs'
export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YY'
  },
  display: {
    dateInput: 'DD/MM/YY',
    monthYearLabel: 'MMM YYYY'
  }
}
@Component({
  selector: 'app-date-field',
  templateUrl: './date-field.component.html',
  styleUrls: ['./date-field.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    DatePipe
  ]
})
export class DateFieldComponent implements OnInit {
  @Input() field: any
  @Input() formGroup!: FormGroup
  @Output() formGroupValue = new EventEmitter<object>()
  today = new Date()
  isValidForm: boolean = false
  subscriptions = new Subscription()

  constructor (private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      if (res.currentTab === res.selectTab) {
        this.isValidForm = res.isSave
      }
    }))
  }

  ngOnInit (): void {
    this.formGroup.controls[this.field.field].addValidators([Validators.required])
  }

  dateChange (value: string, st: any): void {
    const field = { field: value, value: this.formatDate(this.formGroup.controls[this.field.field].value) }
    this.formGroupValue.emit(field)
  }

  /**
   * @function keyPressNumbers
   *  Only Integer allows for date validation
   * */
  keyPressNumbers (event: any): Boolean {
    const charCode = (event?.which) ? event.which : event.keyCode
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault()
      return false
    } else {
      return true
    }
  }

  /**
   * @function formatDate
   *  Date format change based on save api format
  */
  formatDate (pdate: any): String {
    const date = new Date(pdate)
    const year = date.toLocaleString('default', { year: 'numeric' })
    const month = date.toLocaleString('default', { month: '2-digit' })
    const day = date.toLocaleString('default', { day: '2-digit' })
    const formattedDate = year + '/' + month + '/' + day
    return formattedDate
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
    this.isValidForm = false
  }
}
