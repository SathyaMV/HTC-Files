import { ComponentFixture, TestBed } from '@angular/core/testing'
import { MatNativeDateModule } from '@angular/material/core'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { FormGroup, FormControl } from '@angular/forms'
import { DateFieldComponent } from './date-field.component'

describe('DateFieldComponent', () => {
  let component: DateFieldComponent
  let fixture: ComponentFixture<DateFieldComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DateFieldComponent],
      imports: [MatNativeDateModule,
        MatFormFieldModule, MatInputModule
      ]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(DateFieldComponent)
    component = fixture.componentInstance
    component.formGroup = new FormGroup({
      x: new FormControl('')
    })
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
