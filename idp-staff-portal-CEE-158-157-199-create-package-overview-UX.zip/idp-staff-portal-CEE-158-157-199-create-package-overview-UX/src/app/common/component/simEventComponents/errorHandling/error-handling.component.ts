import { Component, OnInit, Inject } from '@angular/core'
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'
export interface DialogDataInterface {
  title: string
  content: string
  agree: string
}
@Component({
  selector: 'app-error-handling',
  templateUrl: './error-handling.component.html',
  styleUrls: ['./error-handling.component.css']
})
export class ErrorHandlingDialogComponent implements OnInit {
  dialogData: DialogDataInterface
  constructor (public dialogRef: MatDialogRef<ErrorHandlingDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogDataInterface) { }

  ngOnInit (): void {
    this.dialogData = this.data
    this.dialogRef.updateSize('400px', '165px')
  }

  /**
   * @function dialogClose
   *  close popoup diaslog window
   */
  dialogClose (): void {
    this.dialogRef.close()
  }
}
