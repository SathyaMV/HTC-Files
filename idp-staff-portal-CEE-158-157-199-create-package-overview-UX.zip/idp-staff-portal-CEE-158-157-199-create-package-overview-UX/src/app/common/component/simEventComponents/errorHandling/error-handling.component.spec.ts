import { ComponentFixture, TestBed } from '@angular/core/testing'
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'
import { RouterTestingModule } from '@angular/router/testing'

import { ErrorHandlingDialogComponent } from './error-handling.component'

describe('ErrorHandlingDialogComponent', () => {
  let component: ErrorHandlingDialogComponent
  let fixture: ComponentFixture<ErrorHandlingDialogComponent>

  const dialogMock = {
    updateSize () { }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ErrorHandlingDialogComponent],
      imports: [
        RouterTestingModule,
        MatDialogModule
      ],
      providers: [{
        provide: MAT_DIALOG_DATA,
        useValue: {}
      },
      {
        provide: MatDialogRef, useValue: dialogMock
      }]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorHandlingDialogComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
    component.ngOnInit()
    component.dialogData = { title: 'Technical Error', content: 'Contact your techinal suppport team', agree: 'ok' }
  })

  it('should call updatesize', () => {
    jest.spyOn(component.dialogRef, 'updateSize')
    component.dialogRef.updateSize()
    expect(component.dialogRef.updateSize).toHaveBeenCalled()
  })
  it('click agree button', () => {
    jest.spyOn(component, 'dialogClose')
    const btn = fixture.debugElement.nativeElement.querySelector('#agree')
    btn.click()
    expect(component.dialogClose).toHaveBeenCalled()
  })
})
