import { Component, OnInit } from '@angular/core'
import { MatDialog } from '@angular/material/dialog'

import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { StudEventSave } from '../common/stud-event-save'
import { MatSnackBar } from '@angular/material/snack-bar'

@Component({
  selector: 'app-virtual-event-details',
  templateUrl: './virtual-event-details.component.html',
  styleUrls: ['./virtual-event-details.component.css']
})
export class VirtualEventDetailsComponent extends StudEventSave {
  constructor (public readonly service: SimBbfService, public dialog: MatDialog, public readonly snackBar: MatSnackBar) {
    super(service, dialog, snackBar)
    this.subscriptions.unsubscribe()
    this.subscriptions.add(this.service.virtualEventDetails.subscribe(res => {
      this.validateData(res)
    }))
    this.subscriptions.add(this.service.eventData.subscribe(res => {
      this.eventType = res.type
      this.eventCategory = res.category
      this.eventId = res.id
    }))
  }

  ngOnInit (): void {

  }

  /**
   * @function validateData -Verifiy whether form has valid data or not
   * @param res - Form data
   * */
  validateData (res): void {
    if (!this.validateDataAndTime(this.eventDateAndTime)) return
    this.getPayloadData(res)
  }

  public createVideoArr (res): any[] {
    const videoConfList: any[] = res
    for (let i = res.length; i < 6; i++) {
      videoConfList.push(
        { title: '', url: '' })
    }
    return videoConfList
  }

  /**
   * @function updateDateTime
   *  update date and time value in form group
   * */
  updateDateTime (e: any): void {
    this.eventDateAndTime = e
  }

  /**
   * @function getPayloadData - forms Payload data
   * @param res - Form datapdate
   * */
  getPayloadData (res): void {
    this.showLoaderIcon = true
    const payloadData = {
      id: this.eventId,
      requestType: 'update',
      status: 'Draft',
      eventDetails: {
        startDate: this.eventDateAndTime?.eventStartDate.replaceAll('/', '-'),
        endDate: this.eventDateAndTime?.eventEndDate.replaceAll('/', '-'),
        startTime: this.eventDateAndTime.eventStartTime,
        endTime: this.eventDateAndTime.eventEndTime,
        videoConferencing: this.createVideoArr(res.videoConfDetails.value),
        includePhysicalEvent: false,
        includeVirtualEvent: true
      }
    }
    this.saveFormData(payloadData)
  }

  /**
   * @function onSave - save tyhe form details
   * */
  onSave (): void {
    this.service.sEventSave.next({ ...this.service.sEventSave.value, isSave: true, selectTab: 'virtual-event-details' })
  }

  ngDestroy (): void {
    super.ngDestroy()
    this.subscriptions.unsubscribe()
  }
}
