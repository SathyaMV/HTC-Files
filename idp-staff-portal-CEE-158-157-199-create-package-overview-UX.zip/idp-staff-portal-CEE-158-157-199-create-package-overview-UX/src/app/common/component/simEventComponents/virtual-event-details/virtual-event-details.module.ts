import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatChipsModule } from '@angular/material/chips'
import { MatInputModule } from '@angular/material/input'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatAutocompleteModule } from '@angular/material/autocomplete'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatNativeDateModule } from '@angular/material/core'
import { MatSelectModule } from '@angular/material/select'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { VirtualEventDetailsComponent } from './virtual-event-details.component'
import { LoaderIconModule } from '../../loader-icon/loader-icon.module'
import { EventDateTimeModule } from '../event-date-time/event-date-time.module'
import { VideoConferenceModule } from '../video-conference/video-conference.module'


@NgModule({
  declarations: [
    VirtualEventDetailsComponent
  ],
  imports: [
    CommonModule,
    MatCardModule,
    MatChipsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatSnackBarModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    FormsModule,
    MatNativeDateModule,
    LoaderIconModule,
    EventDateTimeModule,
    VideoConferenceModule,
    MatSnackBarModule
  ],
  exports: [
    VirtualEventDetailsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class VirtualEventDetailsModule{}