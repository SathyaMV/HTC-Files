import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatChipsModule } from '@angular/material/chips'
import { MatInputModule } from '@angular/material/input'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatAutocompleteModule } from '@angular/material/autocomplete'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatNativeDateModule } from '@angular/material/core'
import { MatSelectModule } from '@angular/material/select'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { TranslateModule } from '@ngx-translate/core'
import { StudentEventOverviewComponent } from './student-event-overview.component'
import { LoaderIconModule } from '../../../../common/component/loader-icon/loader-icon.module'

@NgModule({
  declarations: [
    StudentEventOverviewComponent
  ],
  imports: [
    CommonModule,
    MatCardModule,
    MatChipsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatSnackBarModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    FormsModule,
    MatNativeDateModule,
    LoaderIconModule,
    TranslateModule
  ],
  exports: [
    StudentEventOverviewComponent
  ],
  providers: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class StudentEventOverviewModule{}