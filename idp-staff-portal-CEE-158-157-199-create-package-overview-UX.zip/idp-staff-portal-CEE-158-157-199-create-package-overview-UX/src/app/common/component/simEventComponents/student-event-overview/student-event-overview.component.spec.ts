import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'
import { ComponentFixture, TestBed } from '@angular/core/testing'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { MatCardModule } from '@angular/material/card'
import { MatNativeDateModule } from '@angular/material/core'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { MatSelectModule } from '@angular/material/select'
import { MatChipsModule } from '@angular/material/chips'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { MatAutocompleteModule } from '@angular/material/autocomplete'
import { TranslateModule } from '@ngx-translate/core'
import { of } from 'rxjs'

import { StudentEventOverviewComponent } from './student-event-overview.component'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { CommonMethods } from '../../../utilities/common-methods'

describe('StudentEventOverviewComponent', () => {
  let component: StudentEventOverviewComponent
  let fixture: ComponentFixture<StudentEventOverviewComponent>
  let service: SimBbfService
  let commonMethods: CommonMethods
  let MockService: any

  beforeEach(async () => {
    MockService = {
      getDestinationList: jest.fn(),
      getDestination: jest.fn(),
      getSupportedStudyLevel: jest.fn(),
      getRegionList: jest.fn(),
      getEventPlannerEmail: jest.fn(),
      getStudentEventId: jest.fn(),
      patchStudentEvent: jest.fn(),
      getCountryList: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [StudentEventOverviewComponent],
      imports: [
        TranslateModule.forRoot(),
        NoopAnimationsModule, HttpClientTestingModule,
        HttpClientModule, MatCardModule, FormsModule, ReactiveFormsModule, MatNativeDateModule,
        MatFormFieldModule, MatInputModule, MatSnackBarModule,
        MatSelectModule, MatChipsModule,
        MatAutocompleteModule
      ],
      providers: [{ provide: 'SimBbfService', useValue: MockService }, LangTranslateService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents()

    fixture = TestBed.createComponent(StudentEventOverviewComponent)
    component = fixture.componentInstance
    component.ngOnInit()
  })

  beforeEach(() => {
    service = TestBed.inject(SimBbfService)
    // commonMethods = TestBed.inject(commonMethods)
    fixture.detectChanges()
  })
  it('create component', () => {
    component.ngOnInit()
    expect(component).toBeTruthy()
  })
  it('create a form', () => {
    expect(component.studentEventOverviewForm).not.toBeUndefined()
  })
  it('form invalid when empty', () => {
    component.studentEventOverviewForm.controls.title.setValue('')
    component.studentEventOverviewForm.controls.description.setValue('')
    component.studentEventOverviewForm.controls.destination.setValue('')
    component.studentEventOverviewForm.controls.supportedStudyLevel.setValue('')
    expect(component.studentEventOverviewForm.valid).toBeFalsy()
  })
  it('check initial form values', () => {
    const formValues = component.studentEventOverviewForm
    const studentEventOverviewForm = {
      title: '',
      description: '',
      destination: '',
      supportedStudyLevel: '',
      country: '',
      city: '',
      idpOffice: '',
      idpTeam: '',
      timezone: '',
      email: ''
    }
    expect(formValues.value).toEqual(studentEventOverviewForm)
  })
  it('title field validity', () => {
    const name = component.studentEventOverviewForm.controls.title
    expect(name.valid).toBeFalsy()
    name.setValue('')
    expect(name.hasError('required')).toBeTruthy()
  })
  it('destination field validity', () => {
    const name = component.studentEventOverviewForm.controls.destination
    expect(name.valid).toBeFalsy()
    name.setValue('')
    expect(name.hasError('required')).toBeTruthy()
  })

  it('test a form group input element count', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#studentEventOverviewForm')
    const inputElement = formElement.querySelectorAll('input')
    expect(inputElement.length).toEqual(4)
  })
  it('valid form', () => {
    component.studentEventOverviewForm.controls.title.setValue('IELTS Masterclass Webinar - Listening and Reading')
    component.studentEventOverviewForm.controls.description.setValue(`Want to make sure you’re 100% set for your IELTS test day?

    Tune into our IELTS Listening and Reading Masterclass on Thursday, 30 March at 5:00 PM (AEST)!
    
    In this session, IELTS expert Don will share best tips and plenty of examples on how to boost your IELTS score.
    
    We will end the webinar with a short Q&A session, so make sure to bring along any burning questions you might have.
    
    Bonus: A special IELTS coaching offer is available for you. Redeem a 20% discount for IELTS Reading Assist - an official IELTS mock Reading test with feedback from an IELTS Coach. IELTS Reading Assist will enhance your reading skills to improve your test performance.
    
    How to redeem your special offer?
    
    1. Go to https://ielts.com.au/prepare/ielts-preparation-material/reading
    2. Add IELTS Reading Assist to your shopping cart
    3. Use code Masterclass20 at checkout for 20% off
    4. Practise and boost your score!`)
    component.studentEventOverviewForm.controls.destination.setValue('Canada,Ireland')
    component.studentEventOverviewForm.controls.supportedStudyLevel.setValue('English')
    component.studentEventOverviewForm.controls.country.setValue('Australia')
    component.studentEventOverviewForm.controls.city.setValue('Melbourne')
    component.studentEventOverviewForm.controls.idpOffice.setValue('Mel-Off')
    component.studentEventOverviewForm.controls.idpTeam.setValue('Mel-Team')
    component.studentEventOverviewForm.controls.timezone.setValue('(GMT+10:00) AUS Eastern [Brisbane]')
    component.studentEventOverviewForm.controls.email.setValue('sourav@idp.com')
    component.studentEventOverviewForm.controls.firstName.setValue('sourav')
    component.studentEventOverviewForm.controls.lastName.setValue('kumar')
    expect(component.studentEventOverviewForm.valid).toBeTruthy()
  })
  it('should call get Destination Api', async () => {
    const expectRes = {
      regions: [
        {
          code: 'AU',
          name: 'Australia',
          isVisible: true
        },
        {
          code: 'CA',
          name: 'Canada',
          isVisible: true
        }
      ]
    }
    jest.spyOn(service, 'getDestination').mockReturnValue(of(expectRes))
    component.getDestinationList()
    expect(component.destinationCountryList.length).toBeGreaterThan(0)
  })
  it('should call get Supported Study Level Api', async () => {
    const expectRes = {
      studyLevel: [
        {
          code: 'postgraduate',
          name: 'Postgraduate',
          isVisible: true
        },
        {
          code: 'doctorate',
          name: 'Doctorate',
          isVisible: true
        }
      ]
    }
    jest.spyOn(service, 'getSupportedStudyLevel').mockReturnValue(of(expectRes))
    component.getSupportedStudyLevel()
    expect(component.supportedStudyLevelList.length).toBeGreaterThan(0)
    const undefinedRes = undefined
    jest.spyOn(service, 'getSupportedStudyLevel').mockReturnValue(of(undefinedRes))
    component.getSupportedStudyLevel()
  })
  it('component should call get Destination ', () => {
    component.selectedDestinationList = ['Australia', 'Canada']
    component.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: true
    }, {
      code: 'CA',
      name: 'Canada',
      isVisible: true
    }]
    const undefinedRes = undefined
    jest.spyOn(service, 'getDestination').mockReturnValue(of(undefinedRes))
    component.getDestinationList()
  })
  it('component should call remove Destination ', () => {
    component.selectedDestinationList = ['Australia', 'Canada']
    component.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: true
    }, {
      code: 'CA',
      name: 'Canada',
      isVisible: true
    }]
    component.removeDestination('Australia')
  })
  it('component should call remove Destination else part ', () => {
    component.selectedDestinationList = []
    component.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: true
    }]
    component.removeDestination('Australia')
  })
  it('component should call selected Destination ', () => {
    component.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: false
    }, {
      code: 'CA',
      name: 'Canada',
      isVisible: true
    }]
    component.selectedDestination({ value: 'Australia' })
  })
  it('component should call selected Study Level method', () => {
    component.supportedStudyLevelList = [{
      code: 'doctorate',
      name: 'Doctorate',
      isVisible: true
    }]
    component.selectedStudyLevel({ value: 'Doctorate' })
  })
  it('component should call remove Study Level method', () => {
    component.selectedStudyLevelList = ['Doctorate', 'Postgraduate']
    component.supportedStudyLevelList = [{
      code: 'doctorate',
      name: 'Doctorate',
      isVisible: true
    }, {
      code: 'Postgraduate',
      name: 'Postgraduate',
      isVisible: true
    }]
    component.removeStudyLevel('Doctorate')
  })
  it('component should call remove Study Level method else condition ', () => {
    component.selectedStudyLevelList = []
    component.supportedStudyLevelList = [{
      code: 'doctorate',
      name: 'Doctorate',
      isVisible: true
    }, {
      code: 'Postgraduate',
      name: 'Postgraduate',
      isVisible: true
    }]
    component.removeStudyLevel('Doctorate')
  })
  it('component should call openSnackBar method', () => {
    component.openSnackBar('Success message', 'success')
  })
  it('component should click on save button', () => {
    jest.spyOn(component, 'onSave')
    const btn = fixture.debugElement.nativeElement.querySelector('#saveButton')
    btn.click()
    expect(component.onSave).toHaveBeenCalled()
  })
  it('component should click on save button with valid form values', () => {
    component.studentEventOverviewForm.controls.title.setValue('IELTS Masterclass Webinar - Listening and Reading')
    component.studentEventOverviewForm.controls.description.setValue(`Want to make sure you’re 100% set for your IELTS test day?

    Tune into our IELTS Listening and Reading Masterclass on Thursday, 30 March at 5:00 PM (AEST)!
    
    In this session, IELTS expert Don will share best tips and plenty of examples on how to boost your IELTS score.
    
    We will end the webinar with a short Q&A session, so make sure to bring along any burning questions you might have.
    
    Bonus: A special IELTS coaching offer is available for you. Redeem a 20% discount for IELTS Reading Assist - an official IELTS mock Reading test with feedback from an IELTS Coach. IELTS Reading Assist will enhance your reading skills to improve your test performance.
    
    How to redeem your special offer?
    
    1. Go to https://ielts.com.au/prepare/ielts-preparation-material/reading
    2. Add IELTS Reading Assist to your shopping cart
    3. Use code Masterclass20 at checkout for 20% off
    4. Practise and boost your score!`)
    component.studentEventOverviewForm.controls.destination.setValue('Canada,Ireland')
    component.studentEventOverviewForm.controls.supportedStudyLevel.setValue('English')
    component.studentEventOverviewForm.controls.country.setValue('Australia')
    component.studentEventOverviewForm.controls.city.setValue('Melbourne')
    component.studentEventOverviewForm.controls.idpOffice.setValue('Mel-Off')
    component.studentEventOverviewForm.controls.idpTeam.setValue('Mel-Team')
    component.studentEventOverviewForm.controls.timezone.setValue('(GMT+10:00) AUS Eastern [Brisbane]')
    component.studentEventOverviewForm.controls.email.setValue('sourav@idp.com')
    component.studentEventOverviewForm.controls.firstName.setValue('sourav')
    component.studentEventOverviewForm.controls.lastName.setValue('kumar')
    expect(component.studentEventOverviewForm.valid).toBeTruthy()
    component.showLoaderIcon = true
    component.invalidForm = true
    component.selectedDestinationList = ['Australia', 'Canada']
    jest.spyOn(component, 'onSave')
    const btn = fixture.debugElement.nativeElement.querySelector('#saveButton')
    btn.click()
    expect(component.onSave).toHaveBeenCalled()
    const res = { statusCode: 200, status: 'success', body: { message: 'Data Saved Successfully.' } }
    jest.spyOn(service, 'patchStudentEvent').mockReturnValue(of(res))
    component.onSave()
    const undefinedRes = undefined
    jest.spyOn(service, 'patchStudentEvent').mockReturnValue(of(undefinedRes))
    component.onSave()
    const errRes = {
      status: 'failure',
      statusCode: 500
    }
    jest.spyOn(service, 'patchStudentEvent').mockReturnValue(of(errRes))
    component.onSave()
    // expect(component.openSnackBar).toHaveBeenCalledWith('Success message', 'success')
  })
  it('component should call patchStudentEvent method Api error response', () => {
    const res = {
      status: 'failure',
      statusCode: 500
    }
    jest.spyOn(service, 'patchStudentEvent').mockReturnValue(of(res))
    component.onSave()
  })
  it('component should call onSelectionChange method', () => {
    const validData = {
      option: {
        value: 'emptwo@yopmail.com'
      }
    }
    const inValidData = {
      option: {
        value: 'error@error.com'
      }
    }
    component.emailFilteredOptions = [{ first_name: 'Emp', last_name: 'Two', email: 'emptwo@yopmail.com' }, { first_name: 'Emp', last_name: 'Three', email: 'empthree@yopmail.com' }]
    component.onSelectionChange(validData)
    component.emailFilteredOptions = [{ first_name: 'Emp', last_name: 'Two', email: 'emptwo@yopmail.com' }, { first_name: 'Emp', last_name: 'Three', email: 'empthree@yopmail.com' }]
    component.onSelectionChange(inValidData)
  })
  it('component should call getEventPlannerEmail method', () => {
    component.getEventPlannerEmail()
    const res = { statusCode: 200, status: 'success', body: { message: 'A list of all the staffs based on the email text empthree@yopmail.com.', staffs: [{ first_name: 'Emp', last_name: 'Three', email: 'empthree@yopmail.com' }] } }
    jest.spyOn(service, 'getEventPlannerEmail').mockReturnValue(of(res))
    component.getEventPlannerEmail()
    component.emailFilteredOptions = res.body.staffs
    expect(component.studentEventDetails).toBeDefined()
  })
  it('component should call getStudentEventId method Api success response', () => {
    const successRes = {
      status: 'success',
      statusCode: 201,
      body: {
        studentEvent: { id: 'e26133cd-0a03-46dc-916f-3a68f2b4fdef', eventCode: '5KOPMVJCT2M' },
        message: 'A student event has been created successfully.'
      }
    }
    jest.spyOn(service, 'getStudentEventId').mockReturnValue(of(successRes))
    component.getStudentEventId()
    component.studentEventDetails = successRes
    expect(component.studentEventDetails).toBeDefined()
    const undefinedRes = undefined
    jest.spyOn(service, 'getStudentEventId').mockReturnValue(of(undefinedRes))
    component.getStudentEventId()
    const studentUndefRes = {
      status: 'success',
      statusCode: 201,
      body: undefined
    }
    jest.spyOn(service, 'getStudentEventId').mockReturnValue(of(studentUndefRes))
    component.getStudentEventId()
  })
  it('component should call getCountryList method Api success response', () => {
    const successRes = {
      status: 'success',
      statusCode: 200,
      result: {
        countries: [
          'India'
        ]
      }
    }
    jest.spyOn(service, 'getCountryList').mockReturnValue(of(successRes))
    component.getCountryList()
    component.studentEventDetails = successRes
    expect(component.studentEventDetails).toBeDefined()
    const undefinedRes = undefined
    jest.spyOn(service, 'getCountryList').mockReturnValue(of(undefinedRes))
    component.getCountryList()
    const studentUndefRes = {
      status: 'success',
      statusCode: 200,
      result: undefined
    }
    jest.spyOn(service, 'getCountryList').mockReturnValue(of(studentUndefRes))
    component.getCountryList()
  })
  it('component should call getOfficeList  method Api success response', () => {
    const successRes = {
      status: 'success',
      statusCode: 200,
      result: {
        countries: [
          'India'
        ]
      }
    }
    jest.spyOn(service, 'getCountryList').mockReturnValue(of(successRes))
    component.getOfficeList('India')
    component.studentEventDetails = successRes
    expect(component.studentEventDetails).toBeDefined()
    const undefinedRes = undefined
    jest.spyOn(service, 'getCountryList').mockReturnValue(of(undefinedRes))
    component.getOfficeList('India')
  })
  it('component should call getOfficeTeamList method Api success response', () => {
    component.idpOfficeList = [
      {
        officeName: 'IDP Khon Kaen Office',
        teams: [
          'Khon Kaen Counsellor Team'
        ]
      }
    ]
    component.idpOfficeTeamList = [
      'Khon Kaen Counsellor Team'
    ]
    component.getOfficeTeamList('IDP Khon Kaen Office')
  })
  it('component should call getTimezone method', () => {
    const successRes = {
      status: 'success',
      statusCode: 200,
      result: {
        timezoneList: [
          '(GMT+10:00) AUS Eastern [Brisbane]'
        ]
      }
    }
    jest.spyOn(service, 'getTimezone').mockReturnValue(of(successRes))
    component.getTimezone()
    component.studentEventDetails = successRes
    expect(component.studentEventDetails).toBeDefined()
  })
})
