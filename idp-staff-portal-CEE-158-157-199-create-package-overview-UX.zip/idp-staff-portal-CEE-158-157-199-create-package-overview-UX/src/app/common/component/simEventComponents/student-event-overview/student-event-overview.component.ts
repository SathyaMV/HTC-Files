import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { debounceTime, switchMap } from 'rxjs/operators'
import { CdkTextareaAutosize } from '@angular/cdk/text-field'
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { BffService } from '../../../../providers/bff.service'
import { simConstants } from '../../../../common/utilities/sim-constants'
import { Subscription } from 'rxjs'

@Component({
  selector: 'app-student-event-overview',
  templateUrl: './student-event-overview.component.html',
  styleUrls: ['./student-event-overview.component.css']
})
export class StudentEventOverviewComponent implements OnInit {
  @ViewChild('autosize') autosize: CdkTextareaAutosize
  studentEventDetails: any = {}
  userSupportedCountry: string = ''
  showLoaderIcon: boolean = false
  destinationCountryList: any = []
  supportedStudyLevelList: any = []
  selectedDestinationList: any = []
  selectedStudyLevelList: any = []
  idpOfficeTeamList = []
  countryList = []
  idpOfficeList: any = []
  selectedCountryTimezone = []
  emailFilteredOptions: any = []
  timezoneList: any
  invalidForm: boolean = false
  isEmailLoading = false
  noDataFound = false
  horizontalPosition: MatSnackBarHorizontalPosition = 'right'
  verticalPosition: MatSnackBarVerticalPosition = 'bottom'
  studentEventOverviewForm = new FormGroup({
    title: new FormControl('', [Validators.required]),
    description: new FormControl(''),
    destination: new FormControl('', [Validators.required]),
    supportedStudyLevel: new FormControl('', [Validators.required]),
    country: new FormControl('', [Validators.required]),
    idpOfficeName: new FormControl('', [Validators.required]),
    idpTeam: new FormControl('', [Validators.required]),
    timezone: new FormControl('', [Validators.required]),
    emailAddress: new FormControl('', [Validators.required, Validators.email, Validators.pattern(simConstants.emailPattern)]),
    firstName: new FormControl({ value: '', disabled: true }),
    lastName: new FormControl({ value: '', disabled: true })
  })

  subscriptions = new Subscription()
  eventData: any
  constructor (private readonly service: SimBbfService, private readonly snackBar: MatSnackBar,
    private readonly bbfService: BffService, private readonly el: ElementRef,
    private readonly langTranslateService: LangTranslateService) {
    this.subscriptions.add(this.service.eventData.subscribe(res => {
      this.eventData = res
    }))
  }

  ngOnInit (): void {
    this.getDestinationList()
    this.getSupportedStudyLevel()
    this.getEventPlannerEmail()
    this.getTimezone()
    this.getUserDetails()
    this.getCountryList()
    // this.getStudentEventId()
  }

  /**
   * @function getStudentEventId -
   *  get student event id from masterEvents.api */
  getStudentEventId (): void {
    this.showLoaderIcon = true
    const studentEventId = sessionStorage.getItem('studentEventId')
    const eventParam = { eventClassificationId: studentEventId }
    this.service.getStudentEventId(eventParam).subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.statusCode === 201) {
        this.studentEventDetails = res?.result?.studentEvent
      }
    })
  }

  /**
   * @function getUserDetails
   *  Fetch getUserDetails list from user permission service
  */
  getUserDetails (): void {
    this.bbfService.userPermission.subscribe((result: any) => {
      this.userSupportedCountry = result.supportedCountries ? result.supportedCountries[0] : ''
      this.studentEventOverviewForm.patchValue({
        country: this.userSupportedCountry
      })
      this.getOfficeList(this.userSupportedCountry)
    })
  }

  /**
   * @function getCountryList
   *  Fetch getCountryList list from countires api
  */
  getCountryList (): void {
    this.showLoaderIcon = true
    this.service.getCountryList('').subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.statusCode === 200) {
        this.countryList = res.result.countries
      }
    })
  }

  /**
   * @function getOfficeList
   *  Fetch idp Office list from country API While passing country name in query param
  */
  getOfficeList (e: any) {
    this.showLoaderIcon = true
    this.userSupportedCountry = e
    this.studentEventOverviewForm.patchValue({
      idpOfficeName: '',
      idpTeam: ''
    })
    this.service.getCountryList(e).subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.statusCode === 200) {
        this.idpOfficeList = res.result.offices
      }
      this.setTimezone()
    })
  }

  /**
     * @function getOfficeTeamList
     *  Fetch getOfficeTeamList list from offices list
    */
  getOfficeTeamList (idpOffice: any): void {
    this.studentEventOverviewForm.patchValue({
      idpOfficeName: idpOffice,
      idpTeam: ''
    })
    this.idpOfficeTeamList = this.idpOfficeList.filter((idpteam: any) => idpteam.officeName === idpOffice)[0].teams
  }

  /**
   * @function getTimezone
   *  Fetch getTimezone list from JSON
  */
  getTimezone (): void {
    this.service.getTimezone().subscribe((res: any) => {
      this.timezoneList = res
      this.setTimezone()
    })
  }

  /**
   * @function setTimezone
   *  Fetch setTimezone list from JSON
  */
  setTimezone (): void {
    this.idpOfficeTeamList = []
    Object.keys(this.timezoneList).find(key => {
      if (key === this.userSupportedCountry) {
        this.selectedCountryTimezone = this.timezoneList[key]
        this.studentEventOverviewForm.patchValue({
          timezone: this.timezoneList[key][0]
        })
      }
    })
  }

  /**
   * @function getDestinationList
   *  Fetch destination list from JSON
  */
  getDestinationList (): void {
    this.service.getDestination().subscribe(
      (res: any) => {
        this.destinationCountryList = res?.regions
      })
  }

  /**
   * @function selectedDestination
   *   Multi select destination
   */

  selectedDestination (selectedDest: any): void {
    this.selectedDestinationList.push(selectedDest.value)
    const index = this.destinationCountryList.findIndex((val: any) => val.name === selectedDest.value)
    this.destinationCountryList[index].isVisible = false
  }

  /**
   * @function  removeDestination
   *  Remove destination from selected form
  */
  removeDestination (remDestination: any): void {
    const index = this.selectedDestinationList.findIndex((val: any) => val === remDestination)
    this.selectedDestinationList.splice(index, 1)
    const destIndex = this.destinationCountryList.findIndex((val: any) => val.name === remDestination)
    this.destinationCountryList[destIndex].isVisible = true
    if (this.selectedDestinationList.length === 0) {
      this.studentEventOverviewForm.patchValue({
        destination: ''
      })
    } else {
      this.studentEventOverviewForm.patchValue({
        destination: this.selectedDestinationList.map((x: any) => x).join(',')
      })
    }
  }

  /**
   * @function getSupportedStudyLevel
   *  Fetch Supported Study Level list from JSON
  */
  getSupportedStudyLevel (): void {
    this.service.getSupportedStudyLevel().subscribe((res: any) => {
      this.supportedStudyLevelList = res?.studyLevel
    })
  }

  /**
   * @function selectedStudyLevel
   *   Multi select Study level
   */
  selectedStudyLevel (selectedLevel: any): void {
    this.selectedStudyLevelList.push(selectedLevel.value)
    const index = this.supportedStudyLevelList.findIndex((val: any) => val.name === selectedLevel.value)
    this.supportedStudyLevelList[index].isVisible = false
  }

  /**
   * @function removeStudyLevel
   *   Remove Study level from selected form
  */
  removeStudyLevel (remDestination: any): void {
    const index = this.selectedStudyLevelList.findIndex((val: any) => val === remDestination)
    this.selectedStudyLevelList.splice(index, 1)
    const destIndex = this.supportedStudyLevelList.findIndex((val: any) => val.name === remDestination)
    this.supportedStudyLevelList[destIndex].isVisible = true
    if (this.selectedStudyLevelList.length === 0) {
      this.studentEventOverviewForm.patchValue({
        supportedStudyLevel: ''
      })
    } else {
      this.studentEventOverviewForm.patchValue({
        supportedStudyLevel: this.selectedStudyLevelList.map((x: any) => x).join(',')
      })
    }
  }

  /**
   * @function onSave
   *  Save event overview form details
  */
  onSave (): void {
    this.service.sEventSave.next({ ...this.service.sEventSave.value, selectTab: 'student-event-overview' })
    if (this.studentEventOverviewForm.valid) {
      this.showLoaderIcon = true
      this.invalidForm = false
      const eventOverviewValue = this.studentEventOverviewForm.value
      const payloadData = {
        eventClassificationId: this.eventData.classificationId,
        eventTypeId: this.eventData.typeId,
        eventCategoryId: this.eventData.categoryId,
        requestType: 'create',
        status: 'Draft',
        eventOverview: {
          title: eventOverviewValue.title,
          description: eventOverviewValue.description,
          destination: this.selectedDestinationList.map(x => x).join(','),
          studyLevel: this.selectedStudyLevelList,
          country: eventOverviewValue.country,
          timezone: eventOverviewValue.timezone,
          emailAddress: eventOverviewValue.emailAddress,
          firstName: this.studentEventOverviewForm.controls.firstName.value,
          lastName: this.studentEventOverviewForm.controls.lastName.value,
          idpOfficeName: eventOverviewValue.idpOfficeName,
          idpTeam: eventOverviewValue.idpTeam
        }
      }
      this.service.patchStudentEvent(payloadData).subscribe((res: any) => {
        this.showLoaderIcon = false
        if (res?.statusCode === 200) {
          this.parseSaveResponse(res?.result)
          this.openSnackBar('Data Saved Successfully', 'success-snackbar')
        } else {
          this.openSnackBar('Data could not be saved', 'error-snackbar')
        }
      })
    } else {
      this.invalidForm = true
      if (this.studentEventOverviewForm.invalid) { // Focusing the error field
        for (const key of Object.keys(this.studentEventOverviewForm.controls)) {
          if (this.studentEventOverviewForm.controls[key].invalid) {
            const invalidControl = this.el.nativeElement.querySelector('[id="' + key + '"]')
            invalidControl.focus()
            break
          }
        }
      }
    }
  }

  /**
   * @function parseSaveResponse - parase save the event id
   * @param data - response data
  */
  parseSaveResponse (data): void {
    this.service.eventData.next({ ...this.service.eventData.value, id: data.studentEvent.id, eventCode: data.studentEvent.eventCode })
  }

  /**
   * @function getEventPlannerEmail
   *  Based on email search entry data will fetch from database
  */

  getEventPlannerEmail (): void {
    this.studentEventOverviewForm.controls.emailAddress.valueChanges.pipe(
      debounceTime(1000)
    ).subscribe((valueChanges: any) => {
      this.isEmailLoading = true
      if (valueChanges) {
        this.service.getEventPlannerEmail(valueChanges).subscribe((data: any) => {
          this.isEmailLoading = false
          if (data?.statusCode === 200) {
            this.emailFilteredOptions = data?.result.staffs
            this.noDataFound = !(data?.result.staffs.length > 0)
          }
        })
      } else {
        this.isEmailLoading = false
        this.emailFilteredOptions = []
        this.studentEventOverviewForm.patchValue({
          firstName: '',
          lastName: ''
        })
      }
    })
  }

  /**
   * @function onSelectionChange
   *  on email selection first name and last name will auto populate
  */
  onSelectionChange (e: any): void {
    const selectedEventPlanner: any = this.emailFilteredOptions.filter(option => option.email.toLowerCase().includes(e.option.value.toLowerCase()))[0]
    this.studentEventOverviewForm.patchValue({
      firstName: selectedEventPlanner?.firstName,
      lastName: selectedEventPlanner?.lastName
    })
  }

  /**
   * @function openSnackBar
   *  Toast Message
  */
  openSnackBar (message: string, type: string): void {
    this.snackBar.open(message, '', { horizontalPosition: this.horizontalPosition, verticalPosition: this.verticalPosition, duration: 2000, panelClass: [type] })
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
