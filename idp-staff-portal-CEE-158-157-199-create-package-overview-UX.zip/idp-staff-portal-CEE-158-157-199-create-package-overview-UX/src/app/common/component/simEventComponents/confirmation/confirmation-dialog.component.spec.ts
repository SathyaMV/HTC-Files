import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';

import { ConfirmationDialogComponent } from './confirmation-dialog.component';

describe('ConfirmationDialogComponent', () => {
  let component: ConfirmationDialogComponent;
  let fixture: ComponentFixture<ConfirmationDialogComponent>;

  const dialogMock = {
    updateSize() { }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConfirmationDialogComponent],
      imports: [
        RouterTestingModule,
        MatDialogModule
      ],
      providers: [{
        provide: MAT_DIALOG_DATA,
        useValue: {}
      },
      {
        provide: MatDialogRef, useValue: dialogMock
      }]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationDialogComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })

  it('should call updatesize', () => {
    jest.spyOn(component.dialogRef, 'updateSize')
    component.dialogRef.updateSize()
    expect(component.dialogRef.updateSize).toHaveBeenCalled()
  })

  it('click agree button', () => {
    jest.spyOn(component, 'dialogClose')
    const btn = fixture.debugElement.nativeElement.querySelector('#agree')
    btn.click()
    expect(component.dialogClose).toHaveBeenCalled()
  })

  it('click disagree button', () => {
    jest.spyOn(component, 'dialogClose')
    const btn = fixture.debugElement.nativeElement.querySelector('#disagree')
    btn.click()
    expect(component.dialogClose).toHaveBeenCalled()
  })
})
