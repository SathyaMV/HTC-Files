import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
export interface DialogData {
  title: string
  content: string
  agree: string
  disagree: string
}
@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.css']
})
export class ConfirmationDialogComponent implements OnInit {
  dialogData: any
  constructor (public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }

  ngOnInit (): void {
    this.dialogData = this.data
    this.dialogRef.updateSize('400px', '165px')
  }

  /**
   * @function dialogClose
   * @todo close popoup  diaslog window 
   */
  dialogClose (returnValue: string): void {
    this.dialogRef.close(returnValue)
  }
}
