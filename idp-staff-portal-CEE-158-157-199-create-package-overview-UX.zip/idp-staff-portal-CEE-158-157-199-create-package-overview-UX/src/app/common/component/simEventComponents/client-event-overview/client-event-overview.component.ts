/*
 * Creates an client event overview page
 * @class
 */
import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core'
import { CdkTextareaAutosize } from '@angular/cdk/text-field'
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Router } from '@angular/router'
import { MatDialog } from '@angular/material/dialog'
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar'
import {
  MAT_DATE_FORMATS
} from '@angular/material/core'
import { DatePipe } from '@angular/common'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { ConfirmationDialogComponent } from '../confirmation/confirmation-dialog.component'
import { simConstants } from '../../../../common/utilities/sim-constants'
import { ErrorHandlingDialogComponent } from '../errorHandling/error-handling.component'

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YY'
  },
  display: {
    dateInput: 'DD/MM/YY',
    monthYearLabel: 'MMM YYYY'
  }
}
@Component({
  selector: 'app-client-event-overview',
  templateUrl: './client-event-overview.component.html',
  styleUrls: ['./client-event-overview.component.css'],
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    DatePipe
  ]
})
export class ClientEventOverviewComponent implements OnInit {
  @Input() masterEvents: any = {}
  showLoaderIcon: boolean = false
  @ViewChild('autosize') autosize!: CdkTextareaAutosize
  constructor (private readonly el: ElementRef, private readonly router: Router,
    public readonly snackBar: MatSnackBar, public dialog: MatDialog,
    private readonly newMasterEventService: SimBbfService) { }

  invalidForm: boolean = false
  horizontalPosition: MatSnackBarHorizontalPosition = 'right'
  verticalPosition: MatSnackBarVerticalPosition = 'bottom'
  regionList: any = []
  countriesList: any = []
  selectedDestinationList: any[] = []
  destinationCountryList: any[] = []
  futureDate = new Date()
  eventOverviewForm: FormGroup = new FormGroup({
    title: new FormControl('', [Validators.required]),
    description: new FormControl('', [Validators.required]),
    destination: new FormControl('', [Validators.required]),
    startDate: new FormControl('', [Validators.required]),
    endDate: new FormControl('', [Validators.required]),
    region: new FormControl('', [Validators.required]),
    country: new FormControl('', [Validators.required])
  })

  ngOnInit (): void {
    this.futureDateValidation()
    this.getRegionList()
    this.getDestination()
  }

  /**
   * @function getDestination
   * @todo Fetch destination list from JSON
  */
  getDestination (): void {
    this.newMasterEventService.getDestination().subscribe((res: any) => {
      this.destinationCountryList = res?.regions
      this.destinationCountryList.forEach((x: any) => {
        x.isVisible = true
      })
    })
  }

  /**
   * @function futureDateValidation
   * @todo Future Date Validation
  */
  futureDateValidation (): void {
    const today = new Date()
    this.futureDate.setDate(today.getDate() + 1)
  }

  /**  Multi select destination
   * @function selectedDestination
   * @param {string} selectedDest - Select destination from country list
   * Add selected destination into destination list array
  */
  selectedDestination (selectedDest: any): void {
    this.selectedDestinationList.push(selectedDest.value)
    const index = this.destinationCountryList.findIndex((val: any) => val.name === selectedDest.value)
    this.destinationCountryList[index].isVisible = false
  }

  /**  Remove destination
   * @function removeDestination
   * @todo Remove destination from selected destination array list
  */
  removeDestination (remDestination: any): void {
    const index = this.selectedDestinationList.findIndex((val: any) => val === remDestination)
    this.selectedDestinationList.splice(index, 1)
    const destIndex = this.destinationCountryList.findIndex((val: any) => val.name === remDestination)
    this.destinationCountryList[destIndex].isVisible = true
    if (this.selectedDestinationList.length === 0) {
      this.eventOverviewForm.patchValue({
        destination: ''
      })
    } else {
      this.eventOverviewForm.patchValue({
        destination: this.selectedDestinationList.map(x => x).join(',')
      })
    }
  }

  /**
   * @function getRegionList
   * @todo Fetch Region list from api call
  */
  getRegionList (): void {
    this.showLoaderIcon = true
    this.newMasterEventService.getRegionList().subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.status === 'success') {
        this.regionList = res.body.regions
      } else {
        this.errorHandling(res.body.message)
      }
    })
  }

  /**
   * @function Get onRegionChange
   * @todo Fetch countries list from api based on region selection
   */
  onRegionChange (selectedRegion: any): void {
    this.showLoaderIcon = true
    const regionId = selectedRegion.value
    this.eventOverviewForm.patchValue({
      country: ''
    })
    this.newMasterEventService.getCountriesList(regionId).subscribe((res: any) => {
      this.showLoaderIcon = false
      if (res?.status === 'success') {
        this.countriesList = res?.body?.countries
      } else {
        this.countriesList = []
        this.errorHandling(res.body?.message)
      }
    })
  }

  /**
   * @function backToClassification
   * @todo Back to classification page
   */

  async backToClassification (): Promise<void> {
    await this.router.navigate([simConstants.routingUrl.createEvent])
  }

  /**
   * @function onSave
   * @todo Save event overview
  */
  onSave (): void {
    if (this.eventOverviewForm.valid) {
      this.showLoaderIcon = true
      this.invalidForm = false
      const eventOverviewValue = this.eventOverviewForm.value
      const pathParam = this.masterEvents.masterId
      const payloadData = {
        eventCode: this.masterEvents?.eventCode,
        title: eventOverviewValue.title,
        description: eventOverviewValue.description,
        destination: this.selectedDestinationList.map(x => x).join(','),
        startDate: this.formatDate(eventOverviewValue.startDate),
        endDate: this.formatDate(eventOverviewValue.endDate),
        hostRegion: eventOverviewValue.region,
        hostCountry: eventOverviewValue.country,
        tab: 'event-overview'
      }
      this.newMasterEventService.patchNewMasterEvents(payloadData, pathParam).subscribe((res: any) => {
        this.showLoaderIcon = false
        if (res?.status === 'success') {
          this.openSnackBar('Data Saved Successfully', 'success-snackbar')
        } else {
          this.openSnackBar('Data could not be saved', 'error-snackbar')
        }
      })
    } else {
      this.invalidForm = true
      if (this.eventOverviewForm.invalid) { // Focusing the error field
        for (const key of Object.keys(this.eventOverviewForm.controls)) {
          if (this.eventOverviewForm.controls[key].invalid) {
            const invalidControl = this.el.nativeElement.querySelector('[id="' + key + '"]')
            invalidControl.focus()
            break
          }
        }
      }
    }
  }

  /**
   * @function changeStartDate
   * @todo Reset End date while changing start date
  */
  changeStartDate (): void {
    this.eventOverviewForm.patchValue({
      endDate: ''
    })
  }

  /**
   * @function backToClassificationConfimation
   * @todo Confirmation popup for back button click event
  */
  backToClassificationConfimation (): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: { title: 'Are you sure you want to go back?', content: 'You will lose all the changes made here', agree: 'Yes', disagree: 'No' }
    })

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'Yes') {
        void this.backToClassification()
      }
    })
  }

  /**
   * @function errorHandling
   * @todo Http Error Handling
  */
  errorHandling (message: string): void {
    const dialogRef = this.dialog.open(ErrorHandlingDialogComponent, {
      data: { title: 'Technical Error', content: message, agree: 'Ok' }
    })
    dialogRef.afterClosed()
  }

  /**
   * @function openSnackBar
   * @todo Display Toast Message for success scenario
  */
  openSnackBar (message: string, type: string): void {
    this.snackBar.open(message, '', { horizontalPosition: this.horizontalPosition, verticalPosition: this.verticalPosition, duration: 2000, panelClass: [type] })
  }

  /**
   * @function keyPressNumbers
   * @todo Only Integer allows for date validation
   * */
  keyPressNumbers (event: any): Boolean {
    const charCode = (event?.which) ? event.which : event.keyCode
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault()
      return false
    } else {
      return true
    }
  }

  /**
   * @function keyPressEnter
   * @todo Only Integer allows for date validation
   * */
  keyPressEnter (event: any): Boolean {
    if (event.key === 'Enter') {
      event.preventDefault()
      return false
    } else {
      return true
    }
  }

  /**
   * @function formatDate
   * @todo Date format change based on save api format
  */
  formatDate (pdate: any): String {
    const date = new Date(pdate)
    const year = date.toLocaleString('default', { year: 'numeric' })
    const month = date.toLocaleString('default', { month: '2-digit' })
    const day = date.toLocaleString('default', { day: '2-digit' })
    const formattedDate = year + '/' + month + '/' + day
    return formattedDate
  }
}
