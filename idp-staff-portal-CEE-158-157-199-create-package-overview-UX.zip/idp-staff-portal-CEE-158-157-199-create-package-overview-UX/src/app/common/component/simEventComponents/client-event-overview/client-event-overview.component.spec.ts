import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { ComponentFixture, TestBed } from '@angular/core/testing'
import { HttpClientModule } from '@angular/common/http'
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { RouterTestingModule } from '@angular/router/testing'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { MatDialogModule } from '@angular/material/dialog'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatCardModule } from '@angular/material/card'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { MatSelectModule } from '@angular/material/select'
import { MatChipsModule } from '@angular/material/chips'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatButtonModule } from '@angular/material/button'
import { MatNativeDateModule } from '@angular/material/core'
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter'
import { of } from 'rxjs'

import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { ClientEventOverviewComponent } from './client-event-overview.component'

describe('ClientEventOverviewComponent', () => {
  let component: ClientEventOverviewComponent
  let fixture: ComponentFixture<ClientEventOverviewComponent>
  let simBbfService: SimBbfService
  let MockService: any
  let httpMock: HttpTestingController
  const event = { preventDefault: () => {} }
  const url = 'https://32n6te3069.execute-api.ap-southeast-1.amazonaws.com'
  beforeEach(async () => {
    MockService = {
      getDestination: jest.fn(),
      getRegionList: jest.fn()
    }
    await TestBed.configureTestingModule({
      declarations: [ClientEventOverviewComponent],
      imports: [
        NoopAnimationsModule, RouterTestingModule, HttpClientTestingModule,
        HttpClientModule, MatCardModule, FormsModule, ReactiveFormsModule,
        MatFormFieldModule, MatInputModule, MatSnackBarModule, MatDialogModule, MatDatepickerModule,
        MatSelectModule, MatChipsModule, MatButtonModule, MatNativeDateModule
      ],
      providers: [
        {
          provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS,
          useValue: { useUtc: true }
        },
        { provide: 'SimBbfService', useValue: MockService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents()
    simBbfService = TestBed.inject(SimBbfService)
    httpMock = TestBed.inject(HttpTestingController)
    jest.spyOn(event, 'preventDefault')
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientEventOverviewComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })
  it('should create ClientEventOverviewComponent', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.debugElement.componentInstance
    expect(app).toBeTruthy()
  })

  it('check initial form values', () => {
    const formValues = component.eventOverviewForm
    const eventOverviewForm = {
      title: '',
      description: '',
      destination: '',
      startDate: '',
      endDate: '',
      region: '',
      country: ''
    }
    expect(formValues.value).toEqual(eventOverviewForm)
  })

  it('check form before entering any values field errors)', () => {
    const title = component.eventOverviewForm.get('IELTS Masterclass Webinar - Listening and Reading')
    expect(title?.errors).not.toBeNull()

    const description = component.eventOverviewForm.get('description')
    expect(description?.errors).not.toBeNull()

    const destination = component.eventOverviewForm.get('destination')
    expect(destination?.errors).not.toBeNull()

    const startDate = component.eventOverviewForm.get('startDate')
    expect(startDate?.errors).not.toBeNull()

    const endDate = component.eventOverviewForm.get('endDate')
    expect(endDate?.errors).not.toBeNull()

    const region = component.eventOverviewForm.get('region')
    expect(region?.errors).not.toBeNull()

    const country = component.eventOverviewForm.get('country')
    expect(country?.errors).not.toBeNull()
  })

  it('invalid form', () => {
    component.eventOverviewForm.controls.title.setValue('')
    component.eventOverviewForm.controls.description.setValue('')
    component.eventOverviewForm.controls.destination.setValue('')
    component.eventOverviewForm.controls.startDate.setValue('')
    component.eventOverviewForm.controls.endDate.setValue('')
    component.eventOverviewForm.controls.region.setValue('')
    component.eventOverviewForm.controls.country.setValue('')
    expect(component.eventOverviewForm.valid).toBeFalsy()
  })

  it('should render input elements', () => {
    const compiled = fixture.debugElement.nativeElement
    const titleInput = compiled.querySelector('input[id="title"]')
    expect(titleInput).toBeTruthy()
  })

  it('click on save button', () => {
    jest.spyOn(component, 'onSave')
    const btn = fixture.debugElement.nativeElement.querySelector('#saveButton')
    btn.click()
    component.invalidForm = false
    expect(component.invalidForm).toEqual(false)
    expect(component.onSave).toHaveBeenCalled()
    component.eventOverviewForm.patchValue({
      title: 'title',
      description: 'descrition',
      destination: 'destination',
      startDate: 'startDate',
      endDate: 'endDate',
      region: 'region',
      country: 'country'
    })
    component.onSave()
    expect(component.eventOverviewForm.value).toBeDefined()
    expect(component.eventOverviewForm.valid).toEqual(false)
  })

  it('click on back button', () => {
    jest.spyOn(component, 'backToClassificationConfimation')
    const btn = fixture.debugElement.nativeElement.querySelector('#backToClassificationConfimation')
    btn.click()
    expect(component.backToClassificationConfimation).toHaveBeenCalled()
  })

  it('should call openDialog', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.backToClassificationConfimation()
  })

  it('Back to classification screen', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    const expectedHeader = 'Are you sure you want to go back'
    app.backToClassificationConfimation()
    fixture.detectChanges()
    expect('Are you sure you want to go back').toEqual(expectedHeader)
  })
  it('should call get region Api', () => {
    const expectedResult = [
      'Middle East',
      'Australasia',
      'SE Asia',
      'South Asia',
      'North Asia'
    ]
    simBbfService.getRegionList().subscribe((res: any) => {
      expect(res).toEqual(expectedResult)
    })
  })
  it('should call get country Api', () => {
    const expectedCountryResult = [
      'UAE',
      'QATAR',
      'OMAN'
    ]
    simBbfService.getCountriesList('Middle East').subscribe((res: any) => {
      expect(res).toEqual(expectedCountryResult)
    })
  })
  it('should call save event overview form Api', () => {
    const expectedResult = [
      'UAE',
      'QATAR',
      'OMAN'
    ]
    const payloadData = {
      eventCode: 'FFTTVVGGTH',
      title: 'IELTS Masterclass Webinar - Listening and Reading',
      description: 'IELTS Masterclass Webinar - Listening and Reading',
      destination: 'Canada,Ireland',
      startDate: '15/03/25',
      endDate: '15/03/25',
      hostRegion: 'Asia',
      hostCountry: 'india',
      tab: 'event-overview'
    }
    simBbfService.patchNewMasterEvents(payloadData, '').subscribe((res: any) => {
      expect(res).toEqual(expectedResult)
    })
  })

  it('component should call get Destination ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.getDestination()
    const mockData = [
      'Middle East',
      'Australasia',
      'SE Asia',
      'South Asia',
      'North Asia'
    ]
    simBbfService.getDestination().subscribe((data) => {
      expect(data).toEqual(mockData)
    })
    const req = httpMock.expectOne(`${url}/dev/v1/regions`)
    expect(req.request.method).toEqual('GET')
    req.flush(mockData)
  })
  it('component should call remove Destination ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.selectedDestinationList = [
      'Canada'
    ]
    expect(app.selectedDestinationList.length).toBeGreaterThan(0)
    app.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: true
    }, {
      code: 'CA',
      name: 'Canada',
      isVisible: true
    }]
    app.eventOverviewForm.patchValue({
      destination: app.destinationCountryList.map(x => x).join(',')
    })
    app.removeDestination('Australia')
    app.removeDestination('Canada')
    component.eventOverviewForm.controls.title.setValue('')
    component.eventOverviewForm.controls.description.setValue('')
    component.eventOverviewForm.controls.destination.setValue('')
    component.eventOverviewForm.controls.startDate.setValue('')
    component.eventOverviewForm.controls.endDate.setValue('')
    component.eventOverviewForm.controls.region.setValue('')
    component.eventOverviewForm.controls.country.setValue('')
    expect(component.eventOverviewForm.valid).toBeFalsy()
  })
  it('component should call selected Destination ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.destinationCountryList = [{
      code: 'AU',
      name: 'Australia',
      isVisible: false
    }, {
      code: 'CA',
      name: 'Canada',
      isVisible: true
    }]
    app.selectedDestination({ value: 'Australia' })
  })
  it('component should call Region Change ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.onRegionChange({ value: 'Australia' })
  })
  it('back to classification ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    void app.backToClassification()
  })
  it('change start date ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.changeStartDate()
  })
  it('call error handling ', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.errorHandling('Technical Error')
  })
  it('call openSnackBar method', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.openSnackBar('Success message', 'success')
  })
  it('call keyPressNumbers method', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.keyPressNumbers({ which: 56 })
  })
  it('call formatDate method', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.formatDate(new Date())
  })
  it('call futureDateValidation method', () => {
    const fixture = TestBed.createComponent(ClientEventOverviewComponent)
    const app = fixture.componentInstance
    app.futureDateValidation()
  })
  it('should call country api based on region', async () => {
    const expectedCountryResult = [
      'UAE',
      'QATAR',
      'OMAN'
    ]
    simBbfService.getCountriesList('Middle East').subscribe((res: any) => {
      expect(res).toEqual(expectedCountryResult)
      expect(1).toBe(1)
    })
  })
  it('should call country api based on region', async () => {
    const expectedResult = [
      'Middle East',
      'Australasia',
      'SE Asia',
      'South Asia',
      'North Asia'
    ]
    simBbfService.getRegionList().subscribe((res: any) => {
      expect(res).toEqual(expectedResult)
      expect(1).toBe(1)
    })
  })
  it('should call get Destination', async () => {
    const expectRes = {
      regions: [
        {
          code: 'AU',
          name: 'Australia',
          isVisible: true
        },
        {
          code: 'CA',
          name: 'Canada',
          isVisible: true
        }
      ]
    }
    jest.spyOn(simBbfService, 'getDestination').mockReturnValue(of(expectRes))
    component.getDestination()
    expect(component.destinationCountryList.length).toBeGreaterThan(0)
  })
  it('should call get RegionList', async () => {
    const expectRes = {
      regions: [
        'Middle East',
        'Australasia',
        'SE Asia',
        'South Asia',
        'North Asia'
      ]
    }
    jest.spyOn(simBbfService, 'getRegionList').mockReturnValue(of(expectRes))
    component.getRegionList()
    expect(component.regionList.length).toBeGreaterThanOrEqual(0)
  })
})