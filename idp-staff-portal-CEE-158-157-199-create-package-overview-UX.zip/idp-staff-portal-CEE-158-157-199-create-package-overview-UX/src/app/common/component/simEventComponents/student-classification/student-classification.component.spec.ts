import { ComponentFixture, TestBed } from '@angular/core/testing'

import { StudentClassificationComponent } from './student-classification.component'

describe('StudentClassificationComponent', () => {
  let component: StudentClassificationComponent
  let fixture: ComponentFixture<StudentClassificationComponent>

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StudentClassificationComponent]
    })
      .compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentClassificationComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
})
