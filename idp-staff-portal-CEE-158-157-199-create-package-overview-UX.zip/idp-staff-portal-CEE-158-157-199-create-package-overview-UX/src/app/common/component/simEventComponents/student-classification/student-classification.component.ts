import { Component, OnInit, Renderer2 } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { Subscription } from 'rxjs'
import { SimBbfService } from 'src/app/providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'

@Component({
  selector: 'app-student-classification',
  templateUrl: './student-classification.component.html',
  styleUrls: ['./student-classification.component.css']
})
export class StudentClassificationComponent implements OnInit {
  selectOption = ''
  currentCheckedValue = null
  studentClassification = ['Social', 'Settle', 'Success', 'General']
  studentClassificationForm: FormGroup = new FormGroup({
    classificationOption: new FormControl('')
  })

  subscriptions = new Subscription()
  constructor (private readonly ren: Renderer2, private readonly langTranslateService: LangTranslateService,
    private readonly service: SimBbfService) {
  }

  ngOnInit (): void {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      if (res.selectTab === 'physical-event-details') {
        this.service.physicalEventDetails.next({
          ...this.service.physicalEventDetails.value,
          studentClassification: this.studentClassificationForm
        })
      }
    }))
  }

  onSelectCaption (el: any) {
    setTimeout(() => {
      if (this.currentCheckedValue && this.currentCheckedValue === el.value) {
        el.checked = false
        this.ren.removeClass(el._elementRef.nativeElement, 'cdk-focused')
        this.ren.removeClass(el._elementRef.nativeElement, 'cdk-program-focused')
        this.ren.removeClass(el._elementRef.nativeElement, 'mat-radio-checked')
        this.currentCheckedValue = null
        this.studentClassificationForm.patchValue({
          classificationOption: ''
        })
      } else {
        this.currentCheckedValue = el.value
        this.studentClassificationForm.patchValue({
          classificationOption: el.value
        })
      }
    })
  }

  ngOnDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
