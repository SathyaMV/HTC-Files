import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { CommonModule } from '@angular/common'
import { LocationComponent } from './location.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatCardModule } from '@angular/material/card'
import { MatInputModule } from '@angular/material/input'
import { MatOptionModule } from '@angular/material/core'
import { MatSelectModule } from '@angular/material/select'
import { TranslateModule } from '@ngx-translate/core'

@NgModule({
  declarations: [LocationComponent],
  imports: [
    CommonModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    MatOptionModule,
    MatSelectModule,
    TranslateModule
  ],
  exports: [LocationComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class LocationModule { }
