import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { ComponentFixture, TestBed } from '@angular/core/testing'
import { LocationComponent } from './location.component'
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { MatCardModule } from '@angular/material/card'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input'
import { TranslateModule } from '@ngx-translate/core'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'

describe('LocationComponent', () => {
  let component: LocationComponent
  let fixture: ComponentFixture<LocationComponent>
  let service: SimBbfService
  let MockService: any

  beforeEach(async () => {
    MockService = {
    }
    await TestBed.configureTestingModule({
      declarations: [LocationComponent],
      imports: [
        TranslateModule.forRoot(), NoopAnimationsModule, HttpClientTestingModule,
        HttpClientModule, MatCardModule, FormsModule, ReactiveFormsModule,
        MatFormFieldModule, MatInputModule
      ],
      providers: [{ provide: 'SimBbfService', useValue: MockService }, LangTranslateService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents()
  })

  beforeEach(() => {
    service = TestBed.inject(SimBbfService)
    fixture = TestBed.createComponent(LocationComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })
  it('create a form', () => {
    expect(component.locationForm).not.toBeUndefined()
  })
  it('form invalid when empty', () => {
    component.locationForm.controls.venue.setValue('')
    component.locationForm.controls.address.setValue('')
    component.locationForm.controls.city.setValue('')
    component.locationForm.controls.zipcode.setValue('')
    expect(component.locationForm.valid).toBeFalsy()
  })
  it('form validation', () => {
    component.locationForm.controls.venue.setValue('IDP office')
    component.locationForm.controls.address.setValue('Guindy')
    component.locationForm.controls.city.setValue('Chennai')
    component.locationForm.controls.zipcode.setValue('645732')
    expect(component.locationForm.valid).toBeTruthy()
  })
  it('venue field validity', () => {
    const name = component.locationForm.controls.venue
    expect(name.valid).toBeFalsy()
    name.setValue('')
    expect(name.hasError('required')).toBeTruthy()
  })
  it('test venue field maxlength', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#venue')
    const inputElement = formElement.getAttribute('maxlength')
    expect(parseInt(inputElement)).toEqual(100)
  })
  it('test address field maxlength', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#address')
    const inputElement = formElement.getAttribute('maxlength')
    expect(parseInt(inputElement)).toEqual(160)
  })
  it('test city field maxlength', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#city')
    const inputElement = formElement.getAttribute('maxlength')
    expect(parseInt(inputElement)).toEqual(40)
  })
  it('test zipcode field maxlength', () => {
    const formElement = fixture.debugElement.nativeElement.querySelector('#zipcode')
    const inputElement = formElement.getAttribute('maxlength')
    expect(parseInt(inputElement)).toEqual(10)
  })
})
