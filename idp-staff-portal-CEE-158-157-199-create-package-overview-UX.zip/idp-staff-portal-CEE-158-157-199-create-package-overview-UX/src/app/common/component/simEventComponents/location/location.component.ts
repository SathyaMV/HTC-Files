import { Component, OnInit } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { Subscription } from 'rxjs'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {
  locationForm = new FormGroup({
    venue: new FormControl('', [Validators.required]),
    address: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    zipcode: new FormControl('', [Validators.required])
  })

  // country = 'India'
  // cityList: any[] = [
  //   { name: 'Adelaide' },
  //   { name: 'Brisbane' }
  // ]

  isValidForm: boolean = false
  subscriptions = new Subscription()
  constructor (private readonly langTranslateService: LangTranslateService, private readonly service: SimBbfService) {
    this.subscriptions.add(this.service.sEventSave.subscribe(res => {
      this.isValidForm = res.isSave

      if (res.selectTab === 'physical-event-details') {
        this.service.physicalEventDetails.next({ ...this.service.physicalEventDetails.value, location: this.locationForm })
      } else if (res.selectTab === 'event-details') {
        this.service.eventDetails.next({ ...this.service.eventDetails.value, location: this.locationForm })
      }
    }))
  }

  ngOnInit (): void {
  }

  ngOnDestory (): void {
    this.subscriptions.unsubscribe()
  }
}
