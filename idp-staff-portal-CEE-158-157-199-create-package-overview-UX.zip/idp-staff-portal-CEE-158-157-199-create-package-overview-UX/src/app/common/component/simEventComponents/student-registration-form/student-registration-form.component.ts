/*
 * Creates a student registration form component
 * @class
 */
import { Component, OnInit } from '@angular/core'
import { Subscription } from 'rxjs'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { LangTranslateService } from '../../../../providers/lang-translate.service'
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms'

@Component({
  selector: 'app-student-registration-form',
  templateUrl: './student-registration-form.component.html',
  styleUrls: ['./student-registration-form.component.css']
})
export class StudentRegistrationFormComponent implements OnInit {
  constructor (private readonly langTranslateService: LangTranslateService, private readonly fb: FormBuilder) { }

  regForm: FormGroup = new FormGroup({
    mandatoryFields: this.fb.array([]),
    additionalFields: this.fb.array([])
  })

  mandatoryFields = [{ selected: true, label: 'First Name' },
    { selected: true, label: 'Last Name' },
    { selected: true, label: 'Email' },
    { selected: true, label: 'Dialcode' },
    { selected: true, label: 'Mobile' },
    { selected: true, label: 'Nearest IDP Office' },
    { selected: true, label: 'How Did You Hear About IDP Event' },
    { selected: true, label: 'GDPR 1 (Terms And Conditions Acceptance)' },
    { selected: true, label: 'GDPR 2 (Contact Me By)' }]

  additionalFields = [{ selected: false, label: 'Highest Education' },
    { selected: false, label: 'Nationality' },
    { selected: false, label: 'Preferred Subject' },
    { selected: false, label: 'Intend Study Plan' },
    { selected: false, label: 'Preferred Study Destination' },
    { selected: false, label: 'Preferred Mode of Counselling' },
    { selected: false, label: 'Preferred Session' },
    { selected: false, label: 'Study Level' },
    { selected: false, label: 'Education Funding' },
    { selected: false, label: 'GDPR 3 (Marketing Acceptance)' }]

  onChange (event: any): void {
    const additionalFields = this.regForm.get('additionalFields') as FormArray
    if (event.checked === true) {
      additionalFields.push(new FormControl(event.source.value))
    } else {
      const i = additionalFields.controls.findIndex(x => x.value === event.source.value)
      additionalFields.removeAt(i)
    }
  }

  ngOnInit (): void {
    const mandatoryFields = this.regForm.get('mandatoryFields') as FormArray
    this.mandatoryFields.forEach(x => {
      mandatoryFields.push(new FormControl(x.label))
    })
  }
}
