/*
 * Creates a client event header page
 * @class
 */
import { Component, Input, OnInit } from '@angular/core'

@Component({
  selector: 'app-client-event-header',
  templateUrl: './client-event-header.component.html',
  styleUrls: ['./client-event-header.component.css']
})
export class ClientEventHeaderComponent implements OnInit {
  @Input() masterEvents: any = {}

  constructor () { }

  ngOnInit (): void {
  }
}
