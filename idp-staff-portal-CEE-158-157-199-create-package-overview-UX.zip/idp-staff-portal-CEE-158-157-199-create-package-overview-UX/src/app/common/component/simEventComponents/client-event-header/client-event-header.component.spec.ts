import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientEventHeaderComponent } from './client-event-header.component';

describe('ClientEventHeaderComponent', () => {
  let component: ClientEventHeaderComponent;
  let fixture: ComponentFixture<ClientEventHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientEventHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientEventHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
