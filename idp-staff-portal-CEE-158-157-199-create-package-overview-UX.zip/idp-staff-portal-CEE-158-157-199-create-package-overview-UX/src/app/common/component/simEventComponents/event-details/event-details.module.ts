import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatCardModule } from '@angular/material/card'
import { EventDetailsComponent } from './event-details.component'
import { EventDateTimeModule } from '../event-date-time/event-date-time.module'
import { StudentCapacityModule } from '../student-capacity/student-capacity.module'
import { SpeakerDetailsModule } from '../speaker-details/speaker-details.module'
import { StudentClassificationModule } from '../student-classification/student-classification.module'
import { LocationModule } from '../location/location.module'
import { VideoConferenceModule } from '../video-conference/video-conference.module'
import { MatSnackBarModule } from '@angular/material/snack-bar'
import { LoaderIconModule } from '../../loader-icon/loader-icon.module'

@NgModule({
  declarations: [
    EventDetailsComponent
  ],
  imports: [
    CommonModule,
    MatCardModule,
    EventDateTimeModule,
    StudentCapacityModule,
    SpeakerDetailsModule,
    StudentClassificationModule,
    LocationModule,
    VideoConferenceModule,
    LoaderIconModule,
    MatSnackBarModule
  ],
  exports: [
    EventDetailsComponent
  ]
})
export class EventDetailsModule { }