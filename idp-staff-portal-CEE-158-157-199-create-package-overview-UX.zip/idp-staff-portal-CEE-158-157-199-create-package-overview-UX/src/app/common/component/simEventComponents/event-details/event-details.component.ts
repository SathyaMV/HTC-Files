import { Component, OnInit, ViewChild } from '@angular/core'
import { MatDialog } from '@angular/material/dialog'
import { MatSnackBar } from '@angular/material/snack-bar'
import { Subscription } from 'rxjs'
import { SimBbfService } from '../../../../providers/sim-bbf.service'
import { StudEventSave } from '../common/stud-event-save'
@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent extends StudEventSave {
  subscriptions = new Subscription()
  eventType: string
  eventCategory: string
  constructor (public readonly service: SimBbfService, public dialog: MatDialog, public readonly snackBar: MatSnackBar) {
    super(service, dialog, snackBar)
    this.subscriptions.unsubscribe()
    this.subscriptions.add(this.service.eventDetails.subscribe(res => {
      this.validateData(res)
    }))
    this.subscriptions.add(this.service.eventData.subscribe(res => {
      this.eventType = res.type
      this.eventCategory = res.category
      this.eventId = res.id
      this.eventClassificationId = res.classificationId
    }))
  }

  /**
   * @function validateData -Verifiy whether form has valid data or not
   * @param res - Form data
   * */
  validateData (res): void {
    if (!this.validateDataAndTime(this.eventDateAndTime)) return
    if (this.eventType === 'Physical' && res.location.status === 'INVALID' && (this.eventCategory === 'Pre Departure' || this.eventCategory === 'Seminar' || this.eventCategory === 'Thrive Events')) return
    if (res.videoConfDetails.status === 'INVALID' && (this.eventType === 'Virtual' || (this.eventType === 'Webinar' && this.eventCategory === 'Seminar'))) return
    if (this.eventCategory === 'Seminar' && res.speakerDetails.status === 'INVALID') return
    if (this.eventType !== 'Webinar' && this.eventCategory === 'Thrive Events' && res.studentClassification === 'INVALID') return
    if (this.eventType === 'Physical' && res.studentCapacity.status === 'INVALID') return
    this.getPayloadData(res)
  }

  /**
   * @function saveFilledData - trigger that save button is pressed
   * */
  saveFilledData (): void {
    this.service.sEventSave.next({ ...this.service.sEventSave.value, isSave: true, selectTab: 'event-details' })
  }

  /**
   * @function getPayloadData - forms Payload data
   * @param res - Form data
   * */
  getPayloadData (res): void {
    this.showLoaderIcon = true
    const payloadData = {
      id: this.eventId,
      eventClassificationId: this.eventClassificationId,
      eventTypeId: this.eventTypeId,
      eventCategoryId: this.eventCategoryId,
      requestType: 'update',
      status: 'Draft',
      eventDetails: {
        startDate: this.eventDateAndTime.eventStartDate.replaceAll('/', '-'),
        endDate: this.eventDateAndTime.eventEndDate.replaceAll('/', '-'),
        startTime: this.eventDateAndTime.eventStartTime,
        endTime: this.eventDateAndTime.eventEndTime,
        includePhysicalEvent: false,
        includeVirtualEvent: false
      }
    }

    const addPayload: any = {}
    if (this.eventType === 'Physical' && (this.eventCategory === 'Pre Departure' || this.eventCategory === 'Seminar' ||
     this.eventCategory === 'Thrive Events')) {
      addPayload.venue = res.location.value.venue
      addPayload.address = res.location.value.address
      addPayload.city = res.location.value.city
      addPayload.zipcode = res.location.value.zipcode
    }
    if ((this.eventType === 'Virtual' || (this.eventType === 'Webinar' && this.eventCategory === 'Seminar'))) {
      addPayload.videoConferencing = this.createVideoArr(res.videoConfDetails.value)
    }
    if (this.eventCategory === 'Seminar') {
      addPayload.speakerName = res.speakerDetails.value.speakerInput
    }
    if (this.eventType !== 'Webinar' && this.eventCategory === 'Thrive Events') {
      addPayload.classifications = res.studentClassification
    }
    if (this.eventType === 'Physical') {
      addPayload.capacity = Number(res.studentCapacity.value.capacityInput)
    }
    payloadData.eventDetails = { ...payloadData.eventDetails, ...addPayload }
    this.saveFormData(payloadData)
  }

  /**
   * @function updateFormGroupValue
   * @todo update date and time value in form group
   * */
  updateDateTime (e: any): void {
    this.eventDateAndTime = e
  }

  ngDestroy (): void {
    this.subscriptions.unsubscribe()
  }
}
