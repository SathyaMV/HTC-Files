import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ReferralsComponent } from './referrals.component';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';


@NgModule({
    declarations: [ReferralsComponent],
    imports:[ MatCheckboxModule,
        MatButtonModule,
        FormsModule,
        MatFormFieldModule,
        MatInputModule,
        MatTabsModule,
        CommonModule,
        FormsModule,ReactiveFormsModule,],
    exports:[
        ReferralsComponent
    ]
})

export class ReferralModule{

}