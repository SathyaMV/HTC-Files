import { Component, Input, OnInit } from '@angular/core';
import { BffService } from '../../../providers/bff.service';
@Component({
  selector: 'app-referrals',
  templateUrl: './referrals.component.html',
  styleUrls: ['./referrals.component.css']
})
export class ReferralsComponent implements OnInit {
  selectedValues: any[] = [];
  submitted = false;
  @Input() referralData;
  displayData = []
  maxLengthExceed = false
  selectedInstituteID = []
  isPastEvent = sessionStorage.getItem('pastEvent_' +sessionStorage.getItem('tabID')).includes('true');
  successMsg:boolean = false

  constructor(private bff: BffService) { }

  ngOnInit(): void {
    this.getReferralData()
  }

  // Method to convert the api response into required array
  getReferralData() {
    this.referralData?.map((val) => {
      val.notesVisible = false;
      val.selected = false;
    })
    this.referralData?.forEach((ele) => {
      if (ele.institutionCountry !== '' && ele.institutionName !== '') {
        let index = this.displayData.findIndex(value => value.countryName === ele.institutionCountry)
        if (index === -1) {
          let obj = {
            countryName: ele.institutionCountry,
            count: 1,
            universities: [ele]
          }
          this.displayData.push(obj)
        } else {
          this.displayData[index].count++
          this.displayData[index].universities.push(ele)
        }
      }
    })
  }


//This method is used for toggling notes
  addNotes(country, institutionId) {
    this.displayData.forEach(val => {
      if (val.countryName === country) {
        val.universities.forEach(institute => {
          if (institute.institutionId === institutionId) {
            institute.notesVisible = !institute.notesVisible
          }
        })
      }
    })
  }

  sendReferrals() {
    this.submitted = true;
    const eventCode = sessionStorage.getItem('eventCode_'+ sessionStorage.getItem('tabID'));
    const studentId = sessionStorage.getItem('studentId_' + sessionStorage.getItem('tabID'))
    let validLengthData = this.selectedValues.every(obj => this.validateNotes(obj.notes))
    this.referredStudents()
    if(validLengthData && this.selectedValues.length !== 0 ){
      let payload = {
        eventCode: eventCode,
        studentId: studentId,
        institutionReferrals: this.getNotes(this.selectedValues)
      }
      this.bff.updateReferralDetails(payload).subscribe((data) => {
        this.selectedValues = []
        this.successMsg = true
        setTimeout(() => {
          this.successMsg = false
        }, 2000);
      })
    }
  }
//This method is used as the payload for instutution referrals param
  getNotes(value) {
    let referredUniversity = [];
    value.forEach(val => {
      referredUniversity.push({
        notes: val.notes,
        institutionId: val.institutionId
      })
    })
    return referredUniversity;
  }

  onChange(item: any) {
    if (item.selected) {
      this.selectedValues.push(item);
    } else {
      const index = this.selectedValues.indexOf(item);
      this.selectedValues.splice(index, 1);
    }
  }

  //This method is used to change referred true while clicking send referral Button
  referredStudents(){
    let isValidData = this.selectedValues.every(obj => this.validateNotes(obj.notes))
    if(isValidData){
      this.displayData.forEach((data) => {
        data.universities.forEach((univ) => {
          this.selectedValues.forEach((select) => {
            if(univ.institutionId === select.institutionId && this.validateNotes(univ.notes)){
              univ.referred = true
            }
          })
        })
      })
    }
  }

  validateNotes(notes) {
    notes = notes.trim();
    return notes.length === 0 || (notes.length >=3 && notes.length <=300)
  }
}
