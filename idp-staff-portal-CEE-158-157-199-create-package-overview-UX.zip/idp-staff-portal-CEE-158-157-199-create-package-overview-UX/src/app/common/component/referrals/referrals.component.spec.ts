import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReferralsComponent } from './referrals.component';

describe('ReferralsComponent', () => {
  let component: ReferralsComponent;
  let fixture: ComponentFixture<ReferralsComponent>;
  let service: BffService;

  const referralMockData = [
    { notesVisible: true, selected: true, maxlength: true, minlength: true },
    { notesVisible: true, selected: true, maxlength: true, minlength: true },
    { notesVisible: true, selected: true, maxlength: true, minlength: true },
  ];


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReferralsComponent],
      imports: [CdkAccordionModule,
        HttpClientModule]
    })
      .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferralsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set notesVisible, selected, maxlength, and minlength to false for all values in referralData', () => {
    component.getReferralData();
    component.referralData = referralMockData?.map((val) => {
      val.notesVisible = false;
      val.selected = false;
      val.maxlength = false;
      val.minlength = false;
    });
    expect(referralMockData[0].notesVisible).toBe(false);
    expect(referralMockData[0].selected).toBe(false);
    expect(referralMockData[0].maxlength).toBe(false);
    expect(referralMockData[0].minlength).toBe(false);

    expect(referralMockData[1].notesVisible).toBe(false);
    expect(referralMockData[1].selected).toBe(false);
    expect(referralMockData[1].maxlength).toBe(false);
    expect(referralMockData[1].minlength).toBe(false);

    expect(referralMockData[2].notesVisible).toBe(false);
    expect(referralMockData[2].selected).toBe(false);
    expect(referralMockData[2].maxlength).toBe(false);
    expect(referralMockData[2].minlength).toBe(false);
  })

  it("should add selected item to selectedValues array if item.selected is true", () => {
    const item = { selected: true };
    component.onChange(item);
    expect(component.selectedValues).toContain(item);
  });

  it("should remove item from selectedValues array if item.selected is false", () => {
    const item = { selected: true };
    component.selectedValues.push(item);
    item.selected = false;
    component.onChange(item);
    expect(component.selectedValues).not.toContain(item);
  });

  it("should correctly update properties in displayData based on selectedValues", () => {
    component.displayData = [{
      universities: [{ institutionId: 1, referred: false, maxlength: false, minlength: false, }, { institutionId: 2, referred: false, maxlength: false, minlength: false, },],
    },
    {
      universities: [
        {
          institutionId: 3,
          referred: false,
          maxlength: false,
          minlength: false,
        },
      ],
    },
    ];
    component.selectedValues = [{ institutionId: 1, notes: "Some long notes" }, { institutionId: 3, notes: "x" },];
    expect(component.displayData[0].universities[0].referred).toBe(true);
    expect(component.displayData[0].universities[0].maxlength).toBe(false);
    expect(component.displayData[0].universities[0].minlength).toBe(false);

    expect(component.displayData[0].universities[1].referred).toBe(false);
    expect(component.displayData[0].universities[1].maxlength).toBe(false);
    expect(component.displayData[0].universities[1].minlength).toBe(false);

    expect(component.displayData[1].universities[0].referred).toBe(true);
    expect(component.displayData[1].universities[0].maxlength).toBe(false);
    expect(component.displayData[1].universities[0].minlength).toBe(true);
  });

  it("should correctly return an array of notes and institutionIds from input array", () => {
    const input = [{ institutionId: 1, notes: "Some notes" }, { institutionId: 2, notes: "Other notes" },];
    const expectedOutput = [{ institutionId: 1, notes: "Some notes" }, { institutionId: 2, notes: "Other notes" },];
    const output = component.getNotes(input);
    expect(output).toEqual(expectedOutput);
  });

});

