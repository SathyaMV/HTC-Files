import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import * as XLSX from 'xlsx';
import { ActivatedRoute } from '@angular/router';
import { Auth } from 'aws-amplify';

let errors:any = {};
let showErrors:boolean = false;

@Component({
  selector: 'app-bulk-upload-table',
  templateUrl: './bulk-upload-table.component.html',
  styleUrls: ['./bulk-upload-table.component.css']
})

export class BulkUploadTableComponent implements OnInit, OnDestroy {

  bulkUploadTableData;
  fileName;
  @Input() eventTitle
  tableRows:FormGroup
  eventQuestionData = []
  showTableData = false;
  errorRow = false;
  columnDefs = [];
	rowData = [];
  columnList = [];  
  checkBoxObj = [{option_value : 'Yes', option_desc : 'Yes'},{option_value : 'No', option_desc : 'No'}]
  checkBoxYesObj = [{option_value : 'Yes', option_desc : 'Yes'}]
  checkBoxNoObj = [{option_value : 'No', option_desc : 'No'}]
  cventCode;
  noOfErrorRows;
  dialCodeInfo;
  eventDetails;
  validDataArray = []
  showTable:boolean = true
  bulkUploadTableDataArray = []
  dataWithError = [];
  bulkUploadTableDataArrayPage = 25;
  dataWithErrorArrayPage = 25;
  importedDataCount:number = 0;
  showImportedData:boolean = false;
  showLoaderIcon:boolean = false;
  surveyResponse;
  isFutureEvent: boolean = false;
  uploadedBy: string = '';
  constructor(private formBuilder:FormBuilder, private bff :BffService, private methods:CommonMethods,
    private route:ActivatedRoute) {
    this.tableRows = new FormGroup({
      formArrayName: this.formBuilder.array([])
    })
    window.addEventListener('beforeunload', this.preventReload);
  }

  ngOnInit(): void {
    this.getEventQuestion();
      this.getCventCode();
      this.bff.showbulkUploadTable.subscribe(data=>{
        this.showTable = data;
        if(!data){
          this.bff.showFileUploadScreen.next(false);
          this.bff.showBulkUploadSurveyQn.next(false);
        }
      })

    this.bff.excelFileData.subscribe(data=>{
      if(data?.['excelData'] != undefined){
        this.bulkUploadTableData = data?.['excelData']?.length > 0 ? data['excelData'] : '';
        this.showTable = data?.['excelData']?.length > 0 ? true : false;
      }
    })

    this.bff.bulkUploadSurvey.subscribe(data => {
      this.surveyResponse = data;
    })

    if(this.bulkUploadTableData?.length > this.bulkUploadTableDataArrayPage){
      this.bulkUploadTableDataArray = this.bulkUploadTableData.slice(0,25);
    }else{
      this.bulkUploadTableDataArray = this.bulkUploadTableData;
    }

    Auth.currentAuthenticatedUser().then(user => {
      this.uploadedBy = user.attributes.email
    })
  }

  onScroll(event){
    if (Math.ceil(event.target.offsetHeight + event.target.scrollTop) >= event.target.scrollHeight - 500) {
      if(this.bulkUploadTableData?.length > this.bulkUploadTableDataArrayPage && !this.errorRow){
        let tmpArray = this.bulkUploadTableData.slice(this.bulkUploadTableDataArrayPage,this.bulkUploadTableDataArrayPage+25);
        this.bulkUploadTableDataArray = this.bulkUploadTableDataArray.concat(tmpArray);
        this.bulkUploadTableDataArrayPage += 25;
      }
      if(this.dataWithError?.length > this.dataWithErrorArrayPage && this.errorRow){
        let tmpArray = this.dataWithError.slice(this.dataWithErrorArrayPage,this.dataWithErrorArrayPage+25);
        this.bulkUploadTableDataArray = this.bulkUploadTableDataArray.concat(tmpArray);
        this.dataWithErrorArrayPage += 25;
      }
    }

  }

  errorStatus(){
  }

  getCventCode(){
    this.route.queryParams.subscribe(params=>{
      if(params.eventCode){
        this.cventCode =  params.eventCode;
      }   
    })
  }

  getEventQuestion(){    
    this.route.queryParams.subscribe(params=>{
      if(params.eventCode){
        this.cventCode =  params.eventCode;
      }   
    })
    this.bff.getBulkUploadPPQuestions(this.cventCode,'EN').subscribe(data=>{
      this.eventDetails = data.eventDetails
      if (new Date(this.eventDetails.eventStartDate) > new Date()) {
        this.isFutureEvent = true;
      }
      this.eventQuestionData = data.items[0].fields.questions
      this.dialCodeInfo = data.dialCode;
      this.eventQuestionData = this.methods.sortByDisplaySequence(this.eventQuestionData,'displaySequence')
        this.buildForm();
        this.showTableData = !this.showTableData;
    })
  }

  buildForm(){
    this.tableRows = new FormGroup({
      formArrayName: this.formBuilder.array([])
    })
    const controlArray = this.tableRows.get('formArrayName') as FormArray;
    Object.keys(this.bulkUploadTableData).forEach((i) => {
      let emptyObj = {}
      let defaultValue:any
      let options = [];
      this.eventQuestionData.forEach((j)=>{
        if(j.displayFormat.value === 'CHECKBOX'){
          if(j.mappingField === 'termsAndConditionsAcceptance' || j.mappingField === 'contactMeBy'){
            j.options = this.checkBoxYesObj
          }else{
            j.options = this.checkBoxObj
          }
        }
        defaultValue = this.bulkUploadTableData[i][j.mappingField];
        if(j.displayFormat.value === 'SELECT_BOX' || j.displayFormat.value === 'CHECKBOX' || j.displayFormat.value === 'AJAX' ){
          if (j.mappingField === 'eventParticipant' && this.isFutureEvent) {
            j.options = this.checkBoxNoObj;
            options = (j.options.map(() => 'No'))
          } else {
            options = (j.options.map(ele=>{return ele.option_desc}))
          }
          // if(options.indexOf(defaultValue) === -1 && defaultValue != null){
          //   defaultValue = this.bulkUploadTableData[i][j.mappingField];
          // }
        }
        emptyObj[j.mappingField] = new FormControl(defaultValue,this.getValidators(j,i))
      })
      controlArray.push(this.formBuilder.group(emptyObj))})
      this.noOfErrorRows = this.tableRows.controls['formArrayName']['controls'].filter(data=>{
        return data.status === 'INVALID';
      })?.length
      this.tableRows.valueChanges.subscribe(x=>{
        let errorBeforeChange = this.noOfErrorRows;
        this.noOfErrorRows = this.tableRows.controls['formArrayName']['controls'].filter(data=>{
          return data.status === 'INVALID';
        })?.length

        if (errorBeforeChange == this.noOfErrorRows + 1 && this.errorRow) {
          let tmpArray = this.dataWithError.slice(this.dataWithErrorArrayPage, this.dataWithErrorArrayPage + 1);
          this.bulkUploadTableDataArray = this.bulkUploadTableDataArray.concat(tmpArray);
          this.dataWithErrorArrayPage += 1;
        }
      })
  }

  getValidators(field,i) {
    let fieldValidators = [];
    if (field.mandatory) {
      fieldValidators.push(Validators.required);
    }
    
    if (field.maxLength != '') {
      fieldValidators.push(Validators.maxLength(field.maxLength));
    }

    if (field.mappingField == 'primary_email') {
      let emailPattern = /^\w+([-+.'']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
      fieldValidators.push(Validators.pattern(emailPattern));
      fieldValidators.push(this.checkIfUnique(i));
    }

    if (field.mappingField == 'primary_mobile_number') {
      let numberPattern = '[0-9]*'
      fieldValidators.push(Validators.pattern(numberPattern));
      fieldValidators.push(this.checkMobileNumber(i));
    }

    if(field.mappingField.includes('marketing_acceptance')){
      fieldValidators.push(this.checkMarkettingAcceptance(i))
    }

    if (field.displayFormat.value === 'SELECT_BOX' || field.displayFormat.value === 'CHECKBOX' || field.displayFormat.value === 'AJAX' ) {
      fieldValidators.push(this.checkSelect(field.options))
    }
    return fieldValidators;
  }

  hideErrorFreeRows(event){
    this.errorRow = event.checked;
    if(event.checked) {
      this.dataWithError = this.getErrorData();
      this.bulkUploadTableDataArray = this.dataWithError.slice(0,25);
      this.dataWithErrorArrayPage = 25;
    } else {
      this.bulkUploadTableDataArray = this.bulkUploadTableData.slice(0,25);
      this.bulkUploadTableDataArrayPage = 25;
    }
  }

  downLoadErros(){
    let errorRecordManipulation = []
    let i = 0
    this.tableRows.controls['formArrayName']['controls'].map(data=>{
      if(this.tableRows.controls['formArrayName']['controls'][i].status === 'INVALID'){
        let tmpObj = {}
        Object.keys(data.value).forEach(ele=>{
          tmpObj[ele] = data.value[ele] == '' ? this.bulkUploadTableData[i][ele] : data.value[ele]
        })
        errorRecordManipulation.push(tmpObj)
      }
      i++      
    })

    this.methods.downLoadErrorRecords(errorRecordManipulation,this.eventQuestionData);
    const successDownloadCount = errorRecordManipulation.length;
    const downloadStatus = 'Successfully downloaded'+' '+ successDownloadCount +' '+ 'errors'
    if(successDownloadCount > 0){
      const payLoad = this.bulkUploadLogDetails('Download',downloadStatus,successDownloadCount.toString(),'');
      this.bff.updateBulkUploadLog(payLoad).subscribe(data =>{})
    }
  }

  saveErrorRecords() {
    let errorRecords = [];
    for (let i=0; i < this.bulkUploadTableData?.length; i++) {
      if (errors.hasOwnProperty(String(i)))
        errorRecords.push(this.rowData[i]);
    }
    let worksheet = XLSX.utils.json_to_sheet(errorRecords);
    let workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Upload Errors");
    XLSX.writeFile(workbook, 'bulk-upload-errors.xlsx');

  }

  countryCode(){
    let countryCode = []
    let countryDesc = []
    let countryDetails = []
    this.eventQuestionData.forEach(data=>{
      if(data.mappingField === 'preferredCountryCode'){
        data.options.forEach(ele=>{
          countryCode = [ele.option_value] 
          countryDesc = [ele.option_desc]
        })
      }
    })
    countryDetails.push(countryDesc)
    countryDetails.push(countryCode)
    return countryDetails
  }

  importErrorFreeRows(){
    this.showLoaderIcon = !this.showLoaderIcon
    let countryDetails = this.countryCode()
    let i = 0;
    let eventRegistrationPayload = []
    this.validDataArray = []
    this.tableRows.controls['formArrayName']['controls'].map(ele=>{
      let tmpObj = {}
      let data = this.tableRows.controls['formArrayName']['controls'][i].value
      if(this.tableRows.controls['formArrayName']['controls'][i].status === 'VALID'){
        this.validDataArray.push(i);
        tmpObj = {
          "modeOfRegistration": 'BULK UPLOAD',
          "firstName": data.first_name ? data.first_name.toString() : '',
          "lastName": data.last_name ? data.last_name.toString() : '',
          "mobileNumber": data.primary_mobile_number ? this.dialCodeInfo.optionKey + ' ' + data.primary_mobile_number.toString() : '',
          "email": data.primary_email ? data.primary_email : '',
          "preferredStudyDestination": data.preferredCountryCode ? data.preferredCountryCode : '',
          "preferredStudyDestinationCode": countryDetails[0].indexOf(data.preferredCountryCode) != -1 ? countryDetails[1][countryDetails[0].indexOf(data.preferredCountryCode)] : '',
          "preferredStudyLevel": data.preferredStudyLevel ? data.preferredStudyLevel : '',
          "howDidYouHearAboutIdpEvent" : data.howDidYouHear ? data.howDidYouHear : '', 
          "preferredCounsellingMode" : data.modeOfCounselling ? data.modeOfCounselling : '',
          "studyPlanMonthYear" : data.studyPlanDate ? data.studyPlanDate : '',
          "preferredSubject" : data.majorSubjects ? data.majorSubjects : '',
          "primaryFinancialSource": data.primaryFinancialSource ?  data.primaryFinancialSource : '',
          "highestEducation":data.highestEducation ? data.highestEducation : '',
          "nationality": data.nationality ? data.nationality : '',
          "nearestIdp" : data.nearestldpOffice ? data.nearestldpOffice : '',
          "tcAcceptance": data.termsAndConditionsAcceptance  == 'Yes' ? true : false,
          "contactMeBy" : data.contactMeBy == 'Yes' ?  true : false,
          "marketingAcceptance" : data['marketing_acceptance_flag.acceptPhoneCall, marketing_acceptance_flag.acceptEmail, marketing_acceptance_flag.acceptSms'] == 'Yes' ? true : false,
          "cventCode": this.eventDetails.cventCode,
          "correlationId": this.methods.correlationId(),
          "idpEventId": this.eventDetails.idpEventId,
          "cventAccountId": this.eventDetails.cventAccountId,
          "eventJoinNow" : data.eventParticipant == 'Yes' ? true : false,
          "confirmationEmailConsent": this.surveyResponse.emailConfirmation == 'No' ? 'No' : 'Yes'
        } 
      eventRegistrationPayload.push(tmpObj)
      }
      i++;
    })
    // inpayLoad.event
    this.bff.sendBulkUploadRegistration(eventRegistrationPayload).subscribe(async data=>{ 
      this.bulkUploadTableData.map((ele,index)=>{
        let data = this.tableRows.controls['formArrayName']['controls'][index].value;
        this.bulkUploadTableData[index] = data;
      })
      this.bulkUploadTableData = this.bulkUploadTableData.filter((value, index) => {
        return this.validDataArray.indexOf(index) == -1;
      })
      let i = 0;
      for(let ele of this.bulkUploadTableData){
        this.bulkUploadTableData[i].id = i;
        i++;
      }
      this.bulkUploadTableDataArray = this.bulkUploadTableData.slice(0,24);
      this.buildForm();
      this.showLoaderIcon = !this.showLoaderIcon
      const status = data['message'];
      const successCount = data['successCount']?.toString();
      const failureCount = data['failureCount']?.toString();
      this.importedDataCount = successCount;
      this.showImportedData = true;
      setTimeout(()=> {
        this.showImportedData = false;
        if(this.bulkUploadTableDataArray.length === 0){
          this.closeTable();
          this.bff.showbulkUploadTable.next(false);
        }
      },5000);
      const inPayLoad = this.bulkUploadLogDetails('Upload',status,successCount,failureCount);
      if(data['message']){
        this.bff.updateBulkUploadLog(inPayLoad).subscribe(data =>{})
      } 
    })
  }

  checkFormArray(){
    this.detailsFormArray.controls.forEach(x=>{
      (x as FormGroup).get('primary_email').updateValueAndValidity()
    })
  }

  get detailsFormArray() {
    return (this.tableRows.get("formArrayName") as FormArray)
  }

  checkIfUnique(index) {
    return (control: FormControl) => {
      //try get the form array
      const formArray = control.parent && control.parent.parent ? (control.parent.parent as FormArray) : null;
      if (formArray && formArray.controls?.length) {
        for (let i = index - 1; i >= 0; i--) {
          if ((formArray.at(i) as FormGroup).get("primary_email").value == control.value)
            return { errorRepeat: true };
        }
      }
    };
  }

  checkMobileNumber(i){
    return (control: FormControl) => {
          if (control.value?.toString().length < parseInt(this.dialCodeInfo.minLength)){
            return { errorRepeat: true };
          }
          if(control.value?.toString().length > parseInt(this.dialCodeInfo.maxLength)){
            return { errorRepeat: true };
          }
    };
  }

  checkMarkettingAcceptance(i){
    return (control: FormControl) => {
      let markettingAcceptArray = ['Yes','No']
          if (markettingAcceptArray.indexOf(control.value) == -1){
            return { errorRepeat: true };
          }
    };
  }

  checkSelect(options) {
    let availableOptions = [];
    options.forEach(value => availableOptions.push(value.option_desc))
    return (control: FormControl) => {
      if (availableOptions.indexOf(control.value) == -1) {
        return { errorRepeat: true };
      }
    }
  }
  
  phoneNumberArray(){
    this.phoneNumberFormArray.controls.forEach(x=>{
      (x as FormGroup).get('primary_email').updateValueAndValidity()
    })
  }

  get phoneNumberFormArray() {
    return (this.tableRows.get("formArrayName") as FormArray)
  }

  closeTable(){
    this.bff.excelFileObj.next({});
    this.buildForm();
    this.bff.showbulkUploadTable.next(false);
    this.bff.bulkUploadSurvey.next({});
    document.body.classList.remove('hide_event');
    window.removeEventListener('beforeunload', this.preventReload);
  }

  studentDetailsTracker(index, student){
    return student.id ? student.id : undefined;
  }
 bulkUploadLogDetails(flag,status,success,failure){
  let fileName =  sessionStorage.getItem('fileName_'+ sessionStorage.getItem('tabID'));
  let fileNameCoversion = fileName?.split('.')
  let newFileName = fileNameCoversion[0]
  let payload = {
    eventName: this.eventTitle,
    eventCode: this.cventCode,
    status: status,
    uploadedBy: this.uploadedBy,
    fileName: newFileName,
    bulkUploadFeatureReason: this.surveyResponse.options ? this.surveyResponse.options : [],
    importRegistrantsNotes: this.surveyResponse.notes ? this.surveyResponse.notes : '',
    confirmationEmailConsent: this.surveyResponse.emailConfirmation == 'No' ? 'No' : 'Yes',
    attributes: {
        uploadedDownloadedFlag: flag,
        reasonForUpload: "testing",
        deviceName: "",
        successCount:success,
        failureCount:failure
    }
  }
  return payload
 }

  getErrorData() {
    let errorRecordManipulation = []
    let i = 0
    this.tableRows.controls['formArrayName']['controls'].map(data => {
      if (data.status === 'INVALID') {
        let tmpObj = this.bulkUploadTableData[i];
        errorRecordManipulation.push(tmpObj)
      }
      i++
    });
    return errorRecordManipulation;
  }

  preventReload(event) {
    event.preventDefault();
    event.returnValue = '';
    return event;
  }

  ngOnDestroy(): void {
    this.closeTable();
  }

}