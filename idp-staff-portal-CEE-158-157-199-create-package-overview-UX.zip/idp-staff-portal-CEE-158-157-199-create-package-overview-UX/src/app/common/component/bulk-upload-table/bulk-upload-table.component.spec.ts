import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';
import { BulkUploadTableComponent } from './bulk-upload-table.component';

describe('BulkUploadTableComponent', () => {
  let component: BulkUploadTableComponent;
  let fixture: ComponentFixture<BulkUploadTableComponent>;
  let service: BffService;
  const showTable:boolean= true
  const fileName = [{name:'bulkUpload'}];
  const eventTitle = [{title:'VE Dev'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadTableComponent ],
      imports: [HttpClientModule,RouterTestingModule.withRoutes([])],
      providers: [BffService,FormBuilder,
        { provide: CommonMethods, useClass: class {} },
        
      ]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkUploadTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.showTable = showTable;
    component.fileName = fileName;
    component.eventTitle = eventTitle
    
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.showTable).not.toBeUndefined();
    expect(component.fileName).not.toBeUndefined();
    expect(component.eventTitle).not.toBeUndefined();
  })
});
