import { Component, OnInit } from '@angular/core';
import { ChartConfiguration,ChartOptions} from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-register-participant',
  templateUrl: './reports-register-participant.component.html',
  styleUrls: ['./reports-register-participant.component.css']
})
export class ReportsRegisterParticipantComponent implements OnInit {

  registrantParticipantData:any;
  isDataLoaded:boolean = false;
  scrWidth =  window.innerWidth
  registrantCount:any;
  participantCount:any;
  participantPercentage:any;
  registrantPercentage:any;
  registerParticipantCount = [];
  public barChartOptions3: ChartOptions

  constructor(private bff : BffService, private methods : CommonMethods) {}
  
  ngOnInit(): void {
    this.getRegistrantParticipantDetails();
  }

  getRegistrantParticipantDetails(){
      this.bff.reportsRegisterParticipant.subscribe(data =>{
        this.registrantCount = data['noOfRegistration'];
        this.participantCount = data['noOfParticipant']; 
        this.participantPercentage = Math.round((this.participantCount/(this.registrantCount)) * 100);
        this.registrantPercentage = 100 - this.participantPercentage;
        this.registerParticipantCount = [];
        this.registerParticipantCount.push(this.registrantCount,this.participantCount)
        this.isDataLoaded = true;
        this.barChartData3= { 
          labels: ['Registrants','Participants'],
          datasets: [
            { data: this.registerParticipantCount, backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df',barThickness:90}
          ]
        };
        this.barChartOptions3 = this.methods.barChartObject('chartjs-tooltip7',this.registerParticipantCount,'vertical')
      })  
  }

  public barChartData3: ChartConfiguration['data'] = {
    labels: ['Registrants','Participants'],
    datasets: [
      { data: this.registerParticipantCount, backgroundColor: '#008260',hoverBackgroundColor:'#007556'}
    ]
  };
  
}
