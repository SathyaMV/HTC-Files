import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReportsRegisterParticipantComponent } from './reports-register-participant.component';

describe('ReportsRegisterParticipantComponent', () => {
  let component: ReportsRegisterParticipantComponent;
  let fixture: ComponentFixture<ReportsRegisterParticipantComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsRegisterParticipantComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService)
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsRegisterParticipantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
