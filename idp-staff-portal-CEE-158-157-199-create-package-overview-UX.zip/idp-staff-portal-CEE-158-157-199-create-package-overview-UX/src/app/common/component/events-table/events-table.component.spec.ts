import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxPaginationModule } from 'ngx-pagination'
import { EventsTableComponent } from './events-table.component';

describe('EventsTableComponent', () => {
  let component: EventsTableComponent;
  let fixture: ComponentFixture<EventsTableComponent>;
  const dummyData = [{test:'testname'}];
  const upcomingEvents = [{event : 'virtual'}]
  const pastEvents = [{event : 'webinar'}]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventsTableComponent ],
      imports: [RouterTestingModule,
        MatAutocompleteModule,
        MatSelectModule,
        MatDatepickerModule,
        MatNativeDateModule,
        ReactiveFormsModule,
        FormsModule,
        MatTabsModule,
        NgxPaginationModule,
        NoopAnimationsModule,
        MatInputModule]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventsTableComponent);
    component = fixture.componentInstance;
    component.eventListPageData = dummyData;
    component.upcomingEventsData = upcomingEvents;
    component.pastEventsData = pastEvents;
    component.searchmyControl.setValue('vir');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have data',()=>{
    expect(component.eventListPageData).not.toBeUndefined();
  })

  it('should have data in upcoming events',()=>{
    expect(component.upcomingEventsData).not.toBeUndefined();
  })

  it('should have data in past events',()=>{
    expect(component.pastEventsData).not.toBeUndefined();
  })

  it('Filter Button name is apply',()=>{
    expect(component.filterBtnLabel).toEqual('Apply');
  })

 describe('filter form',()=>{
    it('should create a form',()=>{
      expect(component.range).not.toBeUndefined();
    });
    describe('form fields',()=>{
      it('should create 2 of that',()=>{
        const fields = Object.keys(component.range.controls);
        expect(fields?.length).toBe(2);
      })
    })
  });
  describe('search form with value event name',()=>{
    it('should bind the configured value', async(() => {
      expect(component.searchType).toBe('eventName');
    })); 
    it('should search value',()=>{
      fixture.whenStable().then(() => {
        expect(component.searchmyControl).toBe('vir');
        expect(component.searchmyControl.value.length).not.toBeLessThan(3);
      });
    });
  }) 
});
