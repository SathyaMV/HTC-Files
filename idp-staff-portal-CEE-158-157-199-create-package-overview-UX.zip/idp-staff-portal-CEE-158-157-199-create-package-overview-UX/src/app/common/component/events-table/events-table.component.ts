import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-events-table',
  templateUrl: './events-table.component.html',
  styleUrls: ['./events-table.component.css']
})

export class EventsTableComponent implements OnInit {
  upcomingEventsData;
  pastEventsData;
  @Input() eventListPageData;
  showExtraClass = true;
  show = false;
  check: boolean = false;
  univshow = false;
  myControl = new FormControl('');
  searchtype = new FormControl('eventName');
  searchmyControl = new FormControl('');
  officeList: any
  filteredOptions!: Observable<string[]>;
  filteredSearchOptions: any;
  upcomingPageNumber = 1;
  pastPageNumber = 1;
  p = 0;
  resultCount = 0;
  selectedDestination = [];
  selectedEventType = [];
  filterMatchedData = [];
  selectedOfficeList = [];
  fromDate = null;
  toDate = null;
  searchEvent;
  filterCount = 0
  appliedFilter: number = 0;
  destinationFilter;
  eventTypeFilter;
  range = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });
  searchType = 'eventName';
  searchValue;
  searchValueBoolean:boolean = true;
  eventTitleList = [];
  eventCodeList = [];
  filterUpcomingData = [];
  filterPastData = [];
  liveEventsData = []
  totalRecordsUpcoming;
  totalRecordsPast;
  recordsViewedUpcoming;
  recordsViewedPast;
  itemsPerPage: number = 10;
  filterBtnLabel: string = 'Apply';
  upcomingSelectedIndex = null;
  pastSelectedIndex = null;
  upcomingContainer: ElementRef;
  pastContainer: ElementRef;
  appliedDestination = [];
  appliedEventType = [];
  appliedFromDate = null;
  appliedToDate = null;
  appliedOfficeList = [];
  isSimEnable:boolean = false //Handles on enabling Create event button or not

  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger: MatAutocompleteTrigger;
  

  constructor(private router:Router, @Inject(DOCUMENT) private document: Document){
     this.document.addEventListener('click', this.offClickHandler.bind(this));
  }

  offClickHandler(event: any) {
    if (this.upcomingContainer != undefined && !this.upcomingContainer.nativeElement.contains(event.target)) {
      this.upcomingSelectedIndex = null;
    }
    if (this.pastContainer != undefined && !this.pastContainer.nativeElement.contains(event.target)) {
      this.pastSelectedIndex = null
    }

  }
  @ViewChild('upcomingPopup', { static: false }) set upcomingEventPopup(upcomingEventPopup: ElementRef) {
    if (upcomingEventPopup) { // initially setter gets called with undefined
      this.upcomingContainer = upcomingEventPopup;
    }
  }

  @ViewChild('pastPopup', { static: false }) set pastEventPopup(pastEventPopup: ElementRef) {
    if (pastEventPopup) { // initially setter gets called with undefined
      this.pastContainer = pastEventPopup;
    }
  }

  ngOnInit(): void {
    this.upcomingEventsData = this.eventListPageData?.idpEvents?.upcoming; 
    this.pastEventsData = this.eventListPageData?.idpEvents?.past;
    this.resultCount = this.upcomingEventsData?.length || 0 + this.pastEventsData?.length || 0;
    this.totalRecordsUpcoming = this.upcomingEventsData?.length || 0;
    this.totalRecordsPast = this.pastEventsData?.length || 0;
    this.recordsViewedUpcoming = this.totalRecordsUpcoming < 10 ? this.totalRecordsUpcoming : 10;
    this.recordsViewedPast = this.totalRecordsPast < 10 ? this.totalRecordsUpcoming : 10;

    this.filteredSearchOptions = this.searchmyControl.valueChanges.pipe(
      startWith(''),map(value => this._filter(value || '') ),
    );

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),map(value => this._filterMyControl(value || '') ),
    );

    this.getOfficeList();
    //Simplified event
    this.isSimEnable = Boolean(environment.isSimEnable)
  }
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    let dropDownList = []

    if(this.searchType == 'eventName'){
      if(filterValue?.length >=3){   
        dropDownList = this.eventTitleList.filter(ele=>{
          if(ele.toLowerCase().includes(filterValue.trim().toLowerCase())){
            return ele
          }
        })
        this.filter('search',filterValue);
        this.applyFilter();
      }else{
        this.filter('search','');
        this.applyFilter();
      }
      return dropDownList
    }

    if(this.searchType == 'eventCode'){
      if(filterValue?.length >=3){
        dropDownList = this.eventCodeList.filter(ele=>{
          if(ele.toLowerCase().includes(filterValue.trim().toLowerCase())){
            return ele
          }
        })
        this.filter('search',filterValue);
        this.applyFilter();
      }else{
        this.filter('search','');
        this.applyFilter();
      }
      return dropDownList
    }
  }

  private _filterMyControl(value: string): string[] {
    const filterValue = value.toLowerCase();
    let officeCodeList = []
    this.officeList.filter(ele => {
      if (ele.toLowerCase().includes(filterValue)) {
        officeCodeList.push(ele.trim())
      }
    })
    return officeCodeList
  }

  eventSerchTypeDropDown(value){
    this.searchType = value
     this.searchmyControl.setValue('')
     this.filter('search','');
     this.applyFilter();
  }

  openFilter() {
    if (!this.check) {
      this.check = true;
      document.body.classList.add('hide_body');
    } else {
      this.removeSelectedFilters();
      this.check = false;
      document.body.classList.remove('hide_body');
    }
  }

  filter(filterType, filterValue) {
    switch (filterType) {
      case 'destination': {
        filterValue.checked = !filterValue.checked
        this.selectedDestination = this.eventListPageData.destinationFilter.map(ele => {
          if (ele['checked']) {
            return ele.name
          }
        }).filter(tmp => { return tmp != undefined })
        break;
      }
      case 'eventType': {
        filterValue.checked = !filterValue.checked
        this.selectedEventType = this.eventListPageData.eventTypeFilter.map(ele => {
          if (ele['checked']) {
            return ele.name
          }
        }).filter(tmp => { return tmp != undefined })
        //statements; 
        break;
      }
      case 'fromDate' : {
        this.fromDate = this.range.controls.start.value
        break;
      }
      case 'toDate':{
        this.toDate = this.range.controls.end.value
        break;
      }
      case 'search': {
        // this.searchEvent = filterValue.toLowerCase()
        this.searchEvent = this.searchmyControl.value.length >=3 ? this.searchmyControl.value.toLowerCase() : '';
        break;
      }
      default: {
        //statements; 
        break;
      }
    }
    this.filterSelectedData(this.selectedDestination, this.selectedEventType, this.fromDate, this.toDate, this.searchEvent, this.selectedOfficeList)
  }


  filterSelectedData(selectedDestination, selectedEventType, fromDate, toDate, searchEvent, selectedOfficeList) {
    let filterSelectedData;
    if(toDate) {
      toDate = new Date(toDate)
      toDate.setHours(23,59,59)
    }
    this.filterCount = 0;
    this.filterMatchedData = [];
    this.filterPastData = [];
    this.filterUpcomingData = [];
    this.eventListPageData?.idpEvents?.upcoming?.map(ele => {
      if (this.filterCondition(ele,selectedDestination, selectedEventType, fromDate, toDate, searchEvent, selectedOfficeList)) {
        this.filterUpcomingData.push(ele)
      }
    }).filter(tmp => { return tmp != undefined })

    this.eventListPageData?.idpEvents?.past?.map(ele => {
      if (this.filterCondition(ele,selectedDestination, selectedEventType, fromDate, toDate, searchEvent, selectedOfficeList)) {
        this.filterPastData.push(ele)
      }
    }).filter(tmp => { return tmp != undefined })
    this.resultCount = this.filterUpcomingData?.length + this.filterPastData?.length
    if(selectedDestination?.length > 0) this.filterCount++
    if(selectedEventType?.length > 0) this.filterCount++
    if(fromDate != null || toDate != null) this.filterCount++
    if(selectedOfficeList?.length > 0) this.filterCount++    
  }

  filterCondition(ele, selectedDestination, selectedEventType, fromDate, toDate, searchEvent, selectedOfficeList) {
    let condition = 'true'
    if (selectedEventType?.length > 0) condition += ' && ' + String(selectedEventType.indexOf(ele.idpEventType) != -1);
    if (fromDate != null) condition += ' && ' + String(new Date(fromDate) <= new Date(ele.startDate))
    if (toDate != null) condition += ' && ' + String(new Date(toDate) >= new Date(ele.endDate))
    if (searchEvent && this.searchType == 'eventName') condition += ' && ' + String(ele.idpEventName.toLowerCase().includes(searchEvent))
    if (searchEvent && this.searchType == 'eventCode') condition += ' && ' + String(ele.cventEventId.toLowerCase().includes(searchEvent))
    if (selectedOfficeList?.length > 0) condition += ' && ' + String(ele.office.split(", ").filter(x => selectedOfficeList.includes(x)).length > 0)
    if (selectedDestination?.length > 0) condition += ' && ' + String(ele.destination.split(", ").filter(x => selectedDestination.includes(x)).length > 0);
    return condition.includes('false') ? false : true 
  }

  getOfficeList() {
    let offieArray = []

    this.upcomingEventsData?.map(ele => {
      if (ele.office.includes(',')) {
        ele.office.split(',').filter(officeEle => {
          offieArray.push(officeEle.trim())
        })
      } else {
        offieArray.push(ele.office.trim())
      }
      this.eventTitleList.push(ele.idpEventName)
      this.eventCodeList.push(ele.cventEventId)
    })

    this.pastEventsData?.map(ele => {
      if (ele.office.includes(',')) {
        ele.office.split(',').filter(officeEle => {
          offieArray.push(officeEle.trim())
        })
      } else {
        offieArray.push(ele.office.trim())
      }
      this.eventTitleList.push(ele.idpEventName)
      this.eventCodeList.push(ele.cventEventId)
    })
    this.officeList = [...new Set(offieArray)]
  }

  OfficeSelection(event) {
    if(this.selectedOfficeList && this.selectedOfficeList.indexOf(event.option.value)){
      this.selectedOfficeList.push(event.option.value)
    }
    this.myControl.setValue('');
    this.filter('officeId',this.selectedOfficeList);
  }

  removeSelectedOffice(office){
    this.selectedOfficeList.splice(this.selectedOfficeList.indexOf(office),1);
    this.filter('officeId','') 
  }

  searchSelection(event){
    this.searchValue = event.option.value;
    this.searchValueBoolean = !this.searchValueBoolean
    this.filter('search',event.option.value);
    this.applyFilter();
  }

  searchEnter(event){
    this.searchValue = this.searchmyControl.value;
    this.searchValueBoolean = !this.searchValueBoolean
    this.filter('search','');
    this.applyFilter();
    this.autocompleteTrigger.closePanel();
  }

  removeSearch(){
    this.searchValueBoolean = !this.searchValueBoolean
    this.searchmyControl.setValue('');
    if(this.searchValue != ''){
      this.searchValue = '';
    }
    this.filter('search','');
    this.applyFilter();
  }

  destination(value){
    let country = this.eventListPageData.destinationFilter.map(ele=>{return ele.name})
    let countryCode = this.eventListPageData.destinationFilter.map(ele=>{return ele.code})
    let finalDestinationCodeArray = []
    if(value.includes(',')){
      value.split(',').map( ele =>{
        let index = country.indexOf(ele.trim())
        if(index != -1){
          finalDestinationCodeArray.push(countryCode[index])
        }
      })
    }else{
      let index = country.indexOf(value)
      if(index != -1){
        finalDestinationCodeArray.push(countryCode[index])
      }
    }
    return finalDestinationCodeArray;
  } 

  applyFilter() {
    this.appliedFilter = this.filterCount;
    this.pastPageNumber = 1;
    this.upcomingPageNumber = 1;
    this.getAppliedFilters();
    this.check = false;
    document.body.classList.remove('hide_body');
    let search = this.searchValue ? this.searchValue : 'true'
    if (this.filterCount > 0 || search) {
      this.upcomingEventsData = [];
      this.pastEventsData = [];
      if(this.filterUpcomingData?.length > 0) {
        this.upcomingEventsData = this.filterUpcomingData;
      }
      if(this.filterPastData?.length > 0){
        this.pastEventsData = this.filterPastData;
      }
    }
  }

  getAppliedFilters() {
    this.appliedDestination = this.selectedDestination;
    this.appliedEventType = this.selectedEventType;
    this.appliedFromDate = this.fromDate;
    this.appliedToDate = this.toDate;
    this.appliedOfficeList = this.selectedOfficeList.slice(0);
  }

  removeSelectedFilters() {
    this.eventListPageData.destinationFilter.map(ele => {
      ele.checked = (this.appliedDestination.indexOf(ele.name) >= 0)
    })
    this.eventListPageData.eventTypeFilter.map(ele => {
      ele.checked = (this.appliedEventType.indexOf(ele.name) >= 0)
    })
    this.range.controls.start.setValue(this.appliedFromDate);
    this.range.controls.end.setValue(this.appliedToDate);
    this.selectedOfficeList = [];
    this.selectedOfficeList = this.appliedOfficeList.slice(0);

    this.filterSelectedData(this.appliedDestination, this.appliedEventType, this.appliedFromDate, this.appliedToDate, this.searchEvent, this.appliedOfficeList);
  }

  eventOverViewPage(eventCode,startDate,endDate,eventId){ 
    sessionStorage.setItem('startDate_'+sessionStorage.getItem('tabID'),startDate)
    sessionStorage.setItem('endDate_'+sessionStorage.getItem('tabID'),endDate)
    const startValues = startDate.split(/[^0-9]/);
    const startyear = parseInt(startValues[0], 10);
    const startmonth = parseInt(startValues[1], 10) - 1;
    const startday = parseInt(startValues[2], 10);
    const starthours = parseInt(startValues[3], 10)
    const startminutes = parseInt(startValues[4], 10)
    const startseconds = parseInt(startValues[5], 10)
    const formattedStartDate = new Date(startyear, startmonth, startday, starthours, startminutes, startseconds);
    const endValues = endDate.split(/[^0-9]/);
    const endYear = parseInt(endValues[0], 10);
    const endMonth = parseInt(endValues[1], 10) - 1;
    const endDay = parseInt(endValues[2], 10);
    const endHours = parseInt(endValues[3], 10)
    const endMinutes = parseInt(endValues[4], 10)
    const endSeconds = parseInt(endValues[5], 10)
    const formattedEndDate = new Date(endYear, endMonth, endDay, endHours, endMinutes, endSeconds);
    let liveEvent = new Date() > formattedStartDate  && new Date() < formattedEndDate;
    let pastEvent = new Date() > formattedEndDate;
    let futureEvent = new Date < formattedStartDate;
    sessionStorage.setItem('isLiveEvent_'+sessionStorage.getItem('tabID'),JSON.stringify(liveEvent));
    sessionStorage.setItem('futureEvent_' +sessionStorage.getItem('tabID'),JSON.stringify(futureEvent));
    sessionStorage.setItem('pastEvent_' +sessionStorage.getItem('tabID'),JSON.stringify(pastEvent));
    sessionStorage.setItem('idpEventId_' +sessionStorage.getItem('tabID'),eventId)
    this.router.navigateByUrl('idp-staff-portal/events-overview'+ '?eventCode=' + eventCode);
  }

  pastViewCount(count, value) {
    this.recordsViewedPast = count * 10
    if (this.recordsViewedPast > value) {
      this.recordsViewedPast = value;
    } 
  }

  upcomingViewCount(count,value){
    this.recordsViewedUpcoming = count * 10
    if(this.recordsViewedUpcoming > value){
      this.recordsViewedUpcoming = value
    }
  }

  officeFilterClear(){
    this.selectedOfficeList = [];
    this.filter('officeId','')
  }

  clearAllFilter(){
    this.eventListPageData.destinationFilter.map(ele=>{
      ele['checked'] = false;
    })
    this.selectedDestination = [];
    this.selectedOfficeList = [];
    this.selectedEventType = [];
    this.eventListPageData.eventTypeFilter.map(ele=>{
      ele['checked'] = false;
    })
    this.range.controls.start.setValue('');
    this.range.controls.end.setValue('');
    this.fromDate = null;
    this.toDate = null;
    this.filter('','')
  }

  scrollTop(tab) {
    if(tab === 'upcoming'){
      document.getElementById('listTopUpcoming').scrollIntoView({ behavior: "smooth" });
    }else{
      document.getElementById('listTopPast').scrollIntoView({ behavior: "smooth" }); 
    }
  }

  getPagination(pageNumber, len) {
    let startValue = ((pageNumber-1)*this.itemsPerPage)+1;
    let endValue = pageNumber*this.itemsPerPage > len ? len : pageNumber*this.itemsPerPage;
    return `Showing ${startValue} to ${endValue} of ${len}`
  }

  upcomingEventScanningApp(index,startDate){
    const startValues = startDate.split(/[^0-9]/);
    const startyear = parseInt(startValues[0], 10);
    const startmonth = parseInt(startValues[1], 10) - 1;
    const startday = parseInt(startValues[2], 10);
    const starthours = parseInt(startValues[3], 10) - 2
    const startminutes = parseInt(startValues[4], 10)
    const startseconds = parseInt(startValues[5], 10)
    const formattedStartDate = new Date(startyear, startmonth, startday, starthours, startminutes, startseconds);
    const hideScanningApp = new Date < formattedStartDate;
    if (this.upcomingSelectedIndex !== index && !hideScanningApp) {
      this.upcomingSelectedIndex = index;
    } else {
      this.upcomingSelectedIndex = null;
    }
  }

  checkInApp(eventCode,index,startDate,endDate,eventCountry,idpEventId){
    const idpEventCountry = eventCountry.split('-')[1].trimStart();
    const checkInAppUrl = environment.checkInUrl+eventCode+'?'+'role='+ "idpUser"+'&eventStartDate='+startDate+'&eventEndDate='+endDate+'&country='+idpEventCountry+'&id='+idpEventId;
    window.open(checkInAppUrl);
    this.upcomingSelectedIndex = null;
  }

  pastEventScanningApp(index){
    if (this.pastSelectedIndex !== index) {
      this.pastSelectedIndex = index;
    } else {
      this.pastSelectedIndex = null;
    }
  }

  pastEventCheckInApp(eventCode,index,startDate,endDate,eventCountry,idpEventId){
    const idpEventCountry = eventCountry.split('-')[1].trimStart();
    const pastEventCheckInAppUrl = environment.checkInUrl+eventCode+'?'+'role='+ "idpUser"+'&eventStartDate='+startDate+'&eventEndDate='+endDate+'&country='+idpEventCountry+'&id='+idpEventId;
    window.open(pastEventCheckInAppUrl);
    this.pastSelectedIndex = null;
  }  
}