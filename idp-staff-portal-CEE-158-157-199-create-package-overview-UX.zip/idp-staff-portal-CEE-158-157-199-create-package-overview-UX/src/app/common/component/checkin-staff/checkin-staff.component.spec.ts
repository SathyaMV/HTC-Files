import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckinStaffComponent } from './checkin-staff.component';

describe('CheckinStaffComponent', () => {
  let component: CheckinStaffComponent;
  let fixture: ComponentFixture<CheckinStaffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckinStaffComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckinStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
