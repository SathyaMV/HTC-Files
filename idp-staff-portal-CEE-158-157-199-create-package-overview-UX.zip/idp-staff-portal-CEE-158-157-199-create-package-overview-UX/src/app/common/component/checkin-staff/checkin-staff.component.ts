import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import {Observable} from 'rxjs';
import { BffService } from 'src/app/providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-checkin-staff',
  templateUrl: './checkin-staff.component.html',
  styleUrls: ['./checkin-staff.component.css']
})
export class CheckinStaffComponent implements OnInit {
  myControl = new FormControl('');
  checkinPopup:boolean = false;
  successPopup:boolean = false;
  filteredOptions!: Observable<string[]>;
  labelValue:any;
  staffListData:any = [];
  userStaffPage:any;
  staffCount:any;
  staffStartCount:any;
  staffLastCount:any;
  staffData:any;
  filterMetadata: any = { count: 0 };
  searchData: any = '';
  staffDefaultOption = 'Email';
  staffSearchLastCount: any;
  isUpcomingLiveEvent:boolean;
  LiveEvent : any =  sessionStorage.getItem('isLiveEvent_'+sessionStorage.getItem('tabID'));
  futureEvent : any = sessionStorage.getItem('futureEvent_'+sessionStorage.getItem('tabID'));
  isLiveEvent;
  isFutureEvent;
  canAddGuestUser:boolean = false

  constructor(private bff: BffService,public method: CommonMethods) { }

  ngOnInit(): void {
    this.getStaffDetails();
    this.getStaffSearchLabel(this.staffDefaultOption);
    
    //Check perimission

    this.bff.userPermission.subscribe(data=>{
      this.canAddGuestUser = data['userAccess'].canAddGuestUser
    })
  }

  closePopup(){
    this.successPopup = !this.successPopup
  }

  inviteStaff(e:any){
    this.checkinPopup = false;
  }

  staffDetails(value:any){
    this.getStaffDetails();  
    this.staffListData?.push(value);
    if(value){
      this.successPopup = true;
      setTimeout(() => {
        this.successPopup = false;
      }, 3000);
    }

  }

  onChangeStaff(e) { 
    if (e.length > 2) {
      this.userStaffPage = 1;
      this.staffStartCount = 1;
      this.staffSearchLastCount = 10
      if (this.staffCount <= 10) {
        this.staffLastCount = this.staffCount;
      } else {
        this.staffLastCount = 10;
      }
    }
  }

  getStaffDetails(){
    const eventId =  sessionStorage.getItem('idpEventId_'+ sessionStorage.getItem('tabID'));
    this.bff.getStaffDetails(eventId).subscribe(data =>{
      if(data){  
        this.staffListData = data?.response;
        this.staffCount = this.staffListData?.length;
        if (this.staffCount <= 10) {
          this.staffLastCount = this.staffCount;
        } else {
          this.staffLastCount = 10;
        }
        this.staffStartCount = 1;  
      }
      else{
        this.staffListData = '';
      }
    })
    this.isLiveEvent = this.LiveEvent?.includes(true)  
    this.isFutureEvent = this.futureEvent?.includes(true)
  }
//This method is used to get staff search filter dropdown value
  getStaffSearchLabel(value){
    this.labelValue = value;
  }

  staffListCount(count ,value){
    this.staffStartCount = count
    this.staffStartCount = this.staffStartCount * 10 - 9;
    this.staffLastCount = count * 10;
    if (this.staffLastCount > value) {
      this.staffLastCount = value;
    }
  }

  staffSearchListCount(count, value){
    this.staffSearchLastCount = count * 10;
    if (this.staffSearchLastCount > value) {
      this.staffSearchLastCount = value
    }
  }

  addStaff(){
    if(!this.checkinPopup){
      this.checkinPopup = true;
    }
  }

  scrollTop(tab) {
    if (tab === 'staffPage') {
      document.getElementById('staffPage').scrollIntoView({ behavior: "smooth" });
    } 
  }
}