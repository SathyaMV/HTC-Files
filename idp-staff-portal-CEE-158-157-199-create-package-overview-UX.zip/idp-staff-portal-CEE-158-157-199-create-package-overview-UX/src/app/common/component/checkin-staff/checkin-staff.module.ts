import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxPaginationModule } from 'ngx-pagination';
import { StaffDetailSearchPipe } from '../../pipe/staff-search.pipe';
import { AddStaffModule } from '../add-staff/add-staff.module';
import { CheckinStaffComponent } from './checkin-staff.component';



@NgModule({
    declarations: [CheckinStaffComponent,
                   StaffDetailSearchPipe],
    imports:[CommonModule,
             AddStaffModule,
             MatFormFieldModule,
             MatSelectModule,
             MatInputModule,
             MatAutocompleteModule,
             FormsModule,
             ReactiveFormsModule,
             MatButtonModule,
             NgxPaginationModule,
            ],
    exports:[
        CheckinStaffComponent,
        StaffDetailSearchPipe
    ]
})

export class CheckInStaffModule{}