import { NgModule } from "@angular/core";
import { ReportsPreferredStudyLevelComponent } from "./reports-preferred-study-level.component";
import { NgChartsModule } from 'ng2-charts'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatOptionModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from "@angular/common";



@NgModule({
    declarations: [ReportsPreferredStudyLevelComponent],
    imports:[NgChartsModule,
        MatFormFieldModule,
        MatOptionModule,
        MatSelectModule,
        CommonModule],
    exports:[
        ReportsPreferredStudyLevelComponent
    ]
})

export class PreferredStudyLevelModule{}