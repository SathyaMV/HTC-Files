import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BffService } from '../../../providers/bff.service';
import { ReportsPreferredStudyLevelComponent } from './reports-preferred-study-level.component';

describe('ReportsPreferredStudyLevelComponent', () => {
  let component: ReportsPreferredStudyLevelComponent;
  let fixture: ComponentFixture<ReportsPreferredStudyLevelComponent>;
  let service: BffService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsPreferredStudyLevelComponent ],
      imports: [HttpClientModule],
      providers: [BffService]
    })
    .compileComponents();
    service = TestBed.inject(BffService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsPreferredStudyLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
