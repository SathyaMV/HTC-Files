import { Component, OnInit } from '@angular/core';
import { ChartConfiguration,ChartOptions } from 'chart.js';
import { BffService } from '../../../providers/bff.service';
import { CommonMethods } from '../../utilities/common-methods';

@Component({
  selector: 'app-reports-preferred-study-level',
  templateUrl: './reports-preferred-study-level.component.html',
  styleUrls: ['./reports-preferred-study-level.component.css']
})
export class ReportsPreferredStudyLevelComponent implements OnInit {
  preferredStudyLevel:any;
  preferredStudyLevelLabel=[];
  preferredStudyLevelData=[];
  scrWidth = window.innerWidth;
  isLoaded = false;
  totalRegistrationCount:any;
  barThickness : any
  testArray = [];
  public barChartOptions5: ChartOptions

  constructor(private bff : BffService, private methods : CommonMethods) {
  }

  ngOnInit(): void {
    this.getHdyhDetails();
  }

  getHdyhDetails(){
    setTimeout(() => {
      this.bff.preferredStudyLevel.subscribe((data)=>{
        this.preferredStudyLevel = data['preferredStudyLevel']; 
        let totalRegistrationCount= data['totalRegistrationCount'];
        this.preferredStudyLevelLabel = [];
        this.preferredStudyLevelData = [];
          if(this.preferredStudyLevel?.length > 0){
            this.testArray = [];
            this.preferredStudyLevel.filter(ele => {
              this.testArray.forEach((itm: any) => itm.optionKey === ele.optionKey ?  itm.optionValue = ele.optionValue + itm.optionValue : ele.optionValue)
            if(!this.testArray.find((itm: any) => itm.optionKey === ele.optionKey)){
              this.testArray.push(ele); 
            }});
            this.preferredStudyLevel =  this.testArray.sort((a, b) => a.optionSequence- b.optionSequence);
            this.testArray.forEach((e)=>{
              e.percent = Math.round((e.optionValue/totalRegistrationCount) * 100);
              let strLength;
              if(this.scrWidth <= 768){
                strLength = e.optionKey.length > 17 ? e.optionKey.substring(0,17)+'...' : e.optionKey;
              }else{
                strLength = e.optionKey;
              }
              this.preferredStudyLevelLabel.push(strLength);
              this.preferredStudyLevelData.push(e.optionValue);  
            })
            this.isLoaded = true; 
            if(this.preferredStudyLevelData?.length < 5){
              this.barThickness = 24
            }else {
              this.barThickness = 12;
            }
            this.barChartData5= {
              labels: this.preferredStudyLevelLabel,
              datasets: [
                { data : this.preferredStudyLevelData , backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df',barThickness:this.barThickness}
              ]
            };   

          }
          this.barChartOptions5= this.methods.barChartObject('chartjs-tooltip5',this.preferredStudyLevelData,'vertical')
      });
    }, 1000);
  }

  public barChartData5: ChartConfiguration<'bar'>['data'] = {
    labels: this.preferredStudyLevelLabel,
    datasets: [
      { data : this.preferredStudyLevelData , backgroundColor: '#0086F8',hoverBackgroundColor:'#0077df',barThickness:12}
    ]
  };
}
