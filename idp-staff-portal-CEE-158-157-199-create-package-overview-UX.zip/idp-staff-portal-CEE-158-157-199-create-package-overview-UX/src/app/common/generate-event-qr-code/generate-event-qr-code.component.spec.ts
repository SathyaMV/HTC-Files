import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateEventQrCodeComponent } from './generate-event-qr-code.component';

describe('GenerateEventQrCodeComponent', () => {
  let component: GenerateEventQrCodeComponent;
  let fixture: ComponentFixture<GenerateEventQrCodeComponent>;
  const eventTitle = [{eventName:'VE-DEV'}];
  const eventUrl = [{eventUrl:'www.test.com'}];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [ GenerateEventQrCodeComponent ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(GenerateEventQrCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.eventTitle = eventTitle;
    component.eventUrl = eventUrl;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have data',()=>{
    expect(component.eventTitle).not.toBeUndefined();
    expect(component.eventUrl).not.toBeUndefined();
  })
});
