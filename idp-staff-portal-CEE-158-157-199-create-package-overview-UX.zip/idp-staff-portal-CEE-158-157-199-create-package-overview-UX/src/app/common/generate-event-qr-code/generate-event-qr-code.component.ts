import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { BffService } from '../../providers/bff.service';

@Component({
  selector: 'app-generate-event-qr-code',
  templateUrl: './generate-event-qr-code.component.html',
  styleUrls: ['./generate-event-qr-code.component.css']
})
export class GenerateEventQrCodeComponent implements OnInit {

  @Input() eventUrl;
  @Input() eventTitle;
  allEventsUrl = "idp-staff-portal/events-dashboard";
  qrCheck:boolean = false;
  @ViewChild("printContent") myPrintDiv: ElementRef;


  constructor(private bff:BffService) { }

  ngOnInit(): void {
    this.bff.showEventQrCode.subscribe(data=>{
      this.qrCheck = data ? true : false;
      if(this.qrCheck){
        document.body.classList.add('hide_body');
      }else{
        document.body.classList.remove('hide_body');
      }
    })
  }

  qrPopup() {
    this.bff.showEventQrCode.next(false)
  }
  
  delay(n){
    return new Promise(function(resolve){
        setTimeout(resolve,n*1000);
    });
  }

  async printQr() {
    let divContents = this.myPrintDiv.nativeElement.innerHTML;
    let w:Window = window.open('', '', 'height=1000, width=800');
    w.document.write('<html>');
    //w.document.write('<body onLoad="window.print()');
    // w.document.write('<link rel="stylesheet" href="./generate-event-qr-code.component.css" type="text/css" />');
    w.document.write('<body>')
    w.document.write(divContents);
    w.document.write('</body></html>');
    w.document.close();
    await this.delay(1);
    w.print();
  }
}
