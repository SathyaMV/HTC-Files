import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'studentSearch',
    pure: false
  })

  export class studentDetailSearchPipe implements PipeTransform {
    searchResult:any=[];
    filteredItems=[]
    transform(studentDetails:any=[],searchTerms:any,labelValue:any,filterMetadata: any) {   
        if (!searchTerms) {
            return studentDetails;
          }if(searchTerms.length >= 3){
             this.filteredItems = studentDetails.filter(value =>{ 
                if(labelValue == 'Email'&& searchTerms.length >= 3){
                    return value.emailId.toLocaleLowerCase().includes(searchTerms.toLocaleLowerCase());
                }else if(labelValue == 'Name' && searchTerms.length >= 3){
                    return value.userName.toLocaleLowerCase().includes(searchTerms.toLocaleLowerCase());    
                }else if(labelValue == 'Mobile' && searchTerms.length >= 3 && value.mobileNumber !== null){
                    return value.mobileNumber.includes(searchTerms)
                } 
            });
            filterMetadata.count = this.filteredItems.length;
             return this.filteredItems
          }
     }       
  }