import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'staffSearch',
    pure: false
})

export class StaffDetailSearchPipe implements PipeTransform {
    searchResult: any = [];
    filteredItems = []
    transform(staffDetails: any = [], searchTerms: any, labelValue: any, filterMetadata: any) {
        if (!searchTerms || searchTerms.length < 3) {
            return staffDetails;
        }
        if (searchTerms.length >= 3) {
            this.filteredItems = staffDetails.filter(value => {
                if (labelValue == 'Email' && searchTerms.length >= 3) {
                    return value.emailId.toLocaleLowerCase().includes(searchTerms.toLocaleLowerCase());
                } else if (labelValue == 'Name' && searchTerms.length >= 3) {
                    return value.fullName.toLocaleLowerCase().includes(searchTerms.toLocaleLowerCase());
                }
            });
            filterMetadata.count = this.filteredItems.length;
            return this.filteredItems
        }
    }
}