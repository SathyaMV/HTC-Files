import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { studentDetailSearchPipe } from './student-search.pipe';
import { OrdinalDatePipe } from './date-ordinal.pipe';

@NgModule({
  declarations: [studentDetailSearchPipe,OrdinalDatePipe],
  imports: [
    CommonModule
  ],
  exports: [
    studentDetailSearchPipe,
    OrdinalDatePipe
  ]
})
export class PipeModule { }
