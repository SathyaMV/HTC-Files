export interface EventGroup {
  title: string
  hostCountry: string
  destinations: string[]
}
