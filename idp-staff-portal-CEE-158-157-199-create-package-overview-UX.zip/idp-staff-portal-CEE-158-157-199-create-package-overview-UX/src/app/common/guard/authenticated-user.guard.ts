import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree } from '@angular/router';
import { Auth } from 'aws-amplify';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthenticatedUserGuard implements CanActivate {
  constructor(private router: Router,) { }
  canActivate(): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    if(environment.enableAutentication) {
      return Auth.currentAuthenticatedUser().then(user => {
        return true;
      }).catch(err => {
        Auth.federatedSignIn();
        return false;
      });
    } else{
      return true;
    }
  }
}