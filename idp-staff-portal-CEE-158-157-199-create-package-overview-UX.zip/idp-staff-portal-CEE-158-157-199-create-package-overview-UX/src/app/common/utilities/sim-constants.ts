const dev = 'https://api.staffportal.dev.idp.com/'
const stg = 'https://api.staffportal.stg.idp.com/'
const uat = 'https://api.staffportal.uat.idp.com/'
const prd = 'https://api.staffportal.idp.com/'

export const simConstants = {
  routingUrl: {
    createEvent: 'idp-staff-portal/create-new-event',
    EventType: 'idp-staff-portal/event-type',
    newMasterEvent: 'idp-staff-portal/new-master-event',
    studentEvent: 'idp-staff-portal/student-event'
  },
  dev: {
    eventClassificationList: './assets/json/classificationList.json',
    tabListApi: 'assets/json/newMasterEvent.json',
    destinationApi: 'assets/json/destination.json',
    studentEventTabListApi: 'assets/json/studentEventTab.json',
    supportedStudyLevelJson: 'assets/json/supportedStudyLevel.json',
    eventClassificationApi: dev + 'staffportal/v1/eventClassificationTypeCategories',
    regionApi: dev + 'staffportal/v1/regions',
    countryApi: dev + 'staffportal/v1/countries/',
    masterEventApi: dev + 'staffportal/v1/masterEvents',
    studentEventApi: dev + 'staffportal/v1/events',
    eventPlannerEmailApi: dev + 'staffportal/v1/staffs/',
    langTxtJson: 'assets/json/lang/en.json',
    hostCountryApi: dev + 'staffportal/v1/idpOffices',
    timezoneJson: 'assets/json/timezone.json'
  },
  stg: {
    eventClassificationList: './assets/json/classificationList.json',
    tabListApi: 'assets/json/newMasterEvent.json',
    destinationApi: 'assets/json/destination.json',
    studentEventTabListApi: 'assets/json/studentEventTab.json',
    supportedStudyLevelJson: 'assets/json/supportedStudyLevel.json',
    eventClassificationApi: stg + 'staffportal/v1/eventClassifications',
    regionApi: stg + 'staffportal/v1/regions',
    countryApi: stg + 'staffportal/v1/countries/',
    masterEventApi: stg + 'staffportal/v1/masterEvents',
    studentEventApi: stg + 'staffportal/v1/events',
    eventPlannerEmailApi: stg + 'staffportal/v1/staffs/',
    langTxtJson: 'assets/json/lang/en.json',
    hostCountryApi: stg + 'staffportal/v1/idpOffices',
    timezoneJson: 'assets/json/timezone.json'
  },
  uat: {
    eventClassificationList: './assets/json/classificationList.json',
    tabListApi: 'assets/json/newMasterEvent.json',
    destinationApi: 'assets/json/destination.json',
    studentEventTabListApi: 'assets/json/studentEventTab.json',
    supportedStudyLevelJson: 'assets/json/supportedStudyLevel.json',
    eventClassificationApi: uat + 'staffportal/v1/eventClassifications',
    regionApi: uat + 'staffportal/v1/regions',
    countryApi: uat + 'staffportal/v1/countries/',
    masterEventApi: uat + 'staffportal/v1/masterEvents',
    studentEventApi: uat + 'staffportal/v1/events',
    eventPlannerEmailApi: uat + 'staffportal/v1/staffs/',
    langTxtJson: 'assets/json/lang/en.json',
    hostCountryApi: uat + 'staffportal/v1/idpOffices',
    timezoneJson: 'assets/json/timezone.json'
  },
  prd: {
    eventClassificationList: './assets/json/classificationList.json',
    tabListApi: 'assets/json/newMasterEvent.json',
    destinationApi: 'assets/json/destination.json',
    studentEventTabListApi: 'assets/json/studentEventTab.json',
    supportedStudyLevelJson: 'assets/json/supportedStudyLevel.json',
    eventClassificationApi: prd + 'staffportal/v1/eventClassifications',
    regionApi: prd + 'staffportal/v1/regions',
    countryApi: prd + 'staffportal/v1/countries/',
    masterEventApi: prd + 'staffportal/v1/masterEvents',
    studentEventApi: prd + 'staffportal/v1/events',
    eventPlannerEmailApi: prd + 'staffportal/v1/staffs/',
    langTxtJson: 'assets/json/lang/en.json',
    hostCountryApi: prd + 'staffportal/v1/idpOffices',
    timezoneJson: 'assets/json/timezone.json'
  },
  emailPattern: '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'
}

const devEventCopyUrl = 'https://events.register.dev.idp.com/registration/'
const stgEventCopyUrl = 'https://events.register.stg.idp.com/registration/'
const uatEventCopyUrl = 'https://events.register.uat.idp.com/registration/'
const prdEventCopyUrl = 'https://events.register.prd.idp.com/registration/'

const devKioskUrl = 'https://events.kiosk.dev.idp.com/kiosk/'
const stgKioskUrl = 'https://events.kiosk.stg.idp.com/kiosk/'
const uatKioskUrl = 'https://events.kiosk.uat.idp.com/kiosk/'
const prdKioskUrl = 'https://events.kiosk.prd.idp.com/kiosk/'

const devCheckInAppUrl = 'https://events.checkin.dev.idp.com/check-in/login/'
const stgCheckInAppUrl = 'https://events.checkin.stg.idp.com/check-in/login/'
const uatCheckInAppUrl = 'https://events.checkin.uat.idp.com/check-in/login/'
const prdCheckInAppUrl = 'https://events.checkin.prd.idp.com/check-in/login/'

export const routingUrl = {
  eventsListPage: 'idp-staff-portal/events-dashboard',
  eventOverviewPage: 'idp-staff-portal/events-overview',
  studentProfileUrl: 'idp-staff-portal/student-profile',
  dev: {
    eventCopyUrl: devEventCopyUrl,
    kioskUrl: devKioskUrl,
    checkInUrl: devCheckInAppUrl
  },
  stg: {
    eventCopyUrl: stgEventCopyUrl,
    kioskUrl: stgKioskUrl,
    checkInUrl: stgCheckInAppUrl
  },
  uat: {
    eventCopyUrl: uatEventCopyUrl,
    kioskUrl: uatKioskUrl,
    checkInUrl: uatCheckInAppUrl
  },
  prd: {
    eventCopyUrl: prdEventCopyUrl,
    kioskUrl: prdKioskUrl,
    checkInUrl: prdCheckInAppUrl
  }
}
