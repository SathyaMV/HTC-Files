import { isPlatformBrowser } from '@angular/common';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { AbstractControl, FormControl } from '@angular/forms';
import * as XLSX from 'xlsx';

@Injectable()
export class CommonMethods {

  constructor(@Inject(PLATFORM_ID) private platformId) { }

  //Generating correlation id
  correlationId() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = this.getRandom() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  //Generate random value
  getRandom() {
    let random = window.crypto.getRandomValues(new Uint32Array(1))
    return random[0] / Math.pow(2, 32)
  }

  //set tab id
  setTabId() {
    if (isPlatformBrowser(this.platformId)) {
      const tabID = sessionStorage.tabID && sessionStorage.closedLastTab !== '2' ? sessionStorage.tabID : sessionStorage.tabID = this.getRandom();
      sessionStorage.closedLastTab = '2';
      $(window).on('unload beforeunload', function () {
        sessionStorage.closedLastTab = '1';
      });
    }
  }

  downLoadTemplate(questionList, dialCode) {
    let columnList = {};
    let instructions = [];
    let pickListMaxSize = 0;
    let pickListItems = [];
    questionList = this.sortByDisplaySequence(questionList, 'displaySequence');
    for (let i = 0; i < questionList.length; i++) {
      columnList[questionList[i].label] = "";
      let instruction = {
        field_name: questionList[i].mappingField,
        is_mandatory: questionList[i].mandatory,
        max_length: questionList[i].mappingField == 'primary_mobile_number' ? Number(dialCode.maxLength) : questionList[i].maxLength,
        type: ""
      };

      if (questionList[i].displayFormat.value == "TEXT_BOX")
        instruction.type = "text";
      else if (questionList[i].displayFormat.value == "CHECKBOX")
        instruction.type = "yes or no";
      else if (questionList[i].displayFormat.value == "SELECT_BOX" || questionList[i].displayFormat.value == "AJAX") {
        instruction.type = "pick-list";

        let options = [];
        if (pickListMaxSize < questionList[i].options.length)
          pickListMaxSize = questionList[i].options.length;
        for (let j = 0; j < questionList[i].options.length; j++) {
          options.push(questionList[i].options[j].option_desc);
        }
        pickListItems.push({ name: questionList[i].label, values: options });
      }
      instructions.push(instruction);
    }

    let workbook = XLSX.utils.book_new();

    let wsInstructions = XLSX.utils.json_to_sheet(instructions);
    XLSX.utils.book_append_sheet(workbook, wsInstructions, "Instructions");

    let wsTemplate = XLSX.utils.json_to_sheet([columnList]);
    XLSX.utils.book_append_sheet(workbook, wsTemplate, "Template");

    let pickListJson = [];
    for (let i = 0; i < pickListMaxSize; i++) {
      let pickListRow = {};
      for (let j = 0; j < pickListItems.length; j++) {
        pickListRow[pickListItems[j].name] = "";
        if (pickListItems[j].values.length > i)
          pickListRow[pickListItems[j].name] = pickListItems[j].values[i];
      }
      pickListJson.push(pickListRow);
    }
    let wsPickList = XLSX.utils.json_to_sheet(pickListJson);
    XLSX.utils.book_append_sheet(workbook, wsPickList, "Pick-Lists");
    XLSX.writeFile(workbook, 'bulk-upload-template.xlsx');
  }

  sortByDisplaySequence = (arr, key) => {
    return arr.sort((a, b) => {
      return parseInt(a[key]) - parseInt(b[key]);
    });
  };

  downLoadErrorRecords(records, eventQuestions) {
    let excelArray = []
    let questionLabel = []
    eventQuestions.filter(ele => {
      questionLabel.push(ele.label)
    })
    let mappingField = []
    eventQuestions.filter(ele => {
      mappingField.push(ele.mappingField)
    })
    records.map(list => {
      let tmpObj = {}
      Object.keys(list).forEach(ele => {
        let condition = mappingField.indexOf(ele)
        if (condition != -1) {
          tmpObj[questionLabel[condition]] = list[ele]
        }
      })
      excelArray.push(tmpObj);
    })
    let workbook = XLSX.utils.book_new();
    let wsTemplate = XLSX.utils.json_to_sheet(excelArray);
    XLSX.utils.book_append_sheet(workbook, wsTemplate, "Template");
    XLSX.writeFile(workbook, 'bulk-upload-template.csv');
  }

  /************To check given string is valid or not***************/
  isBlankOrNull(value) {
    if (value === null || value === 'null' || value === '' || value === 'undefined' ||
      value === undefined || (typeof (value) === 'object' && (Object.keys(value).length === 0 || value.length === 0))) {
      return true;
    }
    return false;
  }

  //Check input value is number or not
  checkOnlyDigit(value) {
    return /^\d+$/.test(value)
  }
  getMobileNumber(mobileNumber) {
    let numberWithAsterisk = '';
    if (mobileNumber != null) {
      let removeSpace = mobileNumber.split(" ").join("")
      if (mobileNumber.includes('+') && mobileNumber.includes(' ') && mobileNumber.length > 7) {
        numberWithAsterisk = mobileNumber.substr(0, 7) + '***' + mobileNumber.substr(mobileNumber.length - 3)
      } else if (/^\d+$/.test(removeSpace) && removeSpace.length > 7) {
        numberWithAsterisk = mobileNumber.substr(0, 5) + '***' + mobileNumber.substr(mobileNumber.length - 3)
      } else if (mobileNumber == null || mobileNumber == "") {
        numberWithAsterisk = ""
      } else if (removeSpace.includes('+')) {
        numberWithAsterisk = mobileNumber
      }
    }
    return numberWithAsterisk
  }

  //This method is use to find whether the user is using mobile device
  isMobileUser() {
    if (isPlatformBrowser(this.platformId)) {
      if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        // true for mobile device
        return true;
      } else {
        // false for not mobile device
        return false;
      }
    }
    return true;
  }

  emailValidation(object: AbstractControl): { [key: string]: boolean } {
    var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if ((pattern.test(object.value))) {
      return {};
    }
    return { emailerror: true };
  }

  //This method is uded to remove whitespace
  public removeSpaces(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }

  //This method is used to get masked email
  getMaskedEmail(email) {
    let emailWithAsterisk = ''
    const emailSeparation: any = email.substring(0, email.indexOf("@"))
    if (email != null && email != undefined) {
      if (emailSeparation.length > 3) {
        emailWithAsterisk = email.substring(0, 3) + '***' + email.substring(email.lastIndexOf("@"))
      } else if (emailSeparation.length == 3) {
        emailWithAsterisk = email.substring(0, 2) + '***' + email.substring(email.lastIndexOf("@"))
      } else if (emailSeparation.length == 2) {
        emailWithAsterisk = email.substring(0, 1) + '***' + email.substring(email.lastIndexOf("@"))
      } else {
        emailWithAsterisk = email
      }
    }
    return emailWithAsterisk
  }


  barChartObject(name, dataValue, type) {
    let verticalObj = {
      x: {
        ticks: {
          padding: 10,
          color: '#000',
          font: {
            family: "BuenosAires-Light",
            size: 14
          },
          callback: function (label, index) {
            return this.getLabelForValue(index).split(" ");
          }
        },
        grid: {
          drawOnChartArea: false,
          drawTicks: false,
          borderWidth: 2
        }
      },
      y: {
        ticks: {
          display: false,
        },
        grid: {
          display: false,
          drawBorder: false,
        }
      }
    }


    let horizontalObj =  {
      y: {
        ticks:{
          padding: 10,
          color:'#000',
          font:{
            family:"BuenosAires-Light",
            size: 14
          }
        },
        grid:{
          drawOnChartArea: false,
          drawTicks:false,
          borderWidth:2,
          drawBorder: false,
        }
      },
      x: {
          ticks:{
            display:false,
          },
          grid:{
            display: false,
            drawBorder: false,
          }
        }
    }

    let obj ={
      maintainAspectRatio: false,
      plugins: {
        tooltip: {
          enabled:false,
          external: (context) => {
            let tooltipEl = document.getElementById(name);
            if (!tooltipEl) {
                tooltipEl = document.createElement('div');
                tooltipEl.id = name;
                document.body.appendChild(tooltipEl);
            }
            const tooltipModel = context.tooltip;
            tooltipEl.style.left = tooltipModel.caretX-22 + 'px';
            tooltipEl.style.top = tooltipModel.caretY-44 + 'px';
            const arrayvalue =context.tooltip.dataPoints[0].dataIndex;
            const dataValues = dataValue;
            tooltipEl.innerHTML = dataValues[arrayvalue].toString();
            if (tooltipModel.opacity === 0) {
              tooltipEl.style.opacity = '0';
            }else{
              tooltipEl.style.opacity = '1';
            }
          }
        }
      },
      scales: type === 'vertical' ? verticalObj : horizontalObj
    };

    if(type === 'horizontal'){
      obj['indexAxis'] = 'y'
    }

    console.log(Object(obj),'obj')
    return Object(obj)
  }

  dognughtChartObj(name, dataValue){

    let obj = {
      maintainAspectRatio: false,
      plugins: {
        tooltip: {
          enabled:false,
          external: (context) => {
            let tooltipEl = document.getElementById(name);
            if (!tooltipEl) {
                tooltipEl = document.createElement('div');
                tooltipEl.id = name;
                document.body.appendChild(tooltipEl);
            }
            const tooltipModel = context.tooltip;
            tooltipEl.style.left = tooltipModel.caretX+32 + 'px';
            tooltipEl.style.top = tooltipModel.caretY-22 + 'px';
            const arrayValue =context.tooltip.dataPoints[0].dataIndex;
            const dataValues = dataValue;
            tooltipEl.innerHTML = dataValues[arrayValue].toString();
            if (tooltipModel.opacity === 0) {
              tooltipEl.style.opacity = '0';
            }else{
              tooltipEl.style.opacity = '1';
            }
          }
        }
      },
    };
    return Object(obj)
  }

}
