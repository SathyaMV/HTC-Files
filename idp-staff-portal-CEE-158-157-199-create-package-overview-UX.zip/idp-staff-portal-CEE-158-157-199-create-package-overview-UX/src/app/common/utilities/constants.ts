const dev = 'https://api.staffportal.dev.idp.com/';
const stg = 'https://api.staffportal.stg.idp.com/';
const uat = 'https://api.staffportal.uat.idp.com/';
const prd = 'https://api.staffportal.idp.com/';

export const constants = {
    dev:{
        authentication : true,
        authenticationEmail:'',
        authenticationToken : '',
        eventListViewAPI : dev + 'staffportal/v1/eventsListing',
        eventOverViewAPI : dev + 'staffportal/v1/getEventOverview',
        virtualEventUrl : 'https://meet.dev.idp.com/virtual-events/landing/',
        webinarEventUrl : 'https://meet.dev.idp.com/virtual-events/landing/webinar/',
        studentProfileAPI : dev + 'dev/v1/getStudentProfileQuestions',
        eventQrcheckIn :  dev + 'staffportal/v1/studentQrCheckIn',
        eventsDynamicForm : dev + 'staffportal/v1/eventsDynamicForm',
        getNotesDetailsAPI : dev + 'staffportal/v1/getStudentProfileDetails',
        putNotesDetailsAPI : dev + 'staffportal/v1/putStudentProfileNotes',
        bulkUploadRegistration : dev + 'staffportal/v1/eventsRegistration',
        getQuestions : dev + 'staffportal/v1/getProgressiveProfile',
        updatePersonalInfo : dev + 'staffportal/v1/UpdatePersonalInfo',
        kioskSearch : dev + 'staffportal/v1/kioskSearch',
        eventRegistrationForm : dev + 'staffportal/v1/eventStaticForm',
        updateEducationInfo : dev + 'staffportal/v1/updateEducationProfile',
        bulkUploadLog : dev + 'staffportal/v1/bulkUploadLogs',
        searchEventResgistration : dev + 'staffportal/v1/eventsRegistration/search',
        getPreferenceInfo : dev + 'staffportal/v1/getStudentLeadManagement',
        getEducationInfo : dev + 'staffportal/v1/getStudentEducationDetails',
        getEnglishProficiency : dev + 'staffportal/v1/getEnglishProficiency',
        putEnglishProficiency : dev + 'staffportal/v1/putEnglishProficiency',
        getHowDidYouHear : dev + 'staffportal/v1/reports/getHdyh',
        getDestination : dev + 'staffportal/v1/reports/getPreferredStudyDestination',
        getRegisterParticipant : dev + 'staffportal/v1/reports/getRegistrationParticipant',
        getPreferredStudyLevel : dev + 'staffportal/v1/reports/getPreferredStudyLevel',
        getPreRegisterWalkin : dev + 'staffportal/v1/reports/getPreRegistrationWalkIn',
        getHighestQualification : dev + 'staffportal/v1/reports/getHighestQualification',
        getNewExistingStudent :dev + 'staffportal/v1/reports/getNewExistingStudent',
        postStaffDetails : dev + 'staffportal/v1/postAddStaffDetails',
        getStaffDetails : dev + 'staffportal/v1/getAddStaffDetails',
        getUserList : dev + 'staffportal/v1/userListing',
        getPermissions : dev + 'staffportal/v1/permissions',
        getStaffProfile : dev + 'staffportal/v1/getStaffProfile',
        putStaffProfile : dev + 'staffportal/v1/putStaffProfile',
        getImportRegistrants : dev + 'staffportal/v1/importRegistrantsReport',
        putLastLogin : dev + 'staffportal/v1/staffLastLoggedIn',
        getStudentParticipation: dev + 'staffportal/v1/studentParticipantsReport',
        getDownloadReport: dev + 'staffportal/v1/postStudentParticipantsDownloadReport',
        checkStaffExist: 'https://api.events.checkin.dev.idp.com/checkin/v1/getCheckstaffExist',
        updateReferralDetails: dev + 'staffportal/v1/eventInstitutionReferral'
    },
    stg:{
        authentication : true,
        authenticationEmail:'',
        authenticationToken : '',
        eventListViewAPI : stg + 'staffportal/v1/eventsListing',
        eventOverViewAPI : stg + 'staffportal/v1/getEventOverview',
        virtualEventUrl : 'https://meet.stg.idp.com/virtual-events/landing/',
        webinarEventUrl : 'https://meet.stg.idp.com/virtual-events/landing/webinar/',
        studentProfileAPI : stg + 'dev/v1/getStudentProfileQuestions',
        eventQrcheckIn :  stg + 'staffportal/v1/studentQrCheckIn',
        eventsDynamicForm : stg + 'staffportal/v1/eventsDynamicForm',
        getNotesDetailsAPI : stg + 'staffportal/v1/getStudentProfileDetails',
        putNotesDetailsAPI : stg + 'staffportal/v1/putStudentProfileNotes',
        bulkUploadRegistration : stg + 'staffportal/v1/eventsRegistration',
        getQuestions : stg + 'staffportal/v1/getProgressiveProfile',
        updatePersonalInfo : stg + 'staffportal/v1/UpdatePersonalInfo',
        kioskSearch : stg + 'staffportal/v1/kioskSearch',
        eventRegistrationForm : stg + 'staffportal/v1/eventStaticForm',
        updateEducationInfo : stg + 'staffportal/v1/updateEducationProfile',
        bulkUploadLog : stg + 'staffportal/v1/bulkUploadLogs',
        searchEventResgistration : stg + 'staffportal/v1/eventsRegistration/search',
        getPreferenceInfo : stg + 'staffportal/v1/getStudentLeadManagement',
        getEducationInfo : stg + 'staffportal/v1/getStudentEducationDetails',
        getEnglishProficiency : stg + 'staffportal/v1/getEnglishProficiency',
        putEnglishProficiency : stg + 'staffportal/v1/putEnglishProficiency',
        getHowDidYouHear : stg + 'staffportal/v1/reports/getHdyh',
        getDestination : stg + 'staffportal/v1/reports/getPreferredStudyDestination',
        getRegisterParticipant : stg + 'staffportal/v1/reports/getRegistrationParticipant',
        getPreferredStudyLevel : stg + 'staffportal/v1/reports/getPreferredStudyLevel',
        getPreRegisterWalkin : stg + 'staffportal/v1/reports/getPreRegistrationWalkIn',
        getHighestQualification : stg + 'staffportal/v1/reports/getHighestQualification',
        getNewExistingStudent :stg + 'staffportal/v1/reports/getNewExistingStudent',
        postStaffDetails : stg + 'staffportal/v1/postAddStaffDetails',
        getStaffDetails : stg + 'staffportal/v1/getAddStaffDetails',
        getUserList : stg + 'staffportal/v1/userListing',
        getPermissions : stg + 'staffportal/v1/permissions',
        getStaffProfile : stg + 'staffportal/v1/getStaffProfile',
        putStaffProfile : stg + 'staffportal/v1/putStaffProfile',
        getImportRegistrants : stg + 'staffportal/v1/importRegistrantsReport',
        putLastLogin : stg + 'staffportal/v1/staffLastLoggedIn',
        getStudentParticipation: stg + 'staffportal/v1/studentParticipantsReport',
        getDownloadReport: stg + 'staffportal/v1/postStudentParticipantsDownloadReport',
        checkStaffExist: 'https://api.events.checkin.stg.idp.com/checkin/v1/getCheckstaffExist',
        updateReferralDetails: stg + 'staffportal/v1/eventInstitutionReferral'
    },
    uat:{
        authentication : true,
        authenticationEmail:'',
        authenticationToken : '',
        eventListViewAPI : uat + 'staffportal/v1/eventsListing',
        eventOverViewAPI : uat + 'staffportal/v1/getEventOverview',
        virtualEventUrl : 'https://meet.uat.idp.com/virtual-events/landing/',
        webinarEventUrl : 'https://meet.uat.idp.com/virtual-events/landing/webinar/',
        studentProfileAPI : uat + 'dev/v1/getStudentProfileQuestions',
        eventQrcheckIn :  uat + 'staffportal/v1/studentQrCheckIn',   
        eventsDynamicForm : uat + 'staffportal/v1/eventsDynamicForm',
        getNotesDetailsAPI : uat + 'staffportal/v1/getStudentProfileDetails',
        putNotesDetailsAPI : uat + 'staffportal/v1/putStudentProfileNotes',
        bulkUploadRegistration : uat + 'staffportal/v1/eventsRegistration',
        getQuestions : uat + 'staffportal/v1/getProgressiveProfile',
        updatePersonalInfo : uat + 'staffportal/v1/UpdatePersonalInfo',
        kioskSearch : uat + 'staffportal/v1/kioskSearch',
        eventRegistrationForm : uat + 'staffportal/v1/eventStaticForm',
        updateEducationInfo : uat + 'staffportal//v1/updateEducationProfile',
        bulkUploadLog : uat + 'staffportal/v1/bulkUploadLogs',
        searchEventResgistration : uat + 'staffportal/v1/eventsRegistration/search',
        getPreferenceInfo : uat + 'staffportal/v1/getStudentLeadManagement',
        getEducationInfo : uat + 'staffportal/v1/getStudentEducationDetails',
        getEnglishProficiency : uat + 'staffportal/v1/getEnglishProficiency',
        putEnglishProficiency : uat + 'staffportal/v1/putEnglishProficiency',
        getHowDidYouHear : uat + 'staffportal/v1/reports/getHdyh',
        getDestination : uat + 'staffportal/v1/reports/getPreferredStudyDestination',
        getRegisterParticipant : uat + 'staffportal/v1/reports/getRegistrationParticipant',
        getPreferredStudyLevel : uat + 'staffportal/v1/reports/getPreferredStudyLevel',
        getPreRegisterWalkin : uat + 'staffportal/v1/reports/getPreRegistrationWalkIn',
        getHighestQualification : uat + 'staffportal/v1/reports/getHighestQualification',
        getNewExistingStudent : uat + 'staffportal/v1/reports/getNewExistingStudent',
        postStaffDetails : uat + 'staffportal/v1/postAddStaffDetails',
        getStaffDetails : uat + 'staffportal/v1/getAddStaffDetails',
        getUserList : uat + 'staffportal/v1/userListing',
        getPermissions : uat + 'staffportal/v1/permissions',
        getStaffProfile : uat + 'staffportal/v1/getStaffProfile',
        putStaffProfile : uat + 'staffportal/v1/putStaffProfile',
        getImportRegistrants : uat + 'staffportal/v1/importRegistrantsReport',
        putLastLogin : uat + 'staffportal/v1/staffLastLoggedIn',
        getStudentParticipation: uat + 'staffportal/v1/studentParticipantsReport',
        getDownloadReport: uat + 'staffportal/v1/postStudentParticipantsDownloadReport',
        checkStaffExist: 'https://api.events.checkin.uat.idp.com/checkin/v1/getCheckstaffExist',
        updateReferralDetails: uat + 'staffportal/v1/eventInstitutionReferral'
    },
    prd:{
        authentication : true,
        authenticationEmail:'',
        authenticationToken : '',
        eventListViewAPI : prd + 'staffportal/v1/eventsListing',
        eventOverViewAPI : prd + 'staffportal/v1/getEventOverview',
        virtualEventUrl : 'https://meet.idp.com/virtual-events/landing/',
        webinarEventUrl : 'https://meet.idp.com/virtual-events/landing/webinar/',
        studentProfileAPI : prd + 'dev/v1/getStudentProfileQuestions',
        eventQrcheckIn :  prd + 'staffportal/v1/studentQrCheckIn',
        eventsDynamicForm : prd + 'staffportal/v1/eventsDynamicForm',
        getNotesDetailsAPI : prd + 'staffportal/v1/getStudentProfileDetails',
        putNotesDetailsAPI : prd + 'staffportal/v1/putStudentProfileNotes',
        bulkUploadRegistration : prd + 'staffportal/v1/eventsRegistration',
        getQuestions : prd + 'staffportal/v1/getProgressiveProfile',
        updatePersonalInfo : prd + 'staffportal/v1/UpdatePersonalInfo',
        kioskSearch : prd + 'staffportal/v1/kioskSearch',
        eventRegistrationForm : prd + 'staffportal/v1/eventStaticForm',
        updateEducationInfo : prd + 'staffportal/v1/updateEducationProfile',
        bulkUploadLog : prd + 'staffportal/v1/bulkUploadLogs',
        searchEventResgistration : prd + 'staffportal/v1/eventsRegistration/search',
        getPreferenceInfo : prd + 'staffportal/v1/getStudentLeadManagement',
        getEducationInfo : prd + 'staffportal/v1/getStudentEducationDetails',
        getEnglishProficiency : prd + 'staffportal/v1/getEnglishProficiency',
        putEnglishProficiency : prd + 'staffportal/v1/putEnglishProficiency',
        getHowDidYouHear : prd + 'staffportal/v1/reports/getHdyh',
        getDestination : prd + 'staffportal/v1/reports/getPreferredStudyDestination',
        getRegisterParticipant : prd + 'staffportal/v1/reports/getRegistrationParticipant',
        getPreferredStudyLevel : prd + 'staffportal/v1/reports/getPreferredStudyLevel',
        getPreRegisterWalkin : prd + 'staffportal/v1/reports/getPreRegistrationWalkIn',
        getHighestQualification : prd + 'staffportal/v1/reports/getHighestQualification',
        getNewExistingStudent : prd + 'staffportal/v1/reports/getNewExistingStudent',
        postStaffDetails : prd + 'staffportal/v1/postAddStaffDetails',
        getStaffDetails : prd + 'staffportal/v1/getAddStaffDetails',
        getUserList : prd + 'staffportal/v1/userListing',
        getPermissions : prd + 'staffportal/v1/permissions',
        getStaffProfile : prd + 'staffportal/v1/getStaffProfile',
        putStaffProfile : prd + 'staffportal/v1/putStaffProfile',
        getImportRegistrants : prd + 'staffportal/v1/importRegistrantsReport',
        putLastLogin : prd + 'staffportal/v1/staffLastLoggedIn',
        getStudentParticipation: prd + 'staffportal/v1/studentParticipantsReport',
        getDownloadReport: prd + 'staffportal/v1/postStudentParticipantsDownloadReport',
        checkStaffExist: 'https://api.events.checkin.prd.idp.com/checkin/v1/getCheckstaffExist',
        updateReferralDetails: prd + 'staffportal/v1/eventInstitutionReferral'
    }
}

const devEventCopyUrl = 'https://events.register.dev.idp.com/registration/';
const stgEventCopyUrl = 'https://events.register.stg.idp.com/registration/';
const uatEventCopyUrl = 'https://events.register.uat.idp.com/registration/';
const prdEventCopyUrl = 'https://events.register.idp.com/registration/';

const devKioskUrl = 'https://events.kiosk.dev.idp.com/kiosk/';
const stgKioskUrl = 'https://events.kiosk.stg.idp.com/kiosk/';
const uatKioskUrl = 'https://events.kiosk.uat.idp.com/kiosk/';
const prdKioskUrl = 'https://events.kiosk.idp.com/kiosk/';

const devCheckInAppUrl = 'https://events.checkin.dev.idp.com/check-in/login/';
const stgCheckInAppUrl = 'https://events.checkin.stg.idp.com/check-in/login/';
const uatCheckInAppUrl = 'https://events.checkin.uat.idp.com/check-in/login/';
const prdCheckInAppUrl = 'https://events.checkin.idp.com/check-in/login/';

export const routingUrl = {
  eventsListPage: 'idp-staff-portal/events-dashboard',
  eventOverviewPage: 'idp-staff-portal/events-overview',
  studentProfileUrl: 'idp-staff-portal/student-profile',
  dev: {
    eventCopyUrl: devEventCopyUrl,
    kioskUrl : devKioskUrl,
    checkInUrl : devCheckInAppUrl
  },
  stg: {
    eventCopyUrl: stgEventCopyUrl,
    kioskUrl : stgKioskUrl,
    checkInUrl : stgCheckInAppUrl
  },
  uat: {
    eventCopyUrl: uatEventCopyUrl,
    kioskUrl : uatKioskUrl,
    checkInUrl : uatCheckInAppUrl
  },
  prd: {
    eventCopyUrl: prdEventCopyUrl,
    kioskUrl : prdKioskUrl,
    checkInUrl : prdCheckInAppUrl
  }
}


export const cognito = {
  dev: {

  },
  stg: {

  },
  uat: {

  },
  prd: {

  }
}