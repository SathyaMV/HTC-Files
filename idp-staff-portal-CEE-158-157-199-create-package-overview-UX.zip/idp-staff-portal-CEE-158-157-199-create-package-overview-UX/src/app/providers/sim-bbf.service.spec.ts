import { TestBed } from '@angular/core/testing'

import { SimBbfService } from './sim-bbf.service'

describe('Sim.BbfService', () => {
  let service: SimBbfService

  beforeEach(() => {
    TestBed.configureTestingModule({})
    service = TestBed.inject(SimBbfService)
  })
  it('should be created', () => {
    expect(service).toBeTruthy()
  })
  it('component should call getDestination Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getDestination()
  })
  it('component should call getTabList Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getTabList()
  })
  it('component should call getEventClassifications Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getEventClassifications()
  })
  it('component should call getEventClassificationList Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getEventClassificationList()
  })
  it('component should call getSupportedStudyLevel Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getSupportedStudyLevel()
  })
  it('component should call getStudentEventTabList Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getStudentEventTabList()
  })
  it('component should call getStudentEventId Api', () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getStudentEventId('2c2a3aac-a05d-11ed-9f61-98fa9b82fe16')
    expect(app.getStudentEventId('2c2a3aac-a05d-11ed-9f61-98fa9b82fe16')).toHaveBeenCalled()
  })
  it('should call get RegionList', async () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getRegionList()
    expect(app.getRegionList).toHaveBeenCalled()
  })
  it('should call get getEventPlannerEmail', async () => {
    const fixture = TestBed.createComponent(SimBbfService)
    const app = fixture.componentInstance
    app.getEventPlannerEmail('Kali')
    expect(app.getEventPlannerEmail).toHaveBeenCalled()
  })
})
