/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ClientPackagesService } from './client-packages.service';

describe('Service: ClientPackages', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClientPackagesService]
    });
  });

  it('should ...', inject([ClientPackagesService], (service: ClientPackagesService) => {
    expect(service).toBeTruthy();
  }));
});
