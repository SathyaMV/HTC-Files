import { Injectable } from '@angular/core'
import { TranslateService } from '@ngx-translate/core'

@Injectable({
  providedIn: 'root'
})
export class LangTranslateService {
  constructor (private readonly translate: TranslateService) {
    translate.setDefaultLang('en')
    translate.use('en')
  }
}
