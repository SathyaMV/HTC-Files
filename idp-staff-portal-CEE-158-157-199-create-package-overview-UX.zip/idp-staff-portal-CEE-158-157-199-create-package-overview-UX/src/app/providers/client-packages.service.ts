import { HttpClient } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { EventGroup } from '../common/models/client-package.model'

@Injectable({
  providedIn: 'root'
})
export class ClientPackagesService {
  eventGroupUrl = '../../assets/json/clientPackages.json'

  constructor (private readonly http: HttpClient) { }

  /**
     * @function getEventGroup
     * * Get all the EventGroup for the json
     * @returns Observable<EventGroup>
     */
  getEventGroup (): Observable<EventGroup> {
    return this.http.get<EventGroup>(this.eventGroupUrl)
  }
}
