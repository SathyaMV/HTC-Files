import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import {BehaviorSubject, catchError, Observable, throwError } from 'rxjs';
import { Auth } from 'aws-amplify';



@Injectable({
  providedIn: 'root'
})
export class BffService {
  public showStudentQrCode = new BehaviorSubject(false);
  public showEventQrCode = new BehaviorSubject(false);
  public showFileUploadScreen = new BehaviorSubject(false);
  public showbulkUploadTable = new BehaviorSubject(false);
  public enableQrKiosk = new BehaviorSubject(false);
  public enableRegistrationForm = new BehaviorSubject(false);
  public enableSearchKiosk = new BehaviorSubject(false);
  public showCheckInSuccess = new BehaviorSubject(false);
  public showRegistrationSuccess = new BehaviorSubject(false)
  public checkInSuccessResponseObj = new BehaviorSubject({});
  public checkInSuccessResponseData = this.checkInSuccessResponseObj.asObservable();
  public showManualRegistrationForm = new BehaviorSubject(false);
  public showLoaderIcon = new BehaviorSubject(false);
  public kioskRegistrationResponseObj = new BehaviorSubject({});
  public kioskRegistrationResponseData = this.kioskRegistrationResponseObj.asObservable();
  public excelFileObj = new BehaviorSubject({});
  public excelFileData = this.excelFileObj.asObservable();
  public hdyh = new BehaviorSubject({}); 
  public destination = new BehaviorSubject({}); 
  public reportsRegisterParticipant = new BehaviorSubject({});
  public preferredStudyLevel = new BehaviorSubject({});
  public preRegisterWalkin = new BehaviorSubject({});
  public newExistingStudent = new BehaviorSubject({});
  public highestQualification = new BehaviorSubject({})
  public userPermission = new BehaviorSubject({});
  public showBulkUploadSurveyQn = new BehaviorSubject(false);
  public bulkUploadSurvey = new BehaviorSubject({});
  public detectManualRegisterForm = new BehaviorSubject(false);
  public eventRegistrantData = new BehaviorSubject([])
  public reportRegistrantCount = new BehaviorSubject('')
  public eventParticipantCount = new BehaviorSubject('')
  staffEmailId: string = ''

  constructor(private http: HttpClient) {
    if (environment.enableAutentication) {
      Auth.currentAuthenticatedUser().then(user => {
        this.staffEmailId = user?.attributes?.email;
      }).catch(error => {
        console.log(error)
      })
    } else {
      this.staffEmailId = environment.authenticationEmail
    }
  }

  getEventsOverviewPageDetails(inPayLoad): Observable<any>{
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
       fromString:inPayLoad + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.eventOverViewAPI, httpOptions)
    .pipe(catchError(this.errorHandler));

  }


  getEventsListPageDetails(emailId):Observable<any>{
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
       fromString:'source='+'idpStaffPortal'+'&staffEmailId='+emailId
      })
    };
    return this.http.get<any>(environment.eventDashboardAPI, httpOptions)
    .pipe(catchError(this.errorHandler));
  }
  
  studentQRCheckIn(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
   
    let options = { headers: headers};
    
    const endpoint = environment.eventQrCheckIn;
    return this.http.post(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }

  getUserQuestions(website,studentUuid,formLocator){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
       fromString:'website='+ website+'&studentUuid='+studentUuid+'&formLocator='+formLocator+'&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getQuestions, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getStudentProfileDetails(inPayLoad){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:inPayLoad + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getCounsellorNotesAPI, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getBulkUploadPPQuestions(eventCode, countryCode){
	let httpOptions = {
	  headers: new HttpHeaders({
	    'Content-Type': 'application/json'
	  }),
	  params: new HttpParams({
	    fromString:'cventCode='+eventCode +'&languageCode=' + countryCode
	  })
	};
	return this.http.get<any>(environment.eventsDynamicForm, httpOptions).pipe(catchError(this.errorHandler));
  }

  sendBulkUploadRegistration(inPayload){
	let headers = new HttpHeaders({
		'Content-Type': 'application/json'
	  });
	 
	  let options = { headers: headers};
	  
	  const endpoint = environment.bulkUploadRegistration;
	  return this.http.post(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }

  sendNotesDetails(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
   
    let options = { headers: headers};
    
    const endpoint = environment.putCounsellorNotesAPI;
    return this.http.put(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }

  updatePersonalInfo(inPayload){
    inPayload.studentPersonalInfo.staffEmailId = this.staffEmailId;
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
	  const endpoint = environment.updatePersonalInfoDetails;
	  return this.http.put(endpoint, inPayload,httpOptions).pipe(catchError(this.errorHandler))
  }
  
  getKisokSearchDetails(eventId){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'eventId='+eventId
      })
    };
    return this.http.get<any>(environment.kioskSearch, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getRegistrationFormQuestion(eventCode){
    let lang = 'EN'
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'cventCode='+eventCode+'&languageCode=' +lang
      })
    };
    return this.http.get<any>(environment.eventRegsitrationForm, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  updateEducationDetails(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
      });
      let options = { headers: headers};
      const endpoint = environment.updateEducationDetails;
      return this.http.put(endpoint, inPayload,options).pipe(catchError(this.errorHandler))
  }

  updateBulkUploadLog(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    let options = { headers: headers};
    const endpoint = environment.updateBulkUploadlog;
    return this.http.post(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }


  searchEventRegistration(eventCode,mailId){
    // https://api.staffportal.dev.idp.com/staffportal/v1/eventsRegistration/search?cventCode=D8NL4B2BCZ8&emailId=farzana@yopmail.com
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'cventCode='+eventCode+'&emailId='+mailId
      })
    };
    return this.http.get<any>(environment.searchEventResgistration, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

 getPreferenceAnswer(eventId, studentId){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId +'&studentUuid=' + studentId
      })
    };
    return this.http.get<any>(environment.getPreferenceAnswer, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getEducationAnswer(studentUUid){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'studentProfileId='+studentUUid
      })
    };
    return this.http.get<any>(environment.getEducationAnswer, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getEnglishProficiency(eventId,studentId){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&studentUuid=' + studentId
      })
    };
    return this.http.get<any>(environment.getProficiency, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  updateEnglishProficiency(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    let options = { headers: headers}; 
    const endpoint = environment.putProficiency;
    return this.http.put(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }

  getHowDidYouHearDetails(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getHDYH, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getDestinationDetails(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getDestination, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getRegisterParticipant(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getRegisterParticipant, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getPreferredLevel(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getPreferredStudyLevel, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getPreRegisterWalkinDetails(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getPreRegisterWalkin, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getHighestQualification(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getHighestQualification, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getNewExistingStudentDetails(eventId,nearestIdpOffice){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId+'&nearestIdpOffice=' + nearestIdpOffice + '&staffEmailId=' +  this.staffEmailId
      })
    };
    return this.http.get<any>(environment.getNewExistingStudent, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  
  updateStaffDetails(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    let options = { headers: headers};
    const endpoint = environment.updateStaffDetails;
    return this.http.post(endpoint, inPayload,options).pipe(catchError(this.errorHandler));

  }

  getStaffDetails(eventId){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'idpEventId='+eventId
      })
    };
    return this.http.get<any>(environment.getStaffInfo, httpOptions)
    .pipe(catchError(this.errorHandler));
    
  }

  getUserList(){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.get<any>(environment.getUserList, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getUserPermission(email){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'staffEmailId='+email
      })
    };
    return this.http.get<any>(environment.getPermission, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  getStaffProfile(id,email){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'staffId='+id +'&staffEmailId=' + email
      })
    };
    return this.http.get<any>(environment.getStaffProfile, httpOptions)
    .pipe(catchError(this.errorHandler));
  }

  putStaffProfile(inPayload){
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
   
    let options = { headers: headers};
    
    const endpoint = environment.putStaffProfile;
    return this.http.put(endpoint, inPayload,options).pipe(catchError(this.errorHandler));
  }
  

  updateLastLogin(inPayLoad) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    };

    const endpoint = environment.putlastLogin;
    return this.http.put(endpoint, inPayLoad, httpOptions).pipe(catchError(this.errorHandler))
  }

  getImportRegistrants(emailId) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString: 'staffEmailId=' + emailId
      })
    };
    return this.http.get<any>(environment.getImportRegistrants, httpOptions).pipe(catchError(this.errorHandler));
  }

  getRegistrantsDetails(eventId, logId) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString: 'cventCode=' + eventId + '&logId=' + logId
      })
    };
    return this.http.get<any>(environment.getImportRegistrants, httpOptions).pipe(catchError(this.errorHandler));
  }

  getStudentParticipation(emailId) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString:'source=importStudentParticipantsReport&staffEmailId=' + emailId
      })
    };
    const endpoint = environment.getStudentParticipation;
    return this.http.get<any>(endpoint, httpOptions).pipe(catchError(this.errorHandler))
  }

  getStudentParticipationDownload(payLoad) {
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    const endpoint = environment.getDownloadReport;
    return this.http.post<any>(endpoint, payLoad, httpOptions).pipe(catchError(this.errorHandler))
  }

  checkStaffDetails(email){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      params: new HttpParams({
        fromString: 'emailId='+ email
      })
    };
    return this.http.get<any>(environment.checkStaffExist, httpOptions)
      .pipe(catchError(this.errorHandler));
  }

  updateReferralDetails(payload){
    let httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    const endpoint = environment.postReferralData;
    return this.http.post<any>(endpoint, payload, httpOptions).pipe(catchError(this.errorHandler))
  }

  errorHandler(error:HttpErrorResponse){
    return throwError(error)
  }
}
