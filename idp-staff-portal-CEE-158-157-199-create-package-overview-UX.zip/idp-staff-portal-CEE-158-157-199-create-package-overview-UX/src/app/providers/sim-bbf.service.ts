/**
 * Handle All the api request for simplified event
 * @class
 */
import { HttpClient } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { Auth } from 'aws-amplify'
import { BehaviorSubject, Observable } from 'rxjs'

import { environment } from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})

export class SimBbfService {
  staffEmailId: string = ''
  public eventData = new BehaviorSubject({ id: '', classificationId: '', type: '', typeId: '', category: '', categoryId: '', eventCode: '' })
  public physicalEventDetails = new BehaviorSubject(
    {
      location: {},
      eventDataTime: {},
      speakerDetails: {},
      studentCapacity: {},
      studentClassification: {}
    })

  public eventDetails = new BehaviorSubject(
    {
      location: {},
      eventDataTime: {},
      speakerDetails: {},
      studentCapacity: {},
      videoConfDetails: {}
    })

  public virtualEventDetails = new BehaviorSubject(
    {
      eventDataTime: {},
      videoConfDetails: {}
    })

  public sEventSave = new BehaviorSubject({ isSave: false, selectTab: '', currentTab: '' })

  public eventTypeData = new BehaviorSubject({ eventTypeCategory: {} })

  public readonly eventDataObs

  /**
 * @constructs CreateEventComponent
 * @param http - HttpClient instance
 */
  constructor (private readonly http: HttpClient) {
    Auth.currentAuthenticatedUser().then(user => {
      this.staffEmailId = user?.attributes?.email
    }).catch(error => {
      Auth.federatedSignIn()
    })

    this.eventDataObs = this.eventData.asObservable()
  }

  /**
   * @function getRegionList
   * @todo - Region Api call
  */
  getRegionList (): Observable<any> {
    return this.http.get(environment.regionApi)
  }

  /**
   *  @function getCountriesList - call coutry api
   *  @param regionId - selected region id
   */
  getCountriesList (regionId: string): Observable<any> {
    /**
   * @todo Below codes will be enable while implementing api.
   */
    const url: string = environment.countryApi
    return this.http.get(url + regionId)
  }

  /**
   * @function getDestination
   * @todo JSON call destination
   */
  getDestination (): Observable<any> {
    return this.http.get(environment.destinationApi)
  }

  /**
   * @function patchNewMasterEvents - call master event api
   * @param payload - form data from new master event form
   */
  patchNewMasterEvents (payload: any, pathParam: string): Observable<any> {
    return this.http.patch(environment.masterEventApi + '/' + pathParam, payload)
  }

  /** @function getTabList - call table list json
   */
  getTabList (): Observable<any> {
    return this.http.get(environment.tabListApi)
  }

  /** @function getMasterEventId - call master event api to update master event id
    * @param eventId - selected event id
   */
  getMasterEventId (eventId: any): Observable<any> {
    /**
     * @todo Below code will be enabled while implementing api
     */
    return this.http.post(environment.masterEventApi, eventId)
  }

  /** @function getEventClassifications - call event classification api
   */
  getEventClassifications (): Observable<any> {
    return this.http.get(environment.eventClassificationApi)
  }

  /** @function getEventClassificationList - call event classification list json
   */
  getEventClassificationList (): Observable<any> {
    return this.http.get(environment.eventClassificationList)
  }

  /** @function getSupportedStudyLevel - call supported study level api
   */
  getSupportedStudyLevel (): Observable<any> {
    return this.http.get(environment.supportedStudyLevelJson)
  }

  /** @function getStudentEventTabList - call student event tab list api
   */
  getStudentEventTabList (): Observable<any> {
    return this.http.get(environment.studentEventTabListApi)
  }

  /** @function getStudentEventId - call student event id
   *  @param eventId - event id
   */
  getStudentEventId (eventId: any): Observable<any> {
    return this.http.post(environment.studentEventApi, eventId)
  }

  /** @function patchStudentEvent - call event classification list json
   * @parm payload - from data from studend event page form
   */
  patchStudentEvent (payload: any): Observable<any> {
    return this.http.post(environment.studentEventApi, payload)
  }

  /**
   * @function getEventPlannerEmail - call event getEventPlannerEmail
   * @parm payload - email search
   */
  getEventPlannerEmail (searchEmail: string): Observable<any> {
    return this.http.get(environment.eventPlannerEmailApi + searchEmail)
  }

  /** @function getLanguage - loads the langtx.json file
   */
  getLanguage (): Observable<any> {
    return this.http.get(environment.langTxtJson)
  }

  /**
   * @function getCountryList - call event getCountryList
   * @param if payload empty it will return country list
   * @param if payload pass country name it will return idp office and team
   */
  getCountryList (countryName): Observable<any> {
    const url = countryName ? environment.hostCountryApi + '?countryName=' + countryName : environment.hostCountryApi
    return this.http.get(url)
  }

  /**
   * @function getTimezone - call event getTimezone
   */
  getTimezone (): Observable<any> {
    return this.http.get(environment.timezoneJson)
  }
}
