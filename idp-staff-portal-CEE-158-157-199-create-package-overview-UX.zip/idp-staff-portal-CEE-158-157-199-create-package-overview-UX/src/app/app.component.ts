import { isPlatformBrowser } from '@angular/common';
import { Component, HostListener, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { Auth } from 'aws-amplify';
import { CommonMethods } from './common/utilities/common-methods';
import { BffService } from './providers/bff.service';
import { environment } from 'src/environments/environment';
import { LangTranslateService } from './providers/lang-translate.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  validUser:boolean = true
  interval
  constructor(private customMethods:CommonMethods, 
              private bff: BffService,
              @Inject(PLATFORM_ID) private platformId) {
            
              }
  ngOnInit() {
    this.customMethods.setTabId();
    if (environment.enableAutentication) {
      this.checkUserStatus()
    } else {
      this.disableAuthentication()
    }
    this.inActiveTime()
  }

  checkUserStatus() {
    Auth.currentAuthenticatedUser().then(user => {
      this.bff.getUserPermission(user.attributes.email).subscribe({
        next: res => { //user.attributes.email
          this.bff.userPermission.next(res)
          this.validUser = res.validUser;
          this.lastLogin(user.attributes.email);
        }, error: error => {
          console.log(error, 'error')
        }
      })
    }).catch(error => {
      Auth.federatedSignIn()
    })
  }

  disableAuthentication(){
    const email = environment.authenticationEmail
    this.bff.getUserPermission(email).subscribe({
      next: res => {
        this.bff.userPermission.next(res)
        this.validUser = res.validUser;
        this.lastLogin(email);
      }, error: (error: any) => {
        console.log(error, 'error')
      }
    })
}

  lastLogin(user) {
    let currentDate = new Date();
    let userLogin = sessionStorage.getItem('userLoginDetails');
    if (userLogin != 'true') {
      let loginDetails = {
        "staffEmailId": user,
        "lastLoggedIn": currentDate.toString()
      }
      this.bff.updateLastLogin(loginDetails).subscribe(res=>{
        sessionStorage.setItem('userLoginDetails', 'true');
      });
    }
  }

  @HostListener('document:mousewheel', ['$event'])
  mouseWheel(event) {
   this.inActiveTime()
  }


  @HostListener('document:click', ['$event'])
  onClickEvent(event) {
    this.inActiveTime()
  }

  @HostListener('window:mousemove')
  mouseMoveEvent(event) {
    this.inActiveTime()
  }

  @HostListener('document:keyup', ['$event'])
  KeyUpEvent(event: KeyboardEvent) {
    this.inActiveTime()
  }

  inActiveTime(){
    let idleTime = 20*60
    if (isPlatformBrowser(this.platformId)) {
    if (this.interval) {
        clearInterval(this.interval);
    }
      this.interval = setInterval(() => {
        idleTime--
        if(idleTime == 0){
          this.logoutUser()
        }
      },1000)
    } 
  }

  logoutUser(){
    Auth.signOut({ global: true }).then((res) => {  
      sessionStorage.setItem('userLoginDetails', 'true');
    }).catch((error) => {
      console.log('error signing out: ', error);
    });
  }
}