import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Chart } from 'chart.js';
import { NgChartsModule } from 'ng2-charts';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { StudyLevelComponent } from './study-level.component';

describe('StudyLevelComponent', () => {
  let component: StudyLevelComponent;
  let fixture: ComponentFixture<StudyLevelComponent>;
  let service: EventsService;
  const studyLevelData = [
    { option: 'English Language', count: 1, percentage: 5.6 },
    { option: 'School', count: 0 },
    { option: 'Undergraduate', count: 0 },
    { option: 'Postgraduate', count: 0 },
    { option: 'Doctorate', count: 0 },
    { option: 'Vocational', count: 0 },
    { option: 'University Preparation', count: 0 },
    { option: 'missing', count: 17, percentage: 94.4 }
  ];
  var isMissing = false;
  const context: any = {
    chart: {}, replay: undefined, tooltip: {
      caretX: 240.97223756735326, caretY: 86.12222873703487, opacity: 0, dataPoints: [
        {
          dataIndex: 1
        }
      ]
    }
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgChartsModule,
        HttpClientTestingModule
      ],
      declarations: [StudyLevelComponent],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    service = TestBed.inject(EventsService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudyLevelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `setStudyLevel`', () => {
    jest.spyOn(component, 'setStudyLevel');
    component.setStudyLevel();
    component.studyLevelData = studyLevelData;
    component.isMissing = isMissing;
    component.studyLevelData[0]['percentage'] = 1.5;
    component.setStudyLevel();
  });

  it('Should call `getwindowidth`', () => {
    jest.spyOn(component, 'getwindowidth');
    component.getwindowidth();
    component.scrWidth = 1500;
    expect(component.scrWidth).toBeGreaterThan(1200);
    if (component.scrWidth > 1200) {
      Chart.overrides.doughnut.cutout = 50
    }
    component.getwindowidth();
  });

  it('Should call `customTooltip`', () => {
    jest.spyOn(service, 'customTooltip').mockReturnValue(of('') as any);
    service.customTooltip(context,1,'3,30%');
  });

});
