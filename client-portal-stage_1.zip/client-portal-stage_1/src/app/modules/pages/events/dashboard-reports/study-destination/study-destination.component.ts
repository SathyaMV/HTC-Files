import { Component, OnInit, Input } from '@angular/core';
import { ChartConfiguration, Chart } from 'chart.js';
import { Dashboard } from 'src/app/core/models/events-overview-dashboard';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-study-destination',
  templateUrl: './study-destination.component.html',
  styleUrls: ['./study-destination.component.css']
})
export class StudyDestinationComponent implements OnInit {

  scrWidth = window.innerWidth;
  @Input() destinationData: Dashboard[];
  @Input() registrantsData: number;
  percentages: any = [];
  countWithPercentage: any = [];
  isMissing = false;
  countForOwnCountry: number;
  ownCountry: string = 'Australia';
  
  constructor(public eventsService : EventsService) { }

  ngOnInit(): void {
    this.getwindowidth();
    this.setStudyDestination()
  }

  setStudyDestination(): void {
    for (let i = 0; i < this.destinationData?.length; i++) {
      this.destinationData[i]['percentage'] = Math.round(this.destinationData[i].count / this.registrantsData * 100 * 10) / 10;
        this.ownCountry = this.destinationData[0].option;
        this.countForOwnCountry = this.destinationData[0].count;
    }
    for (let i = 0; i < this.destinationData?.length; i++) {
      this.percentages.push(this.destinationData[i].percentage);
      this.countWithPercentage.push(this.destinationData[i].count + ', ' + this.destinationData[i].percentage + '%');
      if (this.destinationData[i].option == 'missing')
        this.isMissing = true;
    }
    this.doughnutChartDatasets[0].data = this.percentages;
    if (this.isMissing) {
      let colors = [
        '#FFD700',
        '#FF8300',
        '#E11937'
      ];
      this.doughnutChartDatasets[0].backgroundColor = colors;
    }
  }

  getwindowidth() {
    if (this.scrWidth < 1200) {
      Chart.defaults.datasets.bar.barThickness = 40;
    } else {
      Chart.defaults.datasets.bar.barThickness = 54;
      Chart.overrides.doughnut.cutout = 50
    }
  }
  public doughnutChartDatasets: ChartConfiguration<'doughnut'>['data']['datasets'] = [
    {
      data: [],
      backgroundColor: [
        '#FFD700',
        '#FF8300',
      ],
      borderWidth: 0
    }
  ];

  public doughnutChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        enabled: false,
        external: (context) => {
          this.eventsService.customTooltip(context, 2, this.countWithPercentage);
        }
      }
    },
  };
}
