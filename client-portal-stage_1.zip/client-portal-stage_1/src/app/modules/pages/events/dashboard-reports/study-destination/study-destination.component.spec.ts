import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Chart } from 'chart.js';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { EventsModule } from '../../events.module';
import { StudyDestinationComponent } from './study-destination.component';

describe('StudyDestinationComponent', () => {
  let component: StudyDestinationComponent;
  let fixture: ComponentFixture<StudyDestinationComponent>;
  let service: EventsService;
  const destinationData = [
    { option: 'Australia', count: 3, percentage: 16.7 },
    { option: 'others', count: 3, percentage: 16.7 },
    { option: 'missing', count: 12, percentage: 66.7 }
  ];
  var isMissing = false;
  const context: any = {
    chart: {}, replay: undefined, tooltip: {
      caretX: 240.97223756735326, caretY: 86.12222873703487, opacity: 0, dataPoints: [
        {
          dataIndex: 1
        }
      ]
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule.withServerTransition({ appId: "serverApp" }),
        CommonModule,
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        EventsModule
      ],
      declarations: [StudyDestinationComponent],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
      service = TestBed.inject(EventsService);

    fixture = TestBed.createComponent(StudyDestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `setStudyDestination`', () => {
    jest.spyOn(component, 'setStudyDestination');
    component.setStudyDestination();
    component.destinationData = destinationData;
    component.isMissing = isMissing;
    component.destinationData[0]['percentage'] = 1.5;
    component.setStudyDestination();
    if (component.destinationData[0].option == 'Australia') {
      component.ownCountry = destinationData[0].option;
      component.countForOwnCountry = destinationData[0].count;
    }
  });

  it('Should call `getwindowidth`', () => {
    jest.spyOn(component, 'getwindowidth');
    component.getwindowidth();
    component.scrWidth = 1500;
    expect(component.scrWidth).toBeGreaterThan(1200);
    if (component.scrWidth > 1200) {
      Chart.defaults.datasets.bar.barThickness = 54;
      Chart.overrides.doughnut.cutout = 50
    }
    component.getwindowidth();
  });

  it('Should call `customTooltip`', () => {
    jest.spyOn(service, 'customTooltip').mockReturnValue(of('') as any);
    service.customTooltip(context, 2, '3,30%');
  });

});
