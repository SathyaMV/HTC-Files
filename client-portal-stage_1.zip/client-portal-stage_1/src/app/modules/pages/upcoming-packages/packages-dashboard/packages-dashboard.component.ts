import { Component, OnInit, OnDestroy } from '@angular/core'
import { Subscription } from 'rxjs'
import { UpcomingPackagesService } from '../../../../core/services/upcoming-packages.service'
import { Package } from '../../../../core/models/upcoming-packages.model'

@Component({
  selector: 'app-packages-dashboard',
  templateUrl: './packages-dashboard.component.html',
  styleUrls: ['./packages-dashboard.component.css']
})
export class PackagesDashboardComponent implements OnInit, OnDestroy {
  constructor (
    private readonly upcomingPackagesService: UpcomingPackagesService
  ) {}

  recordNotFound: boolean = false
  systemError: boolean = false
  clientDestination: string = 'AU'
  // Needs to be updated when API returns valid response
  eventGroupName: string = 'Australia Education Roadshow'
  hostCountryName: string = 'India'

  packageList: Package[] = []
  packageListSubscription: Subscription
  packagesCount: number = 0
  isLoading: boolean = false;

  /**
   * * getPackageStatus
   * * Method to get package status label based on packagestatus from API
   * @param status string
   * @returns string
   */
  getPackageStatus (status: string): string {
    switch (status) {
      case 'published':
        return 'Book Now'
      case 'booked':
        return 'Booked'
      case 'soldout':
        return 'Sold Out'
      default:
        return status
    }
  }

  /**
   * * getDestinationCountryCode
   * * Method to get destination country code based on country label from API
   * @param countryValue string
   * @returns string
   */
  getDestinationCountryCode (countryValue: string): string {
    switch (countryValue) {
      case 'Australia':
        return 'AU'
      case 'New Zealand':
        return 'NZ'
      case 'United States':
        return 'US'
      case 'United Kingdom':
        return 'UK'
      case 'Canada':
        return 'CA'
      case 'Ireland':
        return 'IE'
      default:
        return countryValue
    }
  }

  /**
   * * getFormattedDate
   * * Method to return package duration based on start date and end date
   * @param startDate string
   * @param endDate string
   * @returns string
   */
  getFormattedDate (startDate: string, endDate: string): string {
    const startDateObj = new Date(startDate)
    const endDateObj = new Date(endDate)
    const startDateVal = startDateObj.getDate()
    const endDateVal = endDateObj.getDate()
    const startMonth = startDateObj.toLocaleDateString('default', {
      month: 'short'
    })
    const endMonth = endDateObj.toLocaleDateString('default', {
      month: 'short'
    })
    const startYear = startDateObj.getFullYear()
    const endYear = endDateObj.getFullYear()
    if (startYear !== endYear) {
      return `${startDateVal} ${startMonth} ${startYear} - ${endDateVal} ${endMonth} ${endYear}`
    } else if (startMonth !== endMonth) {
      return `${startDateVal} ${startMonth} - ${endDateVal} ${endMonth} ${endYear}`
    } else {
      return `${startDateVal} - ${endDateVal} ${endMonth} ${endYear}`
    }
  }

  /**
   * * loadPackageDetails
   * * Method to load package details in UI based on API response
   * @param packageListInfo Package[]
   */
  loadPackageDetails (packageListInfo: Package[]): void {
    this.packageList = packageListInfo.map(packageInfo => {
      const destinationPackagePrice = packageInfo.packagePrice.find(
        priceInfo => priceInfo.destCountryCode === this.clientDestination
      )
      const destinationEarlyBirdInfo = packageInfo.packageEarlyBird.find(
        earlyBirdInfo =>
          earlyBirdInfo.destCountryCode === this.clientDestination
      )
      const destinationCountries = packageInfo.events[0]?.destination
        .split(', ')
        .map(countryName => this.getDestinationCountryCode(countryName))
        .filter(countryCode => countryCode)
        .join(', ')
      const preferredHostCountry = this.hostCountryName
      const hostCountryName = this.hostCountryName
      const packageStatus = packageInfo.status.replace(/\s/g, '').toLowerCase()
      const cartButtonLabel = this.getPackageStatus(packageStatus)

      return {
        id: packageInfo.id,
        title: packageInfo.title,
        totalEvents: packageInfo.events?.length,
        startDate: packageInfo.startDate,
        endDate: packageInfo.endDate,
        eventDuration: this.getFormattedDate(
          packageInfo.startDate,
          packageInfo.endDate
        ),
        destinationCountries,
        hostCountryName,
        hostCountryImgPath: `./assets/img/flags/${preferredHostCountry.toLowerCase()}-flag.svg`,
        eventGroup: this.eventGroupName,
        packagePrice: packageInfo.packagePrice,
        price: destinationPackagePrice.price.split('.')[0],
        cartButtonLabel,
        isBookingDeadlineAvailable: packageInfo.endDate !== '',
        bookingDeadlineDate: packageInfo.endDate,
        isEarlyBirdAvailable: destinationEarlyBirdInfo !== undefined,
        destinationEarlyBirdInfo,
        earlyBirdEndDate: destinationEarlyBirdInfo?.endDate,
        isHidden: false,
        packageType: packageInfo.packageType,
        status: packageStatus,
        packageEarlyBird: [],
        events: []
      }
    })
  }

  /**
   * * getUpcomingPackageList
   * * Method to perform API call to retrieve package list data
   */
  getUpcomingPackageList (): void {
    this.packageList = []
    this.packagesCount = 0
    this.isLoading = true
    this.packageListSubscription = this.upcomingPackagesService
      .getPackageListInfo({ institutionId: 'IID-CA-00637' })
      .subscribe(packageList => {
        const { packages = [] } = packageList
        this.isLoading = false
        if (packages.length > 0) {
          this.packagesCount = packages.length
          this.loadPackageDetails(JSON.parse(JSON.stringify(packages)))
        } else {
          this.systemError = true
        }
      })
  }

  ngOnInit (): void {
    this.getUpcomingPackageList()
  }

  ngOnDestroy (): void {
    if (this.packageListSubscription !== undefined) {
      this.packageListSubscription.unsubscribe()
    }
  }
}
