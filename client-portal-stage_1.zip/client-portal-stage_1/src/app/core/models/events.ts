export interface IIdpEvents {
  idpEvents: IUpComingEvents;
}

export interface IUpComingEvents {
  upcoming: Events;
}

export class Events {
  idpEventId: string;
  cventEventId: string;
  idpEventName: string;
  idpEventType: string;
  idpEventCategory: string;
  idpEventCountry: string;
  idpEventStatus: string;
  startDate: string;
  endDate: string;
  city: string;
  language: string;
  timezone: string;
  description: string;
  destination: string;
  cventAccountId: string;
  fieldsToBeDisplayed: string;
  displayOnWebsites: string;
  participatingUniversities: string;
  eventVenue: string;
  eventRegistrationCount: number;
  eventParticipantCount: number;
  office: string;
  created: string;
  lastModified: string;
}

export interface VisitedBoothData {
  eventId: string;
  institutionId: string;
  studentProfileId: string;
  visitedBooth: boolean;
}