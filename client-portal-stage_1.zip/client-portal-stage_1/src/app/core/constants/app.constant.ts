const dev = 'https://api.clientportal.dev.idp.com/clientportal/';
const stg = 'https://api.clientportal.stg.idp.com/clientportal/';
const uat = 'https://api.clientportal.uat.idp.com/clientportal/';

export const Constants = {
    dev: {
        bookedEventsListAndSearch: dev + 'v1/bookedEventsListAndSearch',
        studentListAndSearch: dev + 'v1/studentListSearch',
        zoomLinks: dev + 'v1/zoomLinks',
        dashboardReports: dev + 'v1/dashboardReports',
        checkIn: dev + 'v1/clientCheckIn',
        visitedBoothData: dev + 'v1/studentVisitedBooth'
    },
    stg: {
        bookedEventsListAndSearch: stg + 'v1/bookedEventsListAndSearch',
        studentListAndSearch: stg + 'v1/studentListSearch',
        zoomLinks: stg + 'v1/zoomLinks',
        dashboardReports: stg + 'v1/dashboardReports',
        checkIn: stg + 'v1/clientCheckIn',
        visitedBoothData: stg + 'v1/studentVisitedBooth'
    },
    uat: {
        bookedEventsListAndSearch: uat + 'v1/bookedEventsListAndSearch',
        studentListAndSearch: uat + 'v1/studentListSearch',
        zoomLinks: uat + 'v1/zoomLinks',
        dashboardReports: uat + 'v1/dashboardReports',
        checkIn: uat + 'v1/clientCheckIn',
        visitedBoothData: uat + 'v1/studentVisitedBooth'
    }
}