import { Directive } from '@angular/core'
import { MAT_DATE_FORMATS } from '@angular/material/core'
import { yearDateFormat } from 'src/app/core/constants/upcoming-packages.constant'

@Directive({
  selector: '[yearCalendar]',
  providers: [{ provide: MAT_DATE_FORMATS, useValue: yearDateFormat }]
})
export class YearDirective {}
