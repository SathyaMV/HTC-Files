import { ComponentFixture, TestBed } from '@angular/core/testing'

import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { PackagesDashboardComponent } from './packages-dashboard.component'
import { UpcomingPackagesService } from '../../../../core/services/upcoming-packages.service'
import { HttpClientTestingModule } from '@angular/common/http/testing'
import { of } from 'rxjs'
import * as mockPackageListData from '../../../../../assets/json/package-list.json'

describe('PackagesDashboardComponent', () => {
  let fixture: ComponentFixture<PackagesDashboardComponent>
  let component: PackagesDashboardComponent
  let service: UpcomingPackagesService

  beforeEach(async () => {
    const MockServiceStub: Partial<UpcomingPackagesService> = {
      getPackageListInfo: jest.fn().mockImplementation(() => of([]))
    }
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [PackagesDashboardComponent],
      providers: [{ provide: UpcomingPackagesService, useValue: MockServiceStub }],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents()
  })

  beforeEach(() => {
    service = TestBed.inject(UpcomingPackagesService)
    fixture = TestBed.createComponent(PackagesDashboardComponent)
    component = fixture.componentInstance
    fixture.detectChanges()
  })

  it('should create a component', () => {
    expect(component).toBeTruthy()
  })

  it('should return package list info when getUpcomingPackageList is called', async () => {
    const mockAPIResponseData = JSON.parse(JSON.stringify(mockPackageListData))
    jest.spyOn(service, 'getPackageListInfo').mockReturnValue(of(mockAPIResponseData))
    component.getUpcomingPackageList()
    expect(component.packageList.length).toBeGreaterThan(0)
  })

  it('should get package status info when getPackageStatus method is called', async () => {
    let result = component.getPackageStatus('published')
    expect(result).toEqual('Book Now')
    result = component.getPackageStatus('booked')
    expect(result).toEqual('Booked')
    result = component.getPackageStatus('soldout')
    expect(result).toEqual('Sold Out')
    result = component.getPackageStatus('unknown')
    expect(result).toEqual('unknown')
  })

  it('should return country code when getDestinationCountryCode method is called', async () => {
    let result = component.getDestinationCountryCode('Australia')
    expect(result).toEqual('AU')
    result = component.getDestinationCountryCode('New Zealand')
    expect(result).toEqual('NZ')
    result = component.getDestinationCountryCode('United States')
    expect(result).toEqual('US')
    result = component.getDestinationCountryCode('United Kingdom')
    expect(result).toEqual('UK')
    result = component.getDestinationCountryCode('Canada')
    expect(result).toEqual('CA')
    result = component.getDestinationCountryCode('Ireland')
    expect(result).toEqual('IE')
    result = component.getDestinationCountryCode('India')
    expect(result).toEqual('India')
  })
})
