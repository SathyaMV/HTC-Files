import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ReactiveFormsModule } from '@angular/forms'
import { MatSelectModule } from '@angular/material/select'
import { MatCheckboxModule } from '@angular/material/checkbox'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatTabsModule } from '@angular/material/tabs'
import { MatIconModule } from '@angular/material/icon'
import { MatBadgeModule } from '@angular/material/badge'
import { MatCardModule } from '@angular/material/card'
import { MatButtonModule } from '@angular/material/button'
import { CdkAccordionModule } from '@angular/cdk/accordion'
import { MatExpansionModule } from '@angular/material/expansion'
import { MatListModule } from '@angular/material/list'
import { MatDatepickerModule } from '@angular/material/datepicker'
import { MatInputModule } from '@angular/material/input'
import { UpcomingPackagesRoutingModule } from './upcoming-packages-routing.module'
import { PackagesDashboardComponent } from './packages-dashboard/packages-dashboard.component'
import { PackagesFilterComponent } from './packages-filter/packages-filter.component'
import {
  DateAdapter,
  MatNativeDateModule,
  MAT_DATE_LOCALE
} from '@angular/material/core'
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS
} from '@angular/material-moment-adapter'
import { UpcomingPackagesService } from '../../../core/services/upcoming-packages.service'
import { MonthYearDirective } from '../../../shared/directives/month-year.directive'
import { YearDirective } from '../../../shared/directives/year.directive'
import { SharedModule } from 'src/app/shared.module'

@NgModule({
  declarations: [PackagesDashboardComponent, PackagesFilterComponent, MonthYearDirective, YearDirective],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    UpcomingPackagesRoutingModule,
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatTabsModule,
    MatIconModule,
    MatBadgeModule,
    CdkAccordionModule,
    MatExpansionModule,
    MatListModule,
    MatBadgeModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    SharedModule
  ],
  providers: [
    UpcomingPackagesService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    }
  ]
})
export class UpcomingPackagesModule { }
