import { ComponentFixture, TestBed } from '@angular/core/testing'
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms'
import { UpcomingPackagesService } from '../../../../core/services/upcoming-packages.service'
import { of, Subscription } from 'rxjs'
import { MatSelectModule } from '@angular/material/select'
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'

import { PackagesFilterComponent } from './packages-filter.component'
import { MatDatepickerModule } from '@angular/material/datepicker'
import _rollupMoment, * as _moment from 'moment'
import { FilterOption } from '../../../../core/models/upcoming-packages.model'
const moment = _rollupMoment || _moment

describe('PackagesFilterComponent', () => {
  let component: PackagesFilterComponent
  let fixture: ComponentFixture<PackagesFilterComponent>
  let mockSubscription: Subscription
  const filterData: FilterOption = {
    regionOptions: [{ label: 'Region1', value: 'region1' }],
    countryOptions: [{ label: 'Country1', value: 'country1', region: 'region1' }],
    groupOptions: [{ label: 'Group1', value: 'group1' }]
  }
  const filterServiceStub: Partial<UpcomingPackagesService> = {
    getFilterOptions: () => of(filterData)
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PackagesFilterComponent],
      imports: [
        MatSelectModule,
        MatOptionModule,
        BrowserAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        MatDatepickerModule,
        MatNativeDateModule
      ],
      providers: [
        { provide: UpcomingPackagesService, useValue: filterServiceStub }
      ]
    }).compileComponents()
  })

  beforeEach(() => {
    fixture = TestBed.createComponent(PackagesFilterComponent)
    component = fixture.componentInstance
    mockSubscription = new Subscription()
    fixture.detectChanges()
  })

  it('should create', () => {
    expect(component).toBeTruthy()
  })

  it('should initialize the form with empty values', () => {
    expect(component.form.value).toEqual({
      selectedRegion: [],
      selectedCountry: [],
      selectedGroup: []
    })
  })

  it('should select and unselect all regions', () => {
    component.regionOptions = [
      { label: 'Region1', value: 'region1' },
      { label: 'Region2', value: 'region2' }
    ]
    component.form = new FormGroup({ selectedRegion: new FormControl() })
    fixture.detectChanges()
    component.onSelectAllRegion()
    expect(component.form.value.selectedRegion).toEqual(['region1', 'region2'])
    component.onClearAllRegion()
    expect(component.form.value.selectedRegion).toEqual([])
  })

  it('should select and unselect all countries', () => {
    component.countryOptions = [
      { label: 'Country1', value: 'country1', region: 'region1' },
      { label: 'Country2', value: 'country2', region: 'region2' }
    ]
    component.form = new FormGroup({ selectedCountry: new FormControl() })
    fixture.detectChanges()
    component.onSelectAllCountry()
    expect(component.form.value.selectedCountry).toEqual([
      'country1',
      'country2'
    ])
    component.onClearAllCountry()
    expect(component.form.value.selectedCountry).toEqual([])
  })

  it('should select and unselect all groups', () => {
    component.groupOptions = [
      { label: 'Group1', value: 'group1' },
      { label: 'Group2', value: 'group2' }
    ]
    component.form = new FormGroup({ selectedGroup: new FormControl() })
    fixture.detectChanges()
    component.onSelectAllGroup()
    expect(component.form.value.selectedGroup).toEqual(['group1', 'group2'])
    component.onClearAllGroup()
    expect(component.form.value.selectedGroup).toEqual([])
  })

  it('should clear all filters', () => {
    component.form = new FormGroup({
      selectedRegion: new FormControl(['region1']),
      selectedCountry: new FormControl(['country1']),
      selectedGroup: new FormControl(['group1'])
    })
    fixture.detectChanges()

    component.clearFilters()
    expect(component.form.value).toEqual({
      selectedRegion: null,
      selectedCountry: null,
      selectedGroup: null
    })
  })

  it('should set date control year to normalized year', () => {
    const normalizedYear = moment()
    component.date.setValue(moment())
    component.chosenYearHandler(normalizedYear)
    expect(component.date.value.year()).toEqual(normalizedYear.year())
  })

  it('should decrease the month of date value when current month is greater than the minimum month', () => {
    const mockDate = moment('2023-08-27')
    component.date.setValue(mockDate)
    component.minDate = new Date()
    component.previousMonth()
    expect(component.date.value.month()).toBeGreaterThanOrEqual(component.minDate.getMonth())
  })

  it('should not change the month of date value when current month is equal to the minimum month', () => {
    const mockDate = moment()
    component.date.setValue(mockDate)
    component.minDate = new Date()
    component.previousMonth()
    expect(component.date.value.month()).toEqual(component.minDate.getMonth())
  })

  it('should not change the month of date value when current year is lesser than the minimum year', () => {
    const mockDate = moment()
    component.date.setValue(mockDate)
    component.minDate = new Date()
    component.previousMonth()
    expect(component.date.value.year()).toBeGreaterThanOrEqual(component.minDate.getFullYear())
  })

  it('shhould increase the month value by 1', () => {
    const mockDate = moment('2023-04-27')
    component.date.setValue(mockDate)
    component.minDate = new Date()
    component.nextMonth()
    expect(component.date.value.month()).toBeGreaterThan(component.minDate.getMonth())
  })

  it('should decrease the year by 1 if it is greater than minDate year', () => {
    component.minDate = new Date()
    component.year.setValue(moment('2025-01-01'))
    component.previousYear()
    expect(component.year.value.year()).toBeGreaterThan(component.minDate.getFullYear())
  })

  it('should not decrease the year if it is equal to minDate year', () => {
    component.minDate = new Date()
    component.year.setValue(moment('2023-01-01'))
    component.previousYear()
    expect(component.year.value.year()).toEqual(component.minDate.getFullYear())
  })

  it('shhould increase the year value by 1', () => {
    const mockDate = moment()
    component.year.setValue(mockDate)
    component.minDate = new Date()
    component.nextYear()
    expect(component.year.value.year()).toBeGreaterThanOrEqual(component.minDate.getFullYear())
  })

  it('should unsubscribe from filterSubscription', () => {
    component.filterSubscription = mockSubscription
    const unsubscribeSpy = jest.spyOn(component.filterSubscription, 'unsubscribe')
    component.ngOnDestroy()
    expect(unsubscribeSpy).toHaveBeenCalled()
  })
})
