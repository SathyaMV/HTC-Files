import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookedEventsComponent } from './booked-events/booked-events.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxPaginationModule } from 'ngx-pagination';
import { EventsRoutingModule } from './events-routing.module';
import { EventsOverviewDashboardComponent } from './events-overview-dashboard/events-overview-dashboard.component';
import { EventsOverviewComponent } from './events-overview/events-overview.component';
import { MatOptionModule } from '@angular/material/core';
import { StudyLevelComponent } from './dashboard-reports/study-level/study-level.component';
import { EducationComponent } from './dashboard-reports/education/education.component';
import { PlanToStudyComponent } from './dashboard-reports/plan-to-study/plan-to-study.component';
import { StudyDestinationComponent } from './dashboard-reports/study-destination/study-destination.component';
import { NoDataComponent } from './dashboard-reports/no-data/no-data.component';
import { NgChartsModule } from 'ng2-charts';
import { SharedModule } from 'src/app/shared.module';

@NgModule({
  declarations: [
    BookedEventsComponent,
    EventsOverviewComponent,
    EventsOverviewDashboardComponent,
    StudyLevelComponent,
    EducationComponent,
    PlanToStudyComponent,
    StudyDestinationComponent,
    NoDataComponent,
  ],
  imports: [
    SharedModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatTabsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    HttpClientModule,
    NgxPaginationModule,
    EventsRoutingModule,
    MatOptionModule,
    NgChartsModule
  ]
})
export class EventsModule { }
