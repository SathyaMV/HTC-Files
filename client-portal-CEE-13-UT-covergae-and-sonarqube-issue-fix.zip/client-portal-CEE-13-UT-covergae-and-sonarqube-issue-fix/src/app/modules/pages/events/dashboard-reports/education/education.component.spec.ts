import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Chart } from 'chart.js';
import { NgChartsModule } from 'ng2-charts';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { EducationComponent } from './education.component';

describe('EducationComponent', () => {
  let component: EducationComponent;
  let fixture: ComponentFixture<EducationComponent>;
  let service: EventsService;
  const educationData = [
    { option: 'High School', count: 0 },
    { option: "Master's Degree", count: 0 },
    { option: 'Doctorate Degree', count: 0 },
    { option: 'Diploma', count: 0 },
    { option: "Bachelor's Degree", count: 1 },
    { option: 'Other', count: 0 },
    { option: 'missing', count: 17 }
  ];
  var isMissing = false;
  const context: any = {
    chart: {}, replay: undefined, tooltip: {
      caretX: 240.97223756735326, caretY: 86.12222873703487, opacity: 0, dataPoints: [
        {
          dataIndex: 1
        }
      ]
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [NgChartsModule, HttpClientTestingModule],
      declarations: [EducationComponent],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    service = TestBed.inject(EventsService);

    fixture = TestBed.createComponent(EducationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `setHigestEducation`', () => {
    jest.spyOn(component, 'setHigestEducation');
    component.setHigestEducation();
    component.educationData = educationData;
    component.isMissing = isMissing;
    component.count.push(educationData[6].count);
    component.setHigestEducation();
    expect(component.educationData[6].option == 'missing').toBeTruthy();
    if (component.educationData[6].option == 'missing') {
      component.isMissing = true;
      expect(component.isMissing).toBeTruthy();
    }
  });

  it('Should call `getwindowidth`', () => {
    jest.spyOn(component, 'getwindowidth');
    component.getwindowidth();
    component.scrWidth = 1500;
    expect(component.scrWidth).toBeGreaterThan(1200);
    if (component.scrWidth > 1200) {
      Chart.defaults.datasets.bar.barThickness = 54;
      Chart.overrides.doughnut.cutout = 50
    }
    component.getwindowidth();
  });

  it('Should call `customTooltip`', () => {
    jest.spyOn(service, 'customTooltip').mockReturnValue(of('') as any);
    service.customTooltip(context, 4, [4,1,3]);
  });

});
