import { Component, OnInit, Input } from '@angular/core';
import { ChartConfiguration, ChartOptions, Chart } from 'chart.js';
import { Dashboard } from 'src/app/core/models/events-overview-dashboard';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {

  scrWidth = window.innerWidth;
  @Input() educationData: Dashboard[];
  count: any = [];
  isMissing: boolean = false;
  highestEducation: any;

  constructor(public eventsService : EventsService) { }

  ngOnInit(): void {
    this.getwindowidth();
    this.setHigestEducation();
  }

  setHigestEducation(): void {
    for (let i = 0; i < this.educationData?.length; i++) {
      this.count.push(this.educationData[i].count);
      if (this.educationData[i].option == 'missing')
        this.isMissing = true;
    }
    if (this.isMissing)
      this.barChartData.labels.push('missing')

    this.barChartData.datasets[0].data = this.count;
  }

  getwindowidth(): void {
    if (this.scrWidth < 1200) {
      Chart.defaults.datasets.bar.barThickness = 20;
      this.barChartOptions.indexAxis = 'y';
    } else {
      Chart.defaults.datasets.bar.barThickness = 54;
      Chart.overrides.doughnut.cutout = 50
    }
  }

  barChartData: ChartConfiguration['data'] = {
    labels: ["High School", "Masters", "Doctorate", "Diploma", "Bachelors", "Other"],
    datasets: [
      { data: [], backgroundColor: '#E11937', hoverBackgroundColor: '#E11937' }
    ],
  };
  public barChartOptions: ChartOptions = {
    maintainAspectRatio: false,
    indexAxis: 'x',
    plugins: {
      tooltip: {
        enabled: false,
        external: (context) => {
          this.eventsService.customTooltip(context, 4, this.count);
        }
      }
    },
    scales: {
      x: {
        ticks: {
          padding: 10,
          color: '#000',
          font: {
            family: "BuenosAires-Regular",
            size: 12
          },
          callback: function (label, index) {
            var label_val = this.getLabelForValue(index);
            if (window.innerWidth < 1200) {
              return '';
            } else {
              return label_val;
            }
          }
        },
        grid: {
          drawOnChartArea: false,
          drawTicks: false,
          borderWidth: 0
        }
      },
      y: {
        ticks: {
          padding: 10,
          display: true,
          color: '#000',
          font: {
            family: "BuenosAires-Regular",
            size: 12
          },
          callback: function (label, index) {
            var label_val = this.getLabelForValue(index);
            if (window.innerWidth < 1200) {
              return label_val;
            } else {
              return '';
            }
          }
        },
        grid: {
          display: false,
          drawBorder: false,
        }
      }
    }
  };
}
