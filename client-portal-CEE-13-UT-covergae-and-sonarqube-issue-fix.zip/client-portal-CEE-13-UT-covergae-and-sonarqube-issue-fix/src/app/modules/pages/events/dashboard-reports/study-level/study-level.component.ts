import { Component, OnInit, Input } from '@angular/core';
import { ChartConfiguration, Chart } from 'chart.js';
import { Dashboard } from 'src/app/core/models/events-overview-dashboard';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-study-level',
  templateUrl: './study-level.component.html',
  styleUrls: ['./study-level.component.css']
})
export class StudyLevelComponent implements OnInit {

  scrWidth = window.innerWidth;
  @Input() studyLevelData: Dashboard[];
  @Input() registrantsData: number;
  percentages: any = [];
  countWithPercentage: any = [];
  isMissing: boolean = false;

  constructor(public eventsService : EventsService) { }

  ngOnInit(): void {
    this.getwindowidth();
    this.setStudyLevel();
  }

  setStudyLevel() {
    for (let i = 0; i < this.studyLevelData?.length; i++) {
      if (this.studyLevelData[i].count >= 1)
        this.studyLevelData[i]['percentage'] = Math.round(this.studyLevelData[i].count / this.registrantsData * 100 * 10) / 10;
    }
    for (let i = 0; i < this.studyLevelData?.length; i++) {
      this.percentages.push(this.studyLevelData[i].percentage ? this.studyLevelData[i].percentage : 0);
      this.countWithPercentage.push(this.studyLevelData[i].count + ', ' + this.studyLevelData[i].percentage + '%');
      if (this.studyLevelData[i].option == 'missing')
        this.isMissing = true;
    }
    this.doughnutChartDatasets[0].data = this.percentages;
    if (this.isMissing) {
      let colors = [
        '#FFD700',
        '#FF8300',
        '#E11937',
        '#008260',
        '#002382',
        '#820073',
        '#005f82',
        '#d314bd'
      ];
      this.doughnutChartDatasets[0].backgroundColor = colors;
    }
  }

  getwindowidth() {
    if (this.scrWidth < 1200) {
      return;
    } else {
      Chart.overrides.doughnut.cutout = 50
    }
  }
  public doughnutChartDatasets: ChartConfiguration<'doughnut'>['data']['datasets'] = [
    {
      data: [],
      backgroundColor: [
        '#FFD700',
        '#FF8300',
        '#E11937',
      ],
      borderWidth: 0
    }
  ];

  public doughnutChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        enabled: false,
        external: (context) => {
          this.eventsService.customTooltip(context, 3, this.countWithPercentage);
        }
      }
    },
  };
}
