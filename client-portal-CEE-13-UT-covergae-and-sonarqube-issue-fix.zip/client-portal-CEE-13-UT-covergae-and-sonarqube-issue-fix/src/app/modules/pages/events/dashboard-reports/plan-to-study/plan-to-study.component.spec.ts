import { APP_BASE_HREF } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Chart } from 'chart.js';
import { NgChartsModule } from 'ng2-charts';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { PlanToStudyComponent } from './plan-to-study.component';

describe('PlanToStudyComponent', () => {
  let component: PlanToStudyComponent;
  let fixture: ComponentFixture<PlanToStudyComponent>;
  let service: EventsService;
  const planToStudyData = [
    { option: 'withinSixMonths', count: 2 },
    { option: 'sixMonthsToOneYear', count: 2 },
    { option: 'oneYearToTwoYears', count: 1 },
    { option: 'twoPlusYears', count: 0 },
    { option: 'missing', count: 13 }
  ];
  var isMissing = false;
  const context: any = {
    chart: {}, replay: undefined, tooltip: {
      caretX: 240.97223756735326, caretY: 86.12222873703487, opacity: 0, dataPoints: [
        {
          dataIndex: 1
        }
      ]
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [NgChartsModule, HttpClientTestingModule],
      declarations: [
        PlanToStudyComponent
      ],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    })
      .compileComponents();
    service = TestBed.inject(EventsService);

    fixture = TestBed.createComponent(PlanToStudyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `setPlanToStudy`', () => {
    jest.spyOn(component, 'setPlanToStudy');
    component.setPlanToStudy();
    component.planToStudyData = planToStudyData;
    component.isMissing = isMissing;
    component.count.push(planToStudyData[0].count);
    component.setPlanToStudy();
    expect(component.planToStudyData[4].option == 'missing').toBeTruthy();
    if (component.planToStudyData[4].option == 'missing') {
      component.isMissing = true;
      expect(component.isMissing).toBeTruthy();
    }
  });

  it('Should call `getwindowidth`', () => {
    jest.spyOn(component, 'getwindowidth');
    component.getwindowidth();
    component.scrWidth = 1500;
    expect(component.scrWidth).toBeGreaterThan(1200);
    if (component.scrWidth > 1200) {
      Chart.defaults.datasets.bar.barThickness = 98;
    }
    component.getwindowidth();
    // component.barChartOptions.plugins.tooltip.external(context);
  });

  it('Should call `customTooltip`', () => {
    jest.spyOn(service, 'customTooltip').mockReturnValue(of('') as any);
    service.customTooltip(context, 2, '3,30%');
  });

});
