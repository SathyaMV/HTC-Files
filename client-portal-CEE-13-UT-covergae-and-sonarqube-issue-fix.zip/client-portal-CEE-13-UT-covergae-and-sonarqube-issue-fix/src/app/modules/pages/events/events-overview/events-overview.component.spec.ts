import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPaginationModule } from 'ngx-pagination';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { LoaderIconComponent } from 'src/app/shared/components/loader-icon/loader-icon.component';
import { NoDataComponent } from '../dashboard-reports/no-data/no-data.component';
import { EventsOverviewDashboardComponent } from '../events-overview-dashboard/events-overview-dashboard.component';
import { EventsRoutingModule } from '../events-routing.module';

import { EventsOverviewComponent } from './events-overview.component';
import { Utils } from 'src/app/core/utils/utils';

describe('EventsOverviewComponent', () => {
  let component: EventsOverviewComponent;
  let fixture: ComponentFixture<EventsOverviewComponent>;
  let service: EventsService;
  let eventOverviewDetail = [
    {
      idpEventId: 'd042e02b-bc1f-4332-8da1-58e2d98c2021',
      idpEventName: 'KT Event creation',
      idpEventType: 'Virtual',
      idpEventCountry: 'IN - India',
      startDate: '2023-04-02T13:30:00.000',
      endDate: '2023-04-14T00:30:00.000', eventVenue: ''
    }
  ]
  let studentList = [
    {
      eventId: '1264b65d-780e-4ceb-a561-8c009e445eb0',
      institutionId: 'IID-CA-00640',
      studentProfileId: '13f3aa4f-3e6d-480a-92b4-1f7d5d304bec',
      visitedBooth: true
    }
  ]

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EventsOverviewComponent, EventsOverviewDashboardComponent, LoaderIconComponent, NoDataComponent],
      imports: [
        BrowserModule.withServerTransition({ appId: "serverApp" }),
        CommonModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        EventsRoutingModule,
        MatTabsModule,
        MatFormFieldModule,
        MatSelectModule,
        MatAutocompleteModule,
        MatInputModule,
        MatButtonModule,
        NgxPaginationModule,
        MatOptionModule,
        FormsModule
      ],
      providers: [EventsService, Utils,
        { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    service = TestBed.inject(EventsService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventsOverviewComponent);
    component = fixture.componentInstance;
    component.eventOverviewDetail = eventOverviewDetail;
    window.sessionStorage.setItem('eventOverviewDetail', JSON.stringify(eventOverviewDetail));
    component.studentsList = studentList;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `ngOnInit`', () => {
    window.sessionStorage.setItem('eventOverviewDetail', JSON.stringify(eventOverviewDetail));
    component.ngOnInit();
  });

  it('Should call `getAllZoomLinks`', () => {
    component.isLoading = true;
    jest.spyOn(service, 'getAllZoomLinks').mockReturnValue(of('') as any);
    component.getZoomLinks();
    expect(service.getAllZoomLinks).toHaveBeenCalled();
    component.isLoading = false;
  });

  it('Should call `getStudentsList`', () => {
    jest.spyOn(service, 'getAllStudents').mockReturnValue(of('') as any);
    component.getStudentsList();
    expect(service.getAllStudents).toHaveBeenCalled();
  });

  it('Should call `onTabClick`', () => {
    jest.spyOn(component, 'getStudentsList');
    jest.spyOn(component, 'getZoomLinks');
    const event = {
      tab: {
        textLabel: 'Student records'
      }
    };
    component.onTabClick(event);
    component.tabChanged = event.tab.textLabel;
    expect(component.tabChanged === 'Student records').toBeTruthy();
    expect(component.tabChanged === 'Zoom links').toBeFalsy();
    expect(component.getStudentsList).toHaveBeenCalled();
    expect(component.getZoomLinks).not.toHaveBeenCalled();
  });

  it('Should call `onTabClick` Zoom links tab tobe TRUE', () => {
    jest.spyOn(component, 'getStudentsList');
    jest.spyOn(component, 'getZoomLinks');
    const event = {
      tab: {
        textLabel: 'Zoom links'
      }
    };
    component.onTabClick(event);
    component.tabChanged = event.tab.textLabel;
    expect(component.tabChanged === 'Zoom links').toBeTruthy();
    expect(component.tabChanged === 'Student records').toBeFalsy();
    expect(component.getStudentsList).not.toHaveBeenCalled();
    expect(component.getZoomLinks).toHaveBeenCalled();
  });

  it('Should call `isCheckedInOrNot`', () => {
    component.isCheckedIn = false;
    component.isCheckedInOrNot(false);
  });

  it('Should call `getCheckIn`', () => {
    jest.spyOn(service, 'getCheckIn').mockReturnValue(of('') as any);
    component.getCheckIn();
    expect(service.getCheckIn).toHaveBeenCalled();
  });

  it('Should call `getPagination`', () => {
    jest.spyOn(component, 'getPagination');
    component.getPagination(1, 12);
    expect(component.getPagination).not.toEqual("Showing 1 to 10 of 12");
  });

  it('Should call `renderPage`', () => {
    const pageNumber = 1;
    jest.spyOn(component, 'getStudentsList');
    jest.spyOn(service, 'getAllStudents').mockReturnValue(of('') as any);
    component.renderPage(pageNumber);
    component.pageNumber = 1;
    expect(component.pageNumber).toBe(1);
    expect(component.isPagination).toBe(true);
    component.getStudentsList();
    expect(service.getAllStudents).toHaveBeenCalled();
  });

  it('should scroll to top', () => {
    document.body.innerHTML = '<div id="studentsRecords"></div>';
    const scrollIntoViewMock = jest.fn();
    HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;
    component.scrollTop();
    expect(scrollIntoViewMock).toHaveBeenCalledWith({ behavior: "smooth" });
  });

  it('Should call `postStudentVisitedBooth`', () => {
    jest.spyOn(service, 'postStudentVisitedBooth').mockReturnValue(of('') as any);
    component.changeVisitedBooth(true);
    component.isLoading = true;
    expect(service.postStudentVisitedBooth).toHaveBeenCalled();
    component.isLoading = false;
  });

  it('Should call `onChange`', () => {
    jest.spyOn(component, 'getStudentsList');
    component.onChange();
    expect(component.getStudentsList).toHaveBeenCalled();
  });

  it('should call `postStudentVisitedBooth` status is TRUE', () => {
    const status = 200;
    jest.spyOn(service, 'postStudentVisitedBooth').mockReturnValue(of({ status } as any));
    component.changeVisitedBooth(true);
    expect(component.isLoading).toBe(true);
  });

  it('should call `getCheckIn` status is TRUE', () => {
    const status = 200;
    jest.spyOn(service, 'getCheckIn').mockReturnValue(of({ status } as any));
    component.getCheckIn();
    expect(component.isLoading).toBe(false);
  });

});
