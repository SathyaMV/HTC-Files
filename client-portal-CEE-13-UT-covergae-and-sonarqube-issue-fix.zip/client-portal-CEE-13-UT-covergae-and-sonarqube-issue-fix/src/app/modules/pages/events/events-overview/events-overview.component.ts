import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTabGroup } from '@angular/material/tabs';
import { EventsService } from 'src/app/core/services/events.service';
import { Utils } from 'src/app/core/utils/utils';

@Component({
  selector: 'app-events-overview',
  templateUrl: './events-overview.component.html',
  styleUrls: ['./events-overview.component.css', './zoomlink.css']
})
export class EventsOverviewComponent implements OnInit {

  @ViewChild('matTabGroup', { static: false }) matTabGroup!: MatTabGroup;
  eventOverviewDetail = [];
  isLoading = false;
  studentsList = [];
  itemsPerPage = 10;
  pageNumber = 1;
  tabChanged: string;
  zoomLinksList = [];
  params = { institutionId: 'IID-CA-00637', clientEmailId: 'test7@gmail.com', idpEventId: '2b749905-55b1-4637-ab93-47b5bff5bc75' };
  isCheckedIn = false;
  totalRecords: number;
  isPagination = false;
  labelValue: string;
  searchData: any = '';
  searchDefaultOption = 'email';

  constructor(private service: EventsService, private utils: Utils) { }

  ngOnInit(): void {
    this.eventOverviewDetail = JSON.parse(sessionStorage.getItem('eventOverviewDetail'));
    this.getSearchLabel(this.searchDefaultOption);
  }

  isCheckedInOrNot(checkIn: boolean): void {
    this.isCheckedIn = checkIn;
  }

  onTabClick(value: any) {
    this.tabChanged = value.tab.textLabel;
    if (this.tabChanged === 'Student records') {
      this.getStudentsList();
      return;
    }
    this.getZoomLinks();
  }

  getStudentsList(): void {
    const studentListData = {
      eventId: '1264b65d-780e-4ceb-a561-8c009e445eb0',
      pageNumber: this.pageNumber,
      institutionId: 'IID-CA-00640',
      pageSize: 10,
      searchBy: this.labelValue,
      searchValue: this.searchData
    };
    this.isLoading = true;
    this.service.getAllStudents(studentListData).subscribe((events: any) => {
      this.studentsList = events?.studentDetails ? events.studentDetails : [];
      this.totalRecords = events?.totalRecords ? events.totalRecords : 0;
      this.isLoading = false;
    });
  }

  getInitial(name: string) {
    const initial = name ? name.split(" ") : '';
    return initial ? initial[0].charAt(0).toUpperCase() + initial[1].charAt(0).toUpperCase() : '';
  }

  getZoomLinks(): void {
    this.isLoading = true;
    this.service.getAllZoomLinks(this.params).subscribe((zoomLinks: any) => {
      this.zoomLinksList = zoomLinks.zoomLinks;
      this.isLoading = false;
    });
  }

  getCheckIn(): void {
    this.isLoading = true;
    this.service.getCheckIn(this.params).subscribe((checkInValue: any) => {
      if (checkInValue.status === 200) {
        this.isLoading = false;
        this.isCheckedIn = true;
      }
    });
  }

  renderPage(event: number): void {
    this.isPagination = true;
    this.pageNumber = event;
    this.getStudentsList();
  }

  getPagination(pageNumber: number, length: number): string {
    let startValue = ((pageNumber - 1) * this.itemsPerPage) + 1;
    let endValue = pageNumber * this.itemsPerPage > length ? length : pageNumber * this.itemsPerPage;
    return `Showing ${startValue} to ${endValue} of ${length}`
  }

  getMobileNumber(mobileNumber: string) {
    return this.utils.getMobileNumber(mobileNumber);
  }

  getSearchLabel(value: string): void {
    this.labelValue = value;
    this.searchData = '';
    this.getStudentsList();
  }

  onChange(): void {
    this.getStudentsList();
  }

  changeVisitedBooth(visitedBooth: boolean): void {
    const visitedBoothData = {
      eventId: '1264b65d-780e-4ceb-a561-8c009e445eb0',
      institutionId: 'IID-CA-00640',
      studentProfileId: this.studentsList[0].studentProfileId,
      visitedBooth: visitedBooth
    };
    this.isLoading = true;
    this.service.postStudentVisitedBooth(visitedBoothData).subscribe((visitedBoothData: any) => {
      this.isLoading = false;
      if (visitedBoothData.status === 200) {
        this.isLoading = true;
      }
    });
  }

  scrollTop(): void {
    document.getElementById('studentsRecords').scrollIntoView({ behavior: "smooth" });
  }

}
