import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { EventType } from 'src/app/core/enums/enum';
import { EventsService } from 'src/app/core/services/events.service';
import { BookedEventsComponent } from './booked-events.component';
import { of } from 'rxjs';
import { EventsModule } from '../events.module';
import { EventsRoutingModule } from '../events-routing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { NgxPaginationModule } from 'ngx-pagination';
import { LoaderIconComponent } from 'src/app/shared/components/loader-icon/loader-icon.component';
import { FormsModule } from '@angular/forms';

describe('BookedEventsComponent', () => {
  let component: BookedEventsComponent;
  let fixture: ComponentFixture<BookedEventsComponent>;
  let service: EventsService;
  const upcomingEvents = [
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
  ];
  const pastEvents = [
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
    { endDate: "2023-03-31T14:00:00.000", eventVenue: "chennai", idpEventCountry: "IN - India", idpEventId: "5ecfef40-3483-42b8-9556-7d0aac4b0ba4", idpEventName: "Abu Dhabi Expo", idpEventType: "Virtual", startDate: "2023-02-01T10:00:00.000" },
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        BookedEventsComponent,
        LoaderIconComponent
      ],
      imports: [
        BrowserModule.withServerTransition({ appId: "serverApp" }),
        CommonModule,
        RouterTestingModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        EventsRoutingModule,
        MatTabsModule,
        MatFormFieldModule,
        MatSelectModule,
        MatAutocompleteModule,
        MatInputModule,
        MatButtonModule,
        NgxPaginationModule,
        MatOptionModule,
        FormsModule
      ],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    service = TestBed.inject(EventsService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BookedEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `getEventsList`', () => {
    jest.spyOn(service, 'getAllBookedEvents').mockReturnValue(of('') as any);
    component.getEventsList();
    expect(service.getAllBookedEvents).toHaveBeenCalled();
  });

  it('Should call `getEventTypeClass` if VIRTUAL is TRUE', () => {
    const param = EventType.VIRTUAL;
    jest.spyOn(component, 'getEventTypeClass');
    component.getEventTypeClass(param);
    expect(component.getEventTypeClass).toBeTruthy();
  });

  it('Should call `getEventTypeClass` if HYBRID is TRUE', () => {
    const param = EventType.HYBRID;
    jest.spyOn(component, 'getEventTypeClass');
    component.getEventTypeClass(param);
    expect(component.getEventTypeClass).toBeTruthy();
  });

  it('Should call `getEventTypeClass` if PHYSICAL is TRUE', () => {
    const param = EventType.PHYSICAL;
    jest.spyOn(component, 'getEventTypeClass');
    component.getEventTypeClass(param);
    expect(component.getEventTypeClass).toBeTruthy();
  });

  it('Should call `getPagination`', () => {
    jest.spyOn(component, 'getPagination');
    component.getPagination(1, 12);
    expect(component.getPagination).not.toEqual("Showing 1 to 10 of 12");
  });

  it('Should call `onTabClick`', () => {
    const event = {
      tab: {
        textLabel: 'Upcoming'
      }
    };
    jest.spyOn(component, 'onTabClick');
    component.onTabClick(event);
    component.tabChanged = event.tab.textLabel;
    expect(component.tabChanged === 'Upcoming').toBeTruthy();
    expect(component.tabChanged === 'Past').toBeFalsy();
  });

  it('Should call `renderPage` if Upcoming is TRUE', () => {
    const value = 'Upcoming';
    jest.spyOn(component, 'renderPage');
    component.renderPage(1, value);
    expect(component.renderPage).toBeTruthy();
  });

  it('Should call `renderPage` if Upcoming is FALSE', () => {
    const value = 'Past';
    jest.spyOn(component, 'renderPage');
    jest.spyOn(service, 'getAllBookedEvents').mockReturnValue(of('') as any);
    component.renderPage(1, value);
    component.pastPageNumber = 1;
    expect(component.pastPageNumber).toBe(1);
    component.getEventsList();
    expect(service.getAllBookedEvents).toHaveBeenCalled();
  });

  it('Should call `onChange`', () => {
    const strValue = 'ABC';
    const source = 'Upcoming';
    const searchEventName = 'ABC';
    jest.spyOn(component, 'onChange');
    component.onChange();
    component.searchValue = strValue;
    component.eventsListData['source'] = source;
    component.eventsListData['searchEventName'] = searchEventName;
    expect(component.searchValue.length >= 3).toBeTruthy();
    expect(component.eventsListData && typeof component.eventsListData === 'object').toBe(true);
    component.onChange();
    expect(component.eventsListData.source).toBe('Upcoming');
    expect(component.eventsListData.searchEventName).toBe('ABC');

    jest.spyOn(service, 'getAllBookedEvents').mockReturnValue(of('') as any);
    component.onChange();
    expect(service.getAllBookedEvents).toHaveBeenCalled();

    component.onChange();
    component.upComingEventsList = upcomingEvents;
    component.pastEventList = pastEvents;

  });

  it('Should call `eventOverViewPage`', () => {
    jest.spyOn(component, 'eventOverViewPage');
    const eventID = 'test-1234';
    component.eventOverViewPage(eventID);
    expect(component.eventOverViewPage).toHaveBeenCalledWith(eventID);
  });
  it('Should call `searchLengthCheck`', () => {
    component.searchLengthCheck();
    component.searchValue = 'AB';
    expect(component.searchValue.length < 3).toBeTruthy();
    component.onChange();
    expect(component.tabChanged == 'Upcoming').toBeTruthy();
    component.upComingEventsList = upcomingEvents;
    component.tabChanged = 'Past';
    component.onChange();
    expect(component.tabChanged == 'Past').toBeTruthy();
    component.pastEventList = pastEvents;
  });

  it('Should call `tabBasedDataset` tabChanged is Upcoming', () => {
    const upComingEvents = {
      status: 200,
      message: "Successful operation - 23 IDP Events found",
      idpEvents: {
        upcoming: [
          {
            idpEventId: "0b36322c-959b-4361-9a9d-4c6ff5718446",
            idpEventName: "Farzana - Invitee or guest modified",
            idpEventType: "Physical",
            idpEventCountry: "AE - United Arab Emirates",
            startDate: "2021-12-22T18:00:00.000",
            endDate: "2023-12-22T22:00:00.000",
            eventVenue: ""
          },
          {
            idpEventId: "d63c11bb-1ec5-443a-b82f-5c234a73869f",
            idpEventName: "VE - FB settings Event- Do not edit",
            idpEventType: "Virtual",
            idpEventCountry: "IN - India",
            startDate: "2021-07-01T18:00:00.000",
            endDate: "2023-07-31T23:59:00.000",
            eventVenue: ""
          }
        ],
        upcomingCount: 23
      }
    }
    component.tabChanged = 'Upcoming';
    component.isPagination = false;
    component.tabBasedDataset(upComingEvents);
    expect(component.upComingEventsList).toStrictEqual(upComingEvents.idpEvents.upcoming);
    expect(component.totalUpcomingItems).toStrictEqual(upComingEvents.idpEvents.upcomingCount);
    expect(component.orgUpcomingList).toStrictEqual(upComingEvents.idpEvents.upcoming);
    expect(component.orgUpcomingCount).toStrictEqual(upComingEvents.idpEvents.upcomingCount);
  });

  it('Should call `tabBasedDataset tabChanged is Past`', () => {
    const pastBookedEvents = {
      status: 200,
      message: "Successful operation - 28 IDP Events found",
      idpEvents: {
        past: [
          {
            idpEventId: "25a34a8d-9207-43b7-b8f5-5f66f1fd7f04",
            idpEventName: "Copy of DEV - Event ongoing 2",
            idpEventType: "Physical",
            idpEventCountry: "IN - India",
            startDate: "2023-03-21T13:00:00.000",
            endDate: "2023-03-21T14:36:00.000",
            eventVenue: ""
          },
          {
            idpEventId: "29b6318b-7cb2-4165-8ea8-c7821435fa6b",
            idpEventName: "E2E Test, Physical India Event, Australia & New Zealand Destination_Jan30",
            idpEventType: "Physical",
            idpEventCountry: "CA - Canada",
            startDate: "2023-02-03T00:15:00.000",
            endDate: "2023-02-17T08:15:00.000",
            eventVenue: "Taj"
          }
        ],
        pastCount: 28
      }
    }
    component.tabChanged = 'Past';
    component.isPagination = false;
    component.tabBasedDataset(pastBookedEvents);
    expect(component.pastEventList).toStrictEqual(pastBookedEvents.idpEvents.past);
    expect(component.totalPastItems).toStrictEqual(pastBookedEvents.idpEvents.pastCount);
    expect(component.orgPastList).toStrictEqual(pastBookedEvents.idpEvents.past);
    expect(component.orgPastCount).toStrictEqual(pastBookedEvents.idpEvents.pastCount);
  });

  it('Should call `searchDataSet tabChanged is Past`', () => {
    const pastBookedEvents = {
      status: 200,
      message: "Successful operation - 28 IDP Events found",
      idpEvents: {
        past: [
          {
            idpEventId: "25a34a8d-9207-43b7-b8f5-5f66f1fd7f04",
            idpEventName: "Copy of DEV - Event ongoing 2",
            idpEventType: "Physical",
            idpEventCountry: "IN - India",
            startDate: "2023-03-21T13:00:00.000",
            endDate: "2023-03-21T14:36:00.000",
            eventVenue: ""
          },
          {
            idpEventId: "29b6318b-7cb2-4165-8ea8-c7821435fa6b",
            idpEventName: "E2E Test, Physical India Event, Australia & New Zealand Destination_Jan30",
            idpEventType: "Physical",
            idpEventCountry: "CA - Canada",
            startDate: "2023-02-03T00:15:00.000",
            endDate: "2023-02-17T08:15:00.000",
            eventVenue: "Taj"
          }
        ],
        pastCount: 28
      }
    }
    component.tabChanged = 'Past';
    component.searchDataSet(pastBookedEvents);
    expect(component.pastEventList).toStrictEqual(pastBookedEvents.idpEvents.past);
    expect(component.totalPastItems).toStrictEqual(pastBookedEvents.idpEvents.pastCount);
    expect(component.pastPageNumber).toStrictEqual(1);
  });

  it('should scroll to top Upcoming when value is valid', () => {
    document.body.innerHTML = '<div id="listTopUpcoming"></div>';
    const scrollIntoViewMock = jest.fn();
    HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;
    component.scrollTop('upcoming');
    expect(scrollIntoViewMock).toHaveBeenCalledWith({ behavior: "smooth" });
  });

  it('should scroll to top Past when value is Valid', () => {
    document.body.innerHTML = '<div id="listTopPast"></div>';
    const scrollIntoViewMock = jest.fn();
    HTMLElement.prototype.scrollIntoView = scrollIntoViewMock;
    component.scrollTop('Past');
    expect(scrollIntoViewMock).toHaveBeenCalledWith({ behavior: "smooth" });
  });

});

