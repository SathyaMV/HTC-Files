import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgChartsModule } from 'ng2-charts';
import { of } from 'rxjs';
import { EventsService } from 'src/app/core/services/events.service';
import { EventsModule } from '../events.module';

import { EventsOverviewDashboardComponent } from './events-overview-dashboard.component';

describe('EventsOverviewDashboardComponent', () => {
  let component: EventsOverviewDashboardComponent;
  let fixture: ComponentFixture<EventsOverviewDashboardComponent>;
  let service: EventsService;
  const educationData = { option: 'High School', count: 0, percentage: 0 };
  const planToStudyData = { option: 'withinSixMonths', count: 2, percentage: 1 };
  const destinationData = { option: 'Australia', count: 3, percentage: 16.7 };
  const studyLevelData = { option: 'English Language', count: 1, percentage: 5.6 };
  const registrantsData = 0;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EventsOverviewDashboardComponent],
      imports: [
        BrowserModule.withServerTransition({ appId: "serverApp" }),
        CommonModule,
        HttpClientTestingModule,
        NoopAnimationsModule,
        EventsModule,
        NgChartsModule
      ],
      providers: [EventsService,
        { provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
    service = TestBed.inject(EventsService);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventsOverviewDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call `getAllDashboardData`', () => {
    jest.spyOn(service, 'getAllDashboardData').mockReturnValue(of('') as any);
    component.getAllDashboardData();
    expect(service.getAllDashboardData).toHaveBeenCalled();
    component.destinationData = destinationData;
    component.educationData = educationData;
    component.studyLevelData = studyLevelData;
    component.planToStudyData = planToStudyData;
    component.registrantsData = registrantsData;
  });
});
