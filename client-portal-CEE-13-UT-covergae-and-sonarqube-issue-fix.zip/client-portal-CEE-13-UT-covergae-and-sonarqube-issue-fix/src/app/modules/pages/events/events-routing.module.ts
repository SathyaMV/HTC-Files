import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookedEventsComponent } from './booked-events/booked-events.component';
import { EventsOverviewComponent } from './events-overview/events-overview.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', component: BookedEventsComponent },
      { path: 'events-overview', component: EventsOverviewComponent }
    ],
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventsRoutingModule { }
