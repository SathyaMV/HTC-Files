import { YearDirective } from './year.directive';

describe('YearDirective', () => {
  it('should create an instance', () => {
    const directive = new YearDirective();
    expect(directive).toBeTruthy();
  });
});
