import { Injectable } from "@angular/core";

@Injectable()
export class Utils {
    getMobileNumber(mobileNumber: string): string {
        let numberWithAsterisk = '';
        if (mobileNumber != null) {
            let removeSpace = mobileNumber.split(" ").join("")
            if (mobileNumber.includes('+') && mobileNumber.includes(' ') && mobileNumber.length > 7) {
                numberWithAsterisk = mobileNumber.substr(0, 7) + '***' + mobileNumber.substr(mobileNumber.length - 3)
            } else if (/^\d+$/.test(removeSpace) && removeSpace.length > 7) {
                numberWithAsterisk = mobileNumber.substr(0, 5) + '***' + mobileNumber.substr(mobileNumber.length - 3)
            } else if (mobileNumber == null || mobileNumber == "") {
                numberWithAsterisk = "";
            } else if (removeSpace.includes('+')) {
                numberWithAsterisk = mobileNumber;
            }
        }
        return numberWithAsterisk;
    }
}