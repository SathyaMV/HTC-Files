import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, catchError, Observable, retry, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Events, VisitedBoothData } from '../models/events';

@Injectable({
  providedIn: 'root'
})
export class EventsService {

  constructor(private http: HttpClient) { }

  public showLoaderIcon = new BehaviorSubject(false);

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
    }),
  };

  getAllBookedEvents(bookedEvents: { clientId: string; institutionId: string; pageNumber: number; pageSize?: number; source: string; searchEventName: string; }): Observable<Events> {
    return this.http
      .get<Events>(environment.bookedEventsListAndSearch, { params: bookedEvents })
      .pipe(retry(1), catchError(this.errorHandler));
  }

  getAllStudents(studentList: { eventId: string; institutionId: string; pageNumber: number; pageSize?: number; searchBy: string; searchValue: string; }): Observable<Events> {
    return this.http
      .get<Events>(environment.studentListAndSearch, { params: studentList })
      .pipe(retry(1), catchError(this.errorHandler));
  }

  getAllZoomLinks(zoomLinks: { idpEventId: string; institutionId: string; clientEmailId: string }): Observable<Events> {
    return this.http
      .get<Events>(environment.zoomLinks, { params: zoomLinks })
      .pipe(retry(1), catchError(this.errorHandler));
  }

  getCheckIn(checkInData: { idpEventId: string; institutionId: string; clientEmailId: string }): Observable<Events> {
    return this.http
      .put<Events>(environment.checkIn, checkInData, this.httpOptions).pipe(catchError(this.errorHandler));
  }

  postStudentVisitedBooth(visitedBoothData: { eventId: string; institutionId: string; studentProfileId: string, visitedBooth: boolean }): Observable<VisitedBoothData> {
    return this.http
      .post<VisitedBoothData>(environment.visitedBoothData, visitedBoothData, this.httpOptions).pipe(catchError(this.errorHandler));
  }

  getAllDashboardData(data: { institutionId: string; clientEmailId: string; idpEventId: string; }) {
    return this.http
      .get<any>(environment.dashboardReports, { params: data })
      .pipe(retry(1), catchError(this.errorHandler));
  }

  customTooltip(context, ind, countWithPercentage) {
    let tooltipEl = document.getElementById('chartjs-tooltip' + ind);
    if (!tooltipEl) {
      tooltipEl = document.createElement('div');
      tooltipEl.id = 'chartjs-tooltip' + ind;
      document.body.appendChild(tooltipEl);
    }
    const tooltipModel = context.tooltip;
    tooltipEl.style.left = tooltipModel.caretX - 22 + 'px';
    tooltipEl.style.top = tooltipModel.caretY - 44 + 'px';
    const arrayValue = context.tooltip.dataPoints[0].dataIndex;
    const destinationValues = countWithPercentage;
    tooltipEl.innerHTML = destinationValues[arrayValue]?.toString();
    if (tooltipModel.opacity === 0) {
      tooltipEl.style.opacity = '0';
    } else {
      tooltipEl.style.opacity = '1';
    }
  }

  errorHandler(error: HttpErrorResponse) {
    return throwError(error);
  }

}
