import { TestBed } from '@angular/core/testing'
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing'

import { Observable } from 'rxjs'

import { UpcomingPackagesService } from './upcoming-packages.service'

describe('UpcomingPackagesService', () => {
  let service: UpcomingPackagesService
  let httpMock: HttpTestingController

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UpcomingPackagesService]
    })
    service = TestBed.inject(UpcomingPackagesService)
    httpMock = TestBed.inject(HttpTestingController)
  })

  afterEach(() => {
    httpMock.verify()
  })

  it('should be created', () => {
    expect(service).toBeTruthy()
  })

  it('should return an observable', () => {
    const result = service.getFilterOptions()
    expect(result).toBeInstanceOf(Observable)
  })

  it('should send an HTTP GET request to the correct URL', () => {
    const expectedUrl = '/assets/json/filter-package.json'
    service.getFilterOptions().subscribe()
    const request = httpMock.expectOne(expectedUrl)
    expect(request.request.method).toEqual('GET')
  })

  it('should send an HTTP GET request to the correct URL', () => {
    const expectedUrl = 'https://api.clientportal.dev.idp.com/clientportal/v1/packages?institutionId=IID-CA-00640'
    service.getPackageListInfo({ institutionId: 'IID-CA-00640' }).subscribe()
    const request = httpMock.expectOne(expectedUrl)
    expect(request.request.method).toEqual('GET')
  })
})
