import { HttpClient, HttpErrorResponse } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { catchError, Observable, retry, throwError } from 'rxjs'
import {
  FilterOption,
  UpcomingPackages
} from '../models/upcoming-packages.model'
import { environment } from 'src/environments/environment'
import { mockDataURL } from '../constants/upcoming-packages.constant'

@Injectable({
  providedIn: 'root'
})
export class UpcomingPackagesService {
  constructor (private readonly http: HttpClient) {}

  /**
   * @function getFilterOptions
   * * Get all the filteroptions for the json
   * @returns Observable<FilterOption>
   */
  getFilterOptions (): Observable<FilterOption> {
    return this.http.get<FilterOption>(mockDataURL.filterList)
  }

  /**
   * @function getPackageListInfo
   * * Function to get upcoming package list  from an API
   * @param filterData: { institutionId: string }
   * @returns Observable<UpcomingPackages[]>
   */
  getPackageListInfo (filterData: {
    institutionId: string
  }): Observable<UpcomingPackages> {
    return this.http
      .get<UpcomingPackages>(environment.packageListAPI, {
      params: filterData
    })
      .pipe(retry(1), catchError(this.errorHandler))
  }

  /**
   * @function errorHandler
   * * Function to Handle an error
   * @returns Observable<UpcomingPackages[]>
   * @param error: HttpErrorResponse
   */
  errorHandler (error: HttpErrorResponse): Observable<UpcomingPackages> {
    return throwError(error)
  }
}
