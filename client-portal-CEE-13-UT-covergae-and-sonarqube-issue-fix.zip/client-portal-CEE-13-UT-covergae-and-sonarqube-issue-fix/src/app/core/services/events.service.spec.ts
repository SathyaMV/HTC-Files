import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController, } from '@angular/common/http/testing';
import { EventsService } from './events.service';
import { HttpErrorResponse } from '@angular/common/http';

describe('EventsService', () => {
  let service: EventsService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EventsService],
    });
    service = TestBed.inject(EventsService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => httpMock.verify());

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return an getAllBookedEvents', () => {
    const eventsListData = {
      source: '',
      pageNumber: 1,
      pageSize: 10,
      searchEventName: '',
      institutionId: 'IID-CA-00747',
      clientId: 'ABC'
    };
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/bookedEventsListAndSearch?source=&pageNumber=1&pageSize=10&searchEventName=&institutionId=IID-CA-00747&clientId=ABC`;
    service.getAllBookedEvents(eventsListData).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('GET');
    req.flush(mockResult);
  });

  it('should return an getAllStudents', () => {
    const studentsListData = {
      eventId: '1264b65d-780e-4ceb-a561-8c009e445eb0',
      pageNumber: 1,
      institutionId: 'IID-CA-00640',
      pageSize: 10,
      searchBy: 'email',
      searchValue: 'abc@gmail.com'
    };
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/studentListSearch?eventId=1264b65d-780e-4ceb-a561-8c009e445eb0&pageNumber=1&institutionId=IID-CA-00640&pageSize=10&searchBy=email&searchValue=abc@gmail.com`;
    service.getAllStudents(studentsListData).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('GET');
    req.flush(mockResult);
  });

  it('should return an getAllZoomLinks', () => {
    const zoomLinksData = {
      idpEventId: '21f42f59-7e2b-400b-a902-dfa07fc2cfff',
      clientEmailId: 'abc@gmail.com',
      institutionId: 'IID-CA-00640'
    };
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/zoomLinks?idpEventId=21f42f59-7e2b-400b-a902-dfa07fc2cfff&clientEmailId=abc@gmail.com&institutionId=IID-CA-00640`;
    service.getAllZoomLinks(zoomLinksData).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('GET');
    req.flush(mockResult);
  });

  it('should called an customTooltip', () => {
    const context: any = {
      chart: {}, replay: undefined, tooltip: {
        caretX: 240.97223756735326, caretY: 86.12222873703487, opacity: 0, dataPoints: [
          {
            dataIndex: 1
          }
        ]
      }
    }
    service.customTooltip(context, 1, '3,30%');
  });
  it('should return an getAllDashboardData', () => {
    const params = {
      idpEventId: '21f42f59-7e2b-400b-a902-dfa07fc2cfff',
      clientEmailId: 'abc@gmail.com',
      institutionId: 'IID-CA-00640'
    };
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/dashboardReports?idpEventId=21f42f59-7e2b-400b-a902-dfa07fc2cfff&clientEmailId=abc@gmail.com&institutionId=IID-CA-00640`;
    service.getAllDashboardData(params).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('GET');
    req.flush(mockResult);
  });

  it('should return an getCheckIn', () => {
    const params = {
      idpEventId: '21f42f59-7e2b-400b-a902-dfa07fc2cfff',
      clientEmailId: 'abc@gmail.com',
      institutionId: 'IID-CA-00640'
    };
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/clientCheckIn`;
    service.getCheckIn(params).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('PUT');
  });

  it('should return an postStudentVisitedBooth', () => {
    const params = {
        eventId: '1264b65d-780e-4ceb-a561-8c009e445eb0',
        institutionId: 'IID-CA-00640',
        studentProfileId: '13f3aa4f-3e6d-480a-92b4-1f7d5d304bec',
        visitedBooth: true
      }
    const mockResult = [];
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/studentVisitedBooth`;
    service.postStudentVisitedBooth(params).subscribe((res) => {
      expect(res).toBe(mockResult);
    });
    const req = httpMock.expectOne(expectedUrl);
    expect(req.request.method).toBe('POST');
  });

  it('throws 404 error', () => {
    const eventsListData = {
      source: '',
      pageNumber: 1,
      pageSize: 10,
      searchEventName: '',
      institutionId: 'IID-CA-00747',
      clientId: 'ABC'
    };
    service.getAllBookedEvents(eventsListData).subscribe(
      data => fail('Should have failed with 404 error'),
      (error: HttpErrorResponse) => {
        expect(error.status).toEqual(404);
        expect(error.error).toContain('404 error');
      }
    );
    const expectedUrl = `https://api.clientportal.dev.idp.com/clientportal/v1/bookedEventsListAndSearch?source=&pageNumber=1&pageSize=10&searchEventName=&institutionId=IID-CA-00747&clientId=ABC`;
    const req = httpMock.expectOne(expectedUrl);
  });

});
