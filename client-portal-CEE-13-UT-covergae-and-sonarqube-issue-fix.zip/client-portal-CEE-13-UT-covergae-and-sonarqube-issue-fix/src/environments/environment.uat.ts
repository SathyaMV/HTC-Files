import { Constants } from "src/app/core/constants/app.constant";

const apiDomain = Constants.uat;

export const environment = {
    production: true,
    baseHref: '/',
    bookedEventsListAndSearch: apiDomain.bookedEventsListAndSearch,
    studentListAndSearch: apiDomain.studentListAndSearch,
    zoomLinks: apiDomain.zoomLinks,
    dashboardReports: apiDomain.dashboardReports,
    checkIn: apiDomain.checkIn,
    visitedBoothData: apiDomain.visitedBoothData,
};