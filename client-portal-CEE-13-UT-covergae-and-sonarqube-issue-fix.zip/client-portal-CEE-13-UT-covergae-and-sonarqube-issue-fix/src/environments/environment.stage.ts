import { Constants } from 'src/app/core/constants/app.constant'
import { upcomingPackagesConstants } from 'src/app/core/constants/upcoming-packages.constant'

const apiDomain = Constants.stg
const upcomingPackagesApiDomain = upcomingPackagesConstants.stg

export const environment = {
  production: true,
  baseHref: '/',
  bookedEventsListAndSearch: apiDomain.bookedEventsListAndSearch,
  studentListAndSearch: apiDomain.studentListAndSearch,
  zoomLinks: apiDomain.zoomLinks,
  dashboardReports: apiDomain.dashboardReports,
  checkIn: apiDomain.checkIn,
  visitedBoothData: apiDomain.visitedBoothData,
  packageListAPI: upcomingPackagesApiDomain.packageListAPI
}
