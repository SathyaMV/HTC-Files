import { Directive } from '@angular/core'
import { MAT_DATE_FORMATS } from '@angular/material/core'
import { monthYearDateFormat } from 'src/app/core/constants/upcoming-packages.constant'

@Directive({
  selector: '[monthYearCalendar]',
  providers: [{ provide: MAT_DATE_FORMATS, useValue: monthYearDateFormat }]
})
export class MonthYearDirective {}
