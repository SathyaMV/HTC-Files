import { MonthYearDirective } from './month-year.directive';

describe('MonthYearDirective', () => {
  it('should create an instance', () => {
    const directive = new MonthYearDirective();
    expect(directive).toBeTruthy();
  });
});
