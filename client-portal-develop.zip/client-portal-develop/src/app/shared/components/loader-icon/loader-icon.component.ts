import { Component, OnInit } from '@angular/core'
import { EventsService } from 'src/app/core/services/events.service'

@Component({
  selector: 'app-loader-icon',
  templateUrl: './loader-icon.component.html',
  styleUrls: ['./loader-icon.component.css']
})
export class LoaderIconComponent implements OnInit {
  showLoaderIcon: boolean = false

  constructor (private readonly eventsService: EventsService) {}

  ngOnInit (): void {
    this.eventsService.showLoaderIcon.subscribe(data => {
      this.showLoaderIcon = data
    })
  }
}
