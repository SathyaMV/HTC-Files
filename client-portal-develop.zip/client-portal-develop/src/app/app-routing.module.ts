import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'upcoming-packages',
    loadChildren: () => import('./modules/pages/upcoming-packages/upcoming-packages.module').then(m => m.UpcomingPackagesModule)
  },
  {
    path: '',
    loadChildren: () => import('./modules/pages/events/events.module').then(m => m.EventsModule)
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }