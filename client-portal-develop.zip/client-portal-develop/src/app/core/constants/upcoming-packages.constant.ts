const dev = 'https://api.clientportal.dev.idp.com/clientportal/'
const stg = 'https://api.clientportal.stg.idp.com/clientportal/'

export const upcomingPackagesConstants = {
  dev: {
    packageListAPI: dev + 'v1/packages'
  },
  stg: {
    packageListAPI: stg + 'v1/packages'
  }
}

export const mockDataURL = {
  filterList: '/assets/json/filter-package.json'
}

export const monthYearDateFormat = {
  parse: {
    dateInput: 'MM/YYYY'
  },
  display: {
    dateInput: 'MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
}

export const yearDateFormat = {
  parse: {
    dateInput: 'MM/YYYY'
  },
  display: {
    dateInput: 'YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
}

export const countryList = {
  IND: 'India',
  AU: 'Australia',
  NZ: 'New Zealand'
}
