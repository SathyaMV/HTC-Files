interface PackagePrice {
  id: string
  actualPrice: number
  price: string
  destCountryCode: string
}

interface PackageEarlyBird {
  id: string
  startDate: string
  endDate: string
  status: string
  discount: string
  discountType: string
  destCountryCode: string
  price: string
}

interface Event {
  id: string
  eventName: string
  startDate: string
  endDate: string
  destination: string
  hostCountry: string
  price: number
}

export interface Package {
  id: string
  title: string
  startDate: string
  endDate: string
  packageType: string
  status: string
  packagePrice: PackagePrice[]
  price: string
  packageEarlyBird: PackageEarlyBird[]
  events: Event[]
  totalEvents: number
  eventDuration: string
  destinationCountries: string
  hostCountryName: string
  hostCountryImgPath: string
  eventGroup: string
  cartButtonLabel: string
  isBookingDeadlineAvailable: boolean
  isEarlyBirdAvailable: boolean
  isHidden: boolean
  bookingDeadlineDate: string
  destinationEarlyBirdInfo: PackageEarlyBird
  earlyBirdEndDate: string
}

export interface UpcomingPackages {
  statusCode: number
  statusMessage: string
  errorMessage: boolean
  packages: Package[]
}

export interface RegionOption {
  label: string
  value: string
}

export interface CountryOption {
  label: string
  value: string
  region: string
}

export interface GroupOption {
  label: string
  value: string
}

export interface FilterOption {
  regionOptions: RegionOption[]
  countryOptions: CountryOption[]
  groupOptions: GroupOption[]
}
