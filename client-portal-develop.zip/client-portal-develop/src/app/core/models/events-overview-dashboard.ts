export interface Dashboard {
    percentage?: any
    option: string,
    count: number
}

export interface EventDashboard {
    checkIn: boolean,
    message: string,
    status: number,
    totalRegistrantsCount: number,
    highestQualification: Dashboard,
    planToStudy: Dashboard,
    preferredDestination: Dashboard,
    preferredStudyLevel: Dashboard,
}