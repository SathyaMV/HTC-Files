export enum EventType {
    VIRTUAL = 'Virtual',
    PHYSICAL = 'Physical',
    HYBRID = 'Hybrid'
}