import { NgModule } from '@angular/core'
import { RouterModule, Routes } from '@angular/router'
import { PackagesDashboardComponent } from './packages-dashboard/packages-dashboard.component'

const routes: Routes = [{ path: '', component: PackagesDashboardComponent }]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UpcomingPackagesRoutingModule {}
