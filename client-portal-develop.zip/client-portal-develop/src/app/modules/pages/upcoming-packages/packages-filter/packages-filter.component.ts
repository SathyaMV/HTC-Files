import { Component, OnInit, OnDestroy, Input } from '@angular/core'
import { FormControl, FormGroup } from '@angular/forms'
import { MatDatepicker } from '@angular/material/datepicker'
import { Subscription } from 'rxjs'
import { CountryOption, RegionOption, GroupOption } from '../../../../core/models/upcoming-packages.model'
import { UpcomingPackagesService } from '../../../../core/services/upcoming-packages.service'
import * as momentAdapter from 'moment'
import rollupMoment, { Moment } from 'moment'
const moment = rollupMoment || momentAdapter

@Component({
  selector: 'app-packages-filter',
  templateUrl: './packages-filter.component.html',
  styleUrls: ['./packages-filter.component.css']
})
export class PackagesFilterComponent implements OnInit, OnDestroy {
  constructor (private readonly filterService: UpcomingPackagesService) { }
  @Input() packageCount: number
  form!: FormGroup
  regionOptions: RegionOption[] = []
  countryOptions: CountryOption[] = []
  groupOptions: GroupOption[] = []
  date: FormControl = new FormControl(moment())
  year: FormControl = new FormControl(moment())
  minDate: Date = new Date()
  filterSubscription: Subscription

  ngOnInit (): void {
    this.form = new FormGroup({
      selectedRegion: new FormControl([]),
      selectedCountry: new FormControl([]),
      selectedGroup: new FormControl([])
    })

    this.getRegionOptions()
    this.getCountryOptions()
    this.getGroupOptions()
  }

  ngOnDestroy (): void {
    if (this.filterSubscription !== undefined) {
      this.filterSubscription.unsubscribe()
    }
  }

  /**
   * @function getRegionOptions
   * * get region dropdown data's from the json
   */
  getRegionOptions (): void {
    this.filterService.getFilterOptions().subscribe(region => {
      this.regionOptions = JSON.parse(JSON.stringify(region.regionOptions))
    })
  }

  /**
   * @function getCountryOptions
   * * get country dropdown data's from the json
   */
  getCountryOptions (): void {
    this.filterService.getFilterOptions().subscribe(country => {
      this.countryOptions = JSON.parse(JSON.stringify(country.countryOptions))
    })
  }

  /**
   * @function getgroupOptions
   * * get group dropdown data's from the json
   */
  getGroupOptions (): void {
    this.filterService.getFilterOptions().subscribe(group => {
      this.groupOptions = JSON.parse(JSON.stringify(group.groupOptions))
    })
  }

  /**
   * @function selectAllRegion
   * * select all the region in the filter dropdown
   */
  onSelectAllRegion (): void {
    this.form.patchValue({
      selectedRegion: this.regionOptions.map(option => option.value)
    })
  }

  /**
   * @function deselectAllRegion
   * * deselect all the region in the filter dropdown
   */
  onClearAllRegion (): void {
    this.form.patchValue({ selectedRegion: [] })
  }

  /**
   * @function selectAllCountry
   * * select all the country in the filter dropdown
   */
  onSelectAllCountry (): void {
    this.form.patchValue({
      selectedCountry: this.countryOptions.map(option => option.value)
    })
  }

  /**
   * @function deselectAllcountry
   * * deselect all the country in the filter dropdown
   */
  onClearAllCountry (): void {
    this.form.patchValue({ selectedCountry: [] })
  }

  /**
   * @function selectAllGroup
   * * select all the group in the filter dropdown
   */
  onSelectAllGroup (): void {
    this.form.patchValue({
      selectedGroup: this.groupOptions.map(option => option.value)
    })
  }

  /**
   * @function deselectAllGroup
   * * deselect all the group in the filter dropdown
   */
  onClearAllGroup (): void {
    this.form.patchValue({ selectedGroup: [] })
  }

  /**
   * @function clearFilters
   * * resetting all the selected filter option to default(empty)
   */
  clearFilters (): void {
    this.form.reset()
  }

  /**
   * @function chosenYearHandler
   * * choose a year
   */
  chosenYearHandler (normalizedYear: Moment): void {
    const ctrlValue = this.date.value
    ctrlValue.year(normalizedYear.year())
    this.date.setValue(ctrlValue)
  }

  /**
   * @function chosenMonthHandler
   * * choose a specific month in the datepicker
   */
  chosenMonthHandler (
    normalizedMonth: Moment,
    datepicker: MatDatepicker<Moment>
  ): void {
    datepicker.close()
    const ctrlValue = this.date.value
    ctrlValue.month(normalizedMonth.month())
    this.date.setValue(ctrlValue)
  }

  /**
   * @function previousYear
   * * change datepicker to previous year
   */
  previousMonth (): void {
    const ctrlValue = this.date.value
    if (
      ctrlValue.month() > this.minDate.getMonth() ||
      ctrlValue.year() > this.minDate.getFullYear()
    ) {
      ctrlValue.month(ctrlValue.month() - 1)
    }
    this.date.setValue(ctrlValue)
  }

  /**
   * @function nextMonth
   * * change datepicker to next month
   */
  nextMonth (): void {
    const ctrlValue = this.date.value
    ctrlValue.month(String(Number(ctrlValue.month()) + 1))
    this.date.setValue(ctrlValue)
  }

  /**
   * @function previousYear
   * * change datepicker to previous year
   */
  previousYear (): void {
    const ctrlValue = this.year.value
    if (ctrlValue.year() > this.minDate.getFullYear()) {
      ctrlValue.year(ctrlValue.year() - 1)
    }
    this.year.setValue(ctrlValue)
  }

  /**
   * @function nextYear
   * * change datepicker to next year
   */
  nextYear (): void {
    const ctrlValue = this.year.value
    // ctrlValue.year(ctrlValue.year() + 1)
    ctrlValue.year(String(Number(ctrlValue.year()) + 1))
    this.year.setValue(ctrlValue)
    if (this.packageCount >= 6) {
      ctrlValue.month(0)
      this.date.setValue(ctrlValue)
    }
  }
}
