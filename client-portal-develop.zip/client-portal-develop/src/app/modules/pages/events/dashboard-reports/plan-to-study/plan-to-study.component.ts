import { Component, OnInit, Input } from '@angular/core';
import { ChartConfiguration, ChartOptions, Chart } from 'chart.js';
import { Dashboard } from 'src/app/core/models/events-overview-dashboard';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-plan-to-study',
  templateUrl: './plan-to-study.component.html',
  styleUrls: ['./plan-to-study.component.css']
})
export class PlanToStudyComponent implements OnInit {

  scrWidth = window.innerWidth;
  @Input() planToStudyData: Dashboard[];
  isMissing: boolean = false;
  count: any = [];

  constructor(public eventsService : EventsService) {}

  ngOnInit(): void {
    this.getwindowidth();
    this.setPlanToStudy();
  }

  setPlanToStudy(): void {
    for (let i = 0; i < this.planToStudyData?.length; i++) {
      this.count.push(this.planToStudyData[i].count);
      if (this.planToStudyData[i].option == 'missing')
        this.isMissing = true;
    }
    if (this.isMissing)
      this.barChartData.labels.push('missing')

    this.barChartData.datasets[0].data = this.count;
  }
  
  getwindowidth(): void {
    if (this.scrWidth < 1200) {
      Chart.defaults.datasets.bar.barThickness = 20;
      this.barChartOptions.indexAxis = 'y';
    } else {
      Chart.defaults.datasets.bar.barThickness = 98;
    }
  }
  barChartData: ChartConfiguration['data'] = {
    labels: ["within 6 mths", "6-12 mths", "1-2 yrs", "2+ yrs"],
    datasets: [
      { data: [], backgroundColor: '#FF8300', hoverBackgroundColor: '#e67700' }
    ],
  };
  public barChartOptions: ChartOptions = {
    maintainAspectRatio: false,
    plugins: {
      tooltip: {
        enabled: false,
        external: (context) => {
          this.eventsService.customTooltip(context, 1, this.count);
        }
      }
    },
    scales: {
      x: {
        ticks: {
          padding: 10,
          color: '#000',
          font: {
            family: "BuenosAires-Regular",
            size: 12
          },
          callback: function (label, index) {
            var label_val = this.getLabelForValue(index);
            if (window.innerWidth < 1200) {
              return '';
            } else {
              return label_val;
            }
          }
        },
        grid: {
          drawOnChartArea: false,
          drawTicks: false,
          borderWidth: 0
        }
      },
      y: {
        ticks: {
          padding: 15,
          display: true,
          color: '#000',
          font: {
            family: "BuenosAires-Regular",
            size: 12
          },
          callback: function (label, index) {
            var label_val = this.getLabelForValue(index);
            if (window.innerWidth < 1200) {
              return label_val;
            } else {
              return '';
            }
          }
        },
        grid: {
          display: false,
          drawBorder: false,
        }
      }
    }
  };
}
