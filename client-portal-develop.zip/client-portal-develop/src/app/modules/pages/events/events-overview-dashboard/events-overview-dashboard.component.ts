import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { EventDashboard, Dashboard } from 'src/app/core/models/events-overview-dashboard';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-events-overview-dashboard',
  templateUrl: './events-overview-dashboard.component.html',
  styleUrls: ['./events-overview-dashboard.component.css']
})
export class EventsOverviewDashboardComponent implements OnInit {

  scrWidth = window.innerWidth;
  planToStudyData: Dashboard;
  destinationData: Dashboard;
  educationData: Dashboard;
  studyLevelData: Dashboard;
  registrantsData = 0;
  isLoading = false;
  @Output() isCheckedIn = new EventEmitter<any>();
  params = { institutionId: 'IID-CA-00637', clientEmailId: 'test7@gmail.com', idpEventId: '2b749905-55b1-4637-ab93-47b5bff5bc75' };
  constructor(private service: EventsService) { }
  ngOnInit(): void {
    this.getAllDashboardData();
  }

  getAllDashboardData(): void {
    this.isLoading = true;
    this.service.getAllDashboardData(this.params).subscribe((res: EventDashboard) => {
      this.planToStudyData = res.planToStudy;
      this.destinationData = res.preferredDestination;
      this.educationData = res.highestQualification;
      this.studyLevelData = res.preferredStudyLevel;
      this.registrantsData = res.totalRegistrantsCount;
      this.isCheckedIn.emit(res.checkIn);
      this.isLoading = false;
    });
  }

}
