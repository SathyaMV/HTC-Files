import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventType } from 'src/app/core/enums/enum';
import { EventsService } from 'src/app/core/services/events.service';

@Component({
  selector: 'app-booked-events',
  templateUrl: './booked-events.component.html',
  styleUrls: ['./booked-events.component.css']
})
export class BookedEventsComponent implements OnInit {

  upComingEventsList: any = [];
  itemsPerPage: number = 10;
  upcomingPageNumber = 1;
  pastPageNumber = 1;
  tabChanged: string = 'Upcoming';
  pastEventList: any = [];
  orgUpcomingList: any = [];
  orgPastList: any = [];
  searchValue: string;
  eventsListData = { source: 'Upcoming', pageNumber: 1, pageSize: 10, searchEventName: '', institutionId: 'IID-CA-00637', clientId: 'test7@idp.com' };
  tabValue: string;
  totalUpcomingItems: number;
  totalPastItems: number;
  orgUpcomingCount: number = 0;
  orgPastCount: number = 0;
  isPagination: boolean = false;

  constructor(private service: EventsService, private router: Router) { }

  ngOnInit(): void {
    this.getEventsList();
  }

  getEventsList(): void {
    this.eventsListData.pageNumber = this.tabChanged === 'Upcoming' ? this.upcomingPageNumber : this.pastPageNumber;
    this.eventsListData.source = this.tabChanged;
    this.service.getAllBookedEvents(this.eventsListData).subscribe((events: any) => {
      this.tabBasedDataset(events);
    });
  }

  tabBasedDataset(events: any): void {
    if (this.tabChanged == 'Upcoming') {
      this.upComingEventsList = events.idpEvents?.upcoming;
      this.totalUpcomingItems = events.idpEvents?.upcomingCount;
      if (!this.isPagination) {
        this.orgUpcomingList = events.idpEvents?.upcoming;
        this.orgUpcomingCount = events.idpEvents?.upcomingCount;
      }
    }
    else {
      this.pastEventList = events.idpEvents?.past;
      this.totalPastItems = events.idpEvents?.pastCount;
      if (!this.isPagination) {
        this.orgPastList = events.idpEvents?.past;
        this.orgPastCount = events.idpEvents?.pastCount;
      }
    }
  }

  searchDataSet(events) {
    if (this.searchValue?.length < 3) {
      this.searchLengthCheck();
    } else {
      if (this.tabChanged == 'Upcoming') {
        this.upComingEventsList = events?.idpEvents?.upcoming ? events?.idpEvents?.upcoming : [];
        this.totalUpcomingItems = events.idpEvents?.upcomingCount;
        this.upcomingPageNumber = 1;
      }
      else {
        this.pastEventList = events?.idpEvents?.past ? events?.idpEvents?.past : [];
        this.totalPastItems = events.idpEvents?.pastCount;
        this.pastPageNumber = 1;
      }
    }
  }

  onChange(): void {
    if (this.searchValue?.length >= 3) {
      this.eventsListData.source = this.tabChanged;
      this.eventsListData.searchEventName = this.searchValue;
      this.eventsListData.pageNumber = 1;
      this.service.getAllBookedEvents(this.eventsListData).subscribe((events: any) => {
        this.searchDataSet(events ? events : []);
      });
    } else if (this.searchValue?.length < 3) {
      this.searchLengthCheck();
    }
  }
  searchLengthCheck() {
    this.eventsListData.searchEventName = this.searchValue;
    this.isPagination = false;
    if (this.tabChanged == 'Upcoming') {
      this.upComingEventsList = this.orgUpcomingList;
      this.totalUpcomingItems = this.orgUpcomingCount;
      this.upcomingPageNumber = 1;
    }
    else {
      this.pastEventList = this.orgPastList;
      this.totalPastItems = this.orgPastCount;
      this.pastPageNumber = 1;
    }
  }
  renderPage(event: number, value: string): void {
    this.isPagination = true;
    if (value === 'Upcoming') {
      this.upcomingPageNumber = event;
      this.getEventsList();
      return
    }
    this.pastPageNumber = event;
    this.getEventsList();
  }

  scrollTop(tab: string): void {
    if (tab === 'upcoming') {
      document.getElementById('listTopUpcoming').scrollIntoView({ behavior: "smooth" });
    } else {
      document.getElementById('listTopPast').scrollIntoView({ behavior: "smooth" });
    }
  }

  getEventTypeClass(eventType: string): string {
    if (eventType === EventType.VIRTUAL)
      return 'event_type virtual';
    else if (eventType === EventType.HYBRID)
      return 'event_type hybrid';
    else return 'event_type';
  }

  getPagination(pageNumber: number, length: number): string {
    let startValue = ((pageNumber - 1) * this.itemsPerPage) + 1;
    let endValue = pageNumber * this.itemsPerPage > length ? length : pageNumber * this.itemsPerPage;
    return `Showing ${startValue} to ${endValue} of ${length}`
  }

  onTabClick(event: any): string {
    this.searchValue = '';
    this.isPagination = false;
    this.eventsListData.searchEventName = '';
    this.tabChanged = this.tabChanged == 'Upcoming' ? 'Past' : 'Upcoming';
    this.getEventsList();
    if (this.searchValue == '') {
      this.upComingEventsList = this.orgUpcomingList;
      this.pastEventList = this.orgPastList;
    }
    this.tabChanged = event.tab.textLabel;
    return this.tabChanged === 'Upcoming' ? this.upComingEventsList : this.pastEventList;
  }

  eventOverViewPage(eventId: string): void {
    const upComingEventsOverviewData = this.upComingEventsList.filter(x => {
      return x.idpEventId === eventId;
    });
    const pastEventsOverviewData = this.pastEventList.filter(x => {
      return x.idpEventId === eventId;
    });
    const eventsOverviewData = this.tabChanged === 'Upcoming' ? upComingEventsOverviewData : pastEventsOverviewData
    sessionStorage.setItem('eventOverviewDetail', JSON.stringify(eventsOverviewData));
    this.router.navigateByUrl('events-overview' + '?eventId=' + eventId);
  }

}